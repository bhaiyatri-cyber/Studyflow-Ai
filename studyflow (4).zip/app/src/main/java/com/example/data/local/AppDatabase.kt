package com.example.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.data.model.TimeBlock
import com.example.data.model.DailyStats

@Database(entities = [TimeBlock::class, DailyStats::class], version = 10, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun timeBlockDao(): TimeBlockDao
    abstract fun statsDao(): StatsDao
}
