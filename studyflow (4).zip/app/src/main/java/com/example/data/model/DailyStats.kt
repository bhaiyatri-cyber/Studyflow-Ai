package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_stats")
data class DailyStats(
    @PrimaryKey val id: Int = 1,
    val totalStudyHours: Long = 0L, // in milliseconds, will convert to hours when displaying
    val totalCompletedTasks: Int = 0,
    val totalMissedTasks: Int = 0,
    val totalStudyDays: Int = 0,
    val currentStreak: Int = 0,
    val longestStreak: Int = 0,
    val lastStudyDateMs: Long = 0L,
    val dailyStudyHourGoal: Int = 4,
    val dailyTaskGoal: Int = 5
)
