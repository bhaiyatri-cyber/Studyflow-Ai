package com.example.data.repository

import com.example.data.local.StatsDao
import com.example.data.local.TimeBlockDao
import com.example.data.model.DailyStats
import com.example.data.model.TimeBlock
import kotlinx.coroutines.flow.Flow

class StudyRepository(
    private val timeBlockDao: TimeBlockDao,
    private val statsDao: StatsDao
) {
    fun getAllBlocks(): Flow<List<TimeBlock>> = timeBlockDao.getAllBlocks()
    
    fun getBlocksForDay(startOfDay: Long, endOfDay: Long): Flow<List<TimeBlock>> = 
        timeBlockDao.getBlocksForDay(startOfDay, endOfDay)
        
    suspend fun getBlockById(id: Int): TimeBlock? = timeBlockDao.getBlockById(id)
    suspend fun insertBlock(timeBlock: TimeBlock): Long = timeBlockDao.insertBlock(timeBlock)
    suspend fun updateBlock(timeBlock: TimeBlock) = timeBlockDao.updateBlock(timeBlock)
    suspend fun deleteBlockById(id: Int) = timeBlockDao.deleteBlockById(id)

    fun getStats(): Flow<DailyStats?> = statsDao.getStats()
    suspend fun insertStats(stats: DailyStats) = statsDao.insertStats(stats)
    suspend fun updateStats(stats: DailyStats) = statsDao.updateStats(stats)
}
