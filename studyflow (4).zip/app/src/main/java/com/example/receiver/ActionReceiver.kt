package com.example.receiver

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.room.Room
import com.example.data.local.AppDatabase
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class ActionReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_COMPLETE_TASK = "com.example.ACTION_COMPLETE_TASK"
        const val ACTION_SKIP_TASK = "com.example.ACTION_SKIP_TASK"
        const val EXTRA_TASK_ID = "EXTRA_TASK_ID"
        const val EXTRA_NOTIFICATION_ID = "EXTRA_NOTIFICATION_ID"
    }

    @OptIn(DelicateCoroutinesApi::class)
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        val taskId = intent.getIntExtra(EXTRA_TASK_ID, -1)
        val notificationId = intent.getIntExtra(EXTRA_NOTIFICATION_ID, -1)

        if (taskId == -1) return
        if (notificationId != -1) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.cancel(notificationId)
        }

        
            try {
                val serviceIntent = Intent(context, com.example.service.TaskForegroundService::class.java).apply {
                    this.action = com.example.service.TaskForegroundService.ACTION_STOP
                }
                context.stopService(Intent(context, com.example.service.TaskForegroundService::class.java))
            } catch(e: Exception) {}
            
            val pendingResult = goAsync()

        GlobalScope.launch {
            try {
                val db = com.example.data.local.DatabaseProvider.getDatabase(context)
                
                val block = db.timeBlockDao().getBlockById(taskId)
                if (block != null) {
                    when (action) {
                        ACTION_COMPLETE_TASK -> {
                            db.timeBlockDao().updateBlock(block.copy(status = "Completed", completedOnMs = System.currentTimeMillis()))
                            Log.d("ActionReceiver", "Task completed: ${block.subject}")
                            updateStats(db)
                        }
                        ACTION_SKIP_TASK -> {
                            db.timeBlockDao().updateBlock(block.copy(status = "Skipped"))
                            Log.d("ActionReceiver", "Task skipped: ${block.subject}")
                            updateStats(db, missed = true)
                        }
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
    
    private suspend fun updateStats(db: AppDatabase, missed: Boolean = false) {
        val statsDao = db.statsDao()
        val currentStats = statsDao.getStatsOnce()
        if (currentStats != null) {
            if (missed) {
                statsDao.updateStats(currentStats.copy(totalMissedTasks = currentStats.totalMissedTasks + 1))
            } else {
                statsDao.updateStats(currentStats.copy(totalCompletedTasks = currentStats.totalCompletedTasks + 1))
            }
        }
    }
}
