package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.room.Room
import com.example.data.local.AppDatabase
import com.example.util.AlarmScheduler
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {

    @OptIn(DelicateCoroutinesApi::class)
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_LOCKED_BOOT_COMPLETED) {
            val pendingResult = goAsync()
            Log.d("BootReceiver", "Device booted. Rescheduling alarms...")
            val alarmScheduler = AlarmScheduler(context)
            alarmScheduler.scheduleMidnightReset()
            GlobalScope.launch {
                try {
                    val db = com.example.data.local.DatabaseProvider.getDatabase(context)
                    
                    val blocks = db.timeBlockDao().getAllBlocks().first()
                    for (block in blocks) {
                        alarmScheduler.scheduleAlarmsForBlock(block)
                    }
                    Log.d("BootReceiver", "Successfully rescheduled ${blocks.size} blocks.")
                } catch (e: Exception) {
                    Log.e("BootReceiver", "Error rescheduling alarms", e)
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
