package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.model.TimeBlock
import kotlinx.coroutines.*

class AppAccessibilityService : AccessibilityService() {

    companion object {
        var currentForegroundPackage: String? = null
    }

    private var job: Job? = null
    private var timeNotStudyingSeconds = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 100
        }
        serviceInfo = info
        Log.d("AppAccessibilityService", "Service Connected")

        createNotificationChannel()
        startTracking()
    }

    private fun startTracking() {
        job = CoroutineScope(Dispatchers.IO).launch {
            val db = com.example.data.local.DatabaseProvider.getDatabase(applicationContext)
            val dao = db.timeBlockDao()

            while (isActive) {
                try {
                    val now = System.currentTimeMillis()
                    val blocks = dao.getAllBlocksSync()
                    
                    // Find active block
                    val activeBlock = blocks.firstOrNull { block ->
                        (block.status == "Running" || now in block.startTimeMs..block.endTimeMs) && block.status != "Completed"
                    }

                    if (activeBlock != null && activeBlock.studyApps.isNotBlank()) {
                        val apps = activeBlock.studyApps.split(",").filter { it.isNotBlank() }
                        val currentApp = currentForegroundPackage
                        val isStudying = apps.contains(currentApp)

                        if (isStudying) {
                            timeNotStudyingSeconds = 0
                        } else {
                            // User has not started or is not studying
                            timeNotStudyingSeconds += 10
                            if (timeNotStudyingSeconds >= 600) { // 10 minutes
                                showNotification("Start Studying!", "You have a scheduled study session for ${activeBlock.subject}. Please open your study app.")
                                timeNotStudyingSeconds = 0
                            }
                        }
                    } else {
                        timeNotStudyingSeconds = 0
                    }
                } catch (e: Exception) {
                    Log.e("AppAccessibilityService", "Error in tracking loop", e)
                }
                delay(10000) // check every 10 seconds
            }
        }
    }

    private fun showNotification(title: String, text: String) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, "study_channel")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        notificationManager.notify(System.currentTimeMillis().toInt(), builder.build())
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Study Tracker"
            val descriptionText = "Notifications for study tracking"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel("study_channel", name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            event.packageName?.let {
                currentForegroundPackage = it.toString()
                Log.d("AppAccessibilityService", "Foreground App: $currentForegroundPackage")
            }
        }
    }

    override fun onInterrupt() {
    }

    override fun onDestroy() {
        super.onDestroy()
        job?.cancel()
    }
}
