package com.example.service

import android.app.AppOpsManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent

import android.graphics.PixelFormat
import android.view.Gravity
import android.view.LayoutInflater
import android.view.WindowManager
import android.view.View
import android.widget.TextView
import android.widget.Button
import android.provider.Settings
import android.app.Service
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.IBinder
import android.app.KeyguardManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.PowerManager
import kotlin.math.abs
import android.os.Process
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.DatabaseProvider
import com.example.receiver.ActionReceiver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TaskForegroundService : Service(), SensorEventListener {
    private val scope = CoroutineScope(Dispatchers.IO)
    private var updateJob: Job? = null
    
    private var sensorManager: SensorManager? = null
    private var accelerometer: Sensor? = null
    private var isScreenDownAndStill = false
    private var lastAccelData = FloatArray(3)
    private var accelTimestamp = 0L

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            val now = System.currentTimeMillis()
            if (now - accelTimestamp > 500) {
                val x = event.values[0]
                val y = event.values[1]
                val z = event.values[2]
                
                val dx = abs(x - lastAccelData[0])
                val dy = abs(y - lastAccelData[1])
                val dz = abs(z - lastAccelData[2])
                
                val isStill = dx < 1.5f && dy < 1.5f && dz < 1.5f
                val isFaceDown = z < -7.0f && abs(x) < 4.0f && abs(y) < 4.0f
                
                isScreenDownAndStill = isStill && isFaceDown
                
                lastAccelData[0] = x
                lastAccelData[1] = y
                lastAccelData[2] = z
                accelTimestamp = now
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    
    private var lastTickTime: Long = 0L
    private var realStudyTimeMs: Long = 0L
    private var currentTaskId: Int = -1
    
    private var appUsageMap = mutableMapOf<String, Long>()
    private var studyAppsList = listOf<String>()
    
    private var hasStartedStudying = false

    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var isPopupShowing = false

    private fun showDistractionPopup(appName: String) {
        if (isPopupShowing || !Settings.canDrawOverlays(this)) return
        
        launchMain {
            try {
                windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
                val layoutParams = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP
                    y = 100
                }
                
                // create a simple view programmatically
                val ctx = this@TaskForegroundService
                val container = android.widget.LinearLayout(ctx).apply {
                    orientation = android.widget.LinearLayout.VERTICAL
                    setPadding(50, 50, 50, 50)
                    setBackgroundColor(android.graphics.Color.parseColor("#E53935"))
                }
                val title = TextView(ctx).apply {
                    text = "Distraction Alert!"
                    textSize = 20f
                    setTextColor(android.graphics.Color.WHITE)
                    setTypeface(null, android.graphics.Typeface.BOLD)
                }
                val msg = TextView(ctx).apply {
                    text = "You are currently supposed to be studying. Get back to work!"
                    textSize = 16f
                    setTextColor(android.graphics.Color.WHITE)
                    setPadding(0, 20, 0, 30)
                }
                val dismissBtn = Button(ctx).apply {
                    text = "Back to Study"
                    setBackgroundColor(android.graphics.Color.WHITE)
                    setTextColor(android.graphics.Color.parseColor("#E53935"))
                    setOnClickListener {
                        hideDistractionPopup()
                        // Optional: Launch MainActivity
                        val i = Intent(ctx, com.example.MainActivity::class.java)
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                    }
                }
                container.addView(title)
                container.addView(msg)
                container.addView(dismissBtn)
                
                floatingView = container
                windowManager?.addView(floatingView, layoutParams)
                isPopupShowing = true
            } catch(e: Exception) {
                e.printStackTrace()
            }
        }
    }
    
    private fun hideDistractionPopup() {
        if (!isPopupShowing) return
        launchMain {
            try {
                floatingView?.let { windowManager?.removeView(it) }
                floatingView = null
                isPopupShowing = false
            } catch(e: Exception) {
                e.printStackTrace()
            }
        }
    }
    
    private fun launchMain(block: () -> Unit) {
        android.os.Handler(android.os.Looper.getMainLooper()).post(block)
    }


    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val EXTRA_TASK_ID = "EXTRA_TASK_ID"
        const val EXTRA_TASK_NAME = "EXTRA_TASK_NAME"
        const val EXTRA_START_TIME = "EXTRA_START_TIME"
        const val EXTRA_END_TIME = "EXTRA_END_TIME"
        private const val CHANNEL_ID = "study_flow_running_channel"
        private const val NOTIFICATION_ID = 8888
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        sensorManager?.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        val taskId = intent?.getIntExtra(EXTRA_TASK_ID, -1) ?: -1
        val taskName = intent?.getStringExtra(EXTRA_TASK_NAME) ?: "Running Task"
        val startTime = intent?.getLongExtra(EXTRA_START_TIME, -1L) ?: -1L
        val endTime = intent?.getLongExtra(EXTRA_END_TIME, -1L) ?: -1L

        if (taskId == -1 || startTime == -1L || endTime == -1L) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification(taskId, taskName, startTime, endTime, false, false))
        
        lastTickTime = System.currentTimeMillis()
        realStudyTimeMs = 0L
        currentTaskId = taskId
        
        updateJob?.cancel()
        updateJob = scope.launch {
            // Load block to get study apps
            val db = DatabaseProvider.getDatabase(this@TaskForegroundService)
            val block = db.timeBlockDao().getBlockById(taskId)
            if (block != null) {
                studyAppsList = block.studyApps.split(",").filter { it.isNotEmpty() }
            }
            
            while (isActive) {
                delay(1000)
                val now = System.currentTimeMillis()
                val tickDuration = now - lastTickTime
                lastTickTime = now
                
                val foregroundApp = getForegroundApp()
                val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
                val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
                val isScreenOn = powerManager.isInteractive
                val isUnlocked = !keyguardManager.isKeyguardLocked
                val isDeviceActive = isScreenOn && isUnlocked

                val isStudying = if (studyAppsList.isEmpty()) {
                    isScreenDownAndStill
                } else {
                    isDeviceActive && foregroundApp != null && studyAppsList.contains(foregroundApp)
                }
                
                if (isStudying) {
                    hideDistractionPopup()
                    hasStartedStudying = true
                    realStudyTimeMs += tickDuration
                    if (foregroundApp != null) {
                        appUsageMap[foregroundApp] = (appUsageMap[foregroundApp] ?: 0L) + tickDuration
                    } else if (studyAppsList.isEmpty()) {
                        appUsageMap["Other"] = (appUsageMap["Other"] ?: 0L) + tickDuration
                    }
                    
                    val b = db.timeBlockDao().getBlockById(taskId)
                    if (b != null) {
                        db.timeBlockDao().updateBlock(b.copy(
                            status = "Running",
                            actualTimeTakenMs = (b.actualTimeTakenMs ?: 0L) + tickDuration
                        ))
                    }
                } else {
                    val b = db.timeBlockDao().getBlockById(taskId)
                    if (b != null && b.status == "Running") {
                        db.timeBlockDao().updateBlock(b.copy(status = "Paused"))
                    }
                    if (foregroundApp != null && foregroundApp != packageName && !foregroundApp.contains("launcher") && !foregroundApp.contains("systemui")) {
                        showDistractionPopup(foregroundApp)
                    }
                }
                
                if (now >= endTime) {
                    val finalBlock = db.timeBlockDao().getBlockById(taskId)
                    if (finalBlock != null) {
                        val finalStatus = if (realStudyTimeMs > 0) "Completed" else "Missed"
                        val json = JSONObject()
                        appUsageMap.forEach { (k, v) -> json.put(k, v) }
                        
                        db.timeBlockDao().updateBlock(finalBlock.copy(
                            status = finalStatus,
                            appUsageStatsJson = json.toString(),
                            completedOnMs = now
                        ))
                    }
                    hideDistractionPopup()
                    stopSelf()
                    break
                }
                
                val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.notify(NOTIFICATION_ID, buildNotification(taskId, taskName, startTime, endTime, isStudying, hasStartedStudying))
            }
        }

        return START_STICKY
    }

    @Suppress("DEPRECATION")
    private fun getForegroundApp(): String? {
        if (com.example.service.AppAccessibilityService.currentForegroundPackage != null) {
            return com.example.service.AppAccessibilityService.currentForegroundPackage
        }
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            @Suppress("DEPRECATION")
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        } else {
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        }
        if (mode != AppOpsManager.MODE_ALLOWED) return null
        
        val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val endTime = System.currentTimeMillis()
        val beginTime = endTime - 10000
        
        val usageEvents = usageStatsManager.queryEvents(beginTime, endTime)
        var foregroundPackage: String? = null
        val event = android.app.usage.UsageEvents.Event()
        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)
            if (event.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED) {
                foregroundPackage = event.packageName
            }
        }
        return foregroundPackage ?: packageName
    }

    private fun buildNotification(taskId: Int, taskName: String, startTime: Long, endTime: Long, isStudying: Boolean, hasStartedStudying: Boolean): android.app.Notification {
        val now = System.currentTimeMillis()
        val durationMs = endTime - startTime
        val elapsedMs = (now - startTime).coerceAtLeast(0L)
        val remainingMs = (endTime - now).coerceAtLeast(0L)
        
        val progress = if (durationMs > 0) (elapsedMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f
        val progressPercent = (progress * 100).toInt()
        
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val startStr = timeFormat.format(Date(startTime))
        val endStr = timeFormat.format(Date(endTime))
        
        val remainingStr = String.format(Locale.getDefault(), "%02d:%02d:%02d", remainingMs / 3600000, (remainingMs / 60000) % 60, (remainingMs / 1000) % 60)
        
        val mainIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(this, 0, mainIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val title = if (studyAppsList.isNotEmpty()) {
            if (!hasStartedStudying) "Waiting for Study App..."
            else if (isStudying) "Running: $taskName"
            else "Paused: Open a Study App"
        } else {
            "Running: $taskName"
        }
        
        val text = if (studyAppsList.isNotEmpty() && !hasStartedStudying) {
            "Open a selected study app to start timer."
        } else if (studyAppsList.isNotEmpty() && !isStudying) {
            "Tracker paused. Go back to study apps."
        } else {
            "Remaining: $remainingStr ($progressPercent%) | $startStr - $endStr"
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setProgress(100, progressPercent, false)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Running Tasks", NotificationManager.IMPORTANCE_DEFAULT)
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        sensorManager?.unregisterListener(this)
        hideDistractionPopup()
        super.onDestroy()
        updateJob?.cancel()
        
        if (currentTaskId != -1) {
            val db = DatabaseProvider.getDatabase(this)
            val tid = currentTaskId
            val time = realStudyTimeMs
            val finalStatus = if (realStudyTimeMs > 0) "Completed" else "Missed"
            
            val json = JSONObject()
            appUsageMap.forEach { (k, v) -> json.put(k, v) }
            val mapStr = json.toString()
            
            scope.launch {
                val block = db.timeBlockDao().getBlockById(tid)
                if (block != null && block.status != "Missed" && block.status != "Completed" && block.status != "Skipped") {
                    db.timeBlockDao().updateBlock(block.copy(
                        status = finalStatus,
                        appUsageStatsJson = mapStr,
                        completedOnMs = System.currentTimeMillis()
                    ))
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
