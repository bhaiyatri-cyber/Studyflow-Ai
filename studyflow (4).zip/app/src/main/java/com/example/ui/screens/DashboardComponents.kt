package com.example.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.util.Collections

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DashboardCard(modifier: Modifier = Modifier, title: String, icon: ImageVector, onClick: () -> Unit, onAction: () -> Unit, content: @Composable () -> Unit) {
    var showMenu by remember { mutableStateOf(false) }
    Card(
        modifier = modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onClick,
                onLongClick = { showMenu = true }
            )
            .shadow(4.dp, RoundedCornerShape(20.dp)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(16.dp))
            content()
            
            DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                DropdownMenuItem(text = { Text("Refresh") }, onClick = { showMenu = false })
                DropdownMenuItem(text = { Text("Edit Goal") }, onClick = { showMenu = false })
                DropdownMenuItem(text = { Text("Export Today's Report") }, onClick = { showMenu = false })
                DropdownMenuItem(text = { Text("Dashboard Settings") }, onClick = { showMenu = false })
            }
        }
    }
}

@Composable
fun QuickStatItem(label: String, value: String, icon: ImageVector, color: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.aspectRatio(0.85f),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.1f)),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(
            modifier = Modifier.padding(8.dp).fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = color, maxLines = 1)
            Spacer(modifier = Modifier.height(2.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

@Composable
fun CustomizeDashboardDialog(
    currentOrder: List<String>,
    currentEnabled: Map<String, Boolean>,
    onDismiss: () -> Unit,
    onSave: (List<String>, Map<String, Boolean>) -> Unit
) {
    var order by remember { mutableStateOf(currentOrder.toMutableList()) }
    var enabled by remember { mutableStateOf(currentEnabled.toMutableMap()) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Text("Customize Dashboard", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Drag up/down to reorder categories. Toggle to show/hide.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(modifier = Modifier.weight(1f)) {
                    itemsIndexed(order) { index, item ->
                        val isEnabled = enabled[item] ?: true
                        val title = item.replace("_", " ").replaceFirstChar { it.uppercase() }
                        
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Default.DragHandle, contentDescription = "Drag", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(4f))
                                Switch(
                                    checked = isEnabled,
                                    onCheckedChange = {
                                         enabled = enabled.toMutableMap().apply { put(item, it) }
                                    }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    if (index > 0) {
                                        IconButton(onClick = {
                                            val newOrder = order.toMutableList()
                                            Collections.swap(newOrder, index, index - 1)
                                            order = newOrder
                                        }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Up")
                                        }
                                    }
                                    if (index < order.size - 1) {
                                        IconButton(onClick = {
                                            val newOrder = order.toMutableList()
                                            Collections.swap(newOrder, index, index + 1)
                                            order = newOrder
                                        }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Down")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(onClick = { onSave(order, enabled) }) { Text("Save") }
                }
            }
        }
    }
}
