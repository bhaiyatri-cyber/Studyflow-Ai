package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.TimeBlock
import com.example.ui.viewmodel.StudyViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    viewModel: StudyViewModel,
    onNavigateToDetails: (TimeBlock) -> Unit,
) {
    val blocks by viewModel.allBlocks.collectAsState()
    
    val context = androidx.compose.ui.platform.LocalContext.current
    val is24HourFormat = android.text.format.DateFormat.is24HourFormat(context)
    val timeFormatStr = if (is24HourFormat) "HH:mm" else "hh:mm a"
    val timeFormat = SimpleDateFormat(timeFormatStr, Locale.getDefault())
    val dateFormat = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())
    
    val now = System.currentTimeMillis()
    val calendar = Calendar.getInstance()
    calendar.timeInMillis = now
    calendar.set(Calendar.HOUR_OF_DAY, 0)
    calendar.set(Calendar.MINUTE, 0)
    calendar.set(Calendar.SECOND, 0)
    val startOfToday = calendar.timeInMillis
    
    val historyBlocks = blocks.filter { it.startTimeMs < startOfToday }.sortedByDescending { it.startTimeMs }
    val groupedBlocks = historyBlocks.groupBy { 
        val c = Calendar.getInstance()
        c.timeInMillis = it.startTimeMs
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.timeInMillis
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("History", fontWeight = FontWeight.Bold) },
                actions = {
                },

                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        if (historyBlocks.isEmpty()) {
            Box(modifier = Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No history yet.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding).fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                groupedBlocks.forEach { (dateMs, blocksForDate) ->
                    item {
                        DateHistoryGroup(
                            dateMs = dateMs,
                            blocks = blocksForDate,
                            dateFormat = dateFormat,
                            timeFormat = timeFormat,
                            onNavigateToDetails = onNavigateToDetails
                        )
                    }
                }
                item { Spacer(modifier = Modifier.height(80.dp)) }
            }
        }
    }
}

@Composable
fun DateHistoryGroup(
    dateMs: Long,
    blocks: List<TimeBlock>,
    dateFormat: SimpleDateFormat,
    timeFormat: SimpleDateFormat,
    onNavigateToDetails: (TimeBlock) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha=0.3f))
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded }.padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(dateFormat.format(Date(dateMs)), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Icon(if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, contentDescription = null)
            }
            if (expanded) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    val now = System.currentTimeMillis()
                    blocks.forEach { originalBlock ->
                        val evaluatedStatus = com.example.util.ScheduleStatusEngine.calculateStatus(originalBlock, now)
                        val block = originalBlock.copy(status = evaluatedStatus)
                        val isMissedEvaluated = evaluatedStatus == "Missed" || (block.endTimeMs <= now && evaluatedStatus != "Completed" && evaluatedStatus != "Skipped" && evaluatedStatus != "Running")
                        
                        TaskCard(
                            block = block,
                            timeFormat = timeFormat,
                            isCompleted = evaluatedStatus == "Completed",
                            isMissed = isMissedEvaluated,
                            isSkipped = evaluatedStatus == "Skipped",
                            onClick = { onNavigateToDetails(block) },
                            onEdit = {},
                            onDelete = {},
                            onComplete = {},
                            onDuplicate = {}
                        )
                    }
                }
            }
        }
    }
}
