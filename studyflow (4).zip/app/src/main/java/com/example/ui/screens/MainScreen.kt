package com.example.ui.screens

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.viewmodel.StudyViewModel

@Composable
fun MainScreen(
    viewModel: StudyViewModel,
    onNavigateToAddBlock: () -> Unit,
    onNavigateToEditBlock: (Int) -> Unit,
    onNavigateToDetails: (Int) -> Unit,
    onNavigateToSettings: () -> Unit = {}
) {
    val navController = rememberNavController()
    
    Scaffold(
        bottomBar = {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = navBackStackEntry?.destination?.route
            
            NavigationBar {
                NavigationBarItem(
                    selected = currentRoute == "home",
                    onClick = { navController.navigate("home") { popUpTo("home") { inclusive = false } } },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") }
                )
                NavigationBarItem(
                    selected = currentRoute == "history",
                    onClick = { navController.navigate("history") { popUpTo("home") { inclusive = false } } },
                    icon = { Icon(Icons.Default.History, contentDescription = "History") },
                    label = { Text("History") }
                )
                NavigationBarItem(
                    selected = currentRoute == "progress",
                    onClick = { navController.navigate("progress") { popUpTo("home") { inclusive = false } } },
                    icon = { Icon(Icons.Default.PieChart, contentDescription = "Progress") },
                    label = { Text("Progress") }
                )
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(padding).consumeWindowInsets(padding)
        ) {
            composable("home") {
                HomeScreen(
                    viewModel = viewModel,
                    onNavigateToDetails = { onNavigateToDetails(it.id) },
                    onNavigateToAddBlock = onNavigateToAddBlock,
                    onNavigateToEditBlock = { onNavigateToEditBlock(it.id) },
                    onNavigateToSettings = onNavigateToSettings,
                    onNavigateToAutoSchedule = { navController.navigate("autoSchedule") },
                    onNavigateToAssistant = { navController.navigate("chat") },
                )
            }
            composable("history") {
                HistoryScreen(
                    viewModel = viewModel,
                    onNavigateToDetails = { onNavigateToDetails(it.id) }
                )
            }
            composable("autoSchedule") { AutoScheduleScreen(viewModel, { navController.popBackStack() }) }
            composable("chat") { ChatScreen(viewModel, { navController.popBackStack() }) }
            composable("progress") {
                ProgressScreen(viewModel = viewModel, onNavigateBack = {})
            }
        }
    }
}
