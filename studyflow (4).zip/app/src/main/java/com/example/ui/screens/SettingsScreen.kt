package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.ui.platform.LocalContext

import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import com.example.ui.viewmodel.StudyViewModel
import java.util.Collections
import androidx.compose.foundation.lazy.itemsIndexed

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onNavigateBack: () -> Unit, onNavigateToPermissions: () -> Unit, onNavigateToStudyApps: () -> Unit, onNavigateToDashboardCustomization: (() -> Unit)? = null, viewModel: StudyViewModel) {
    val stats by viewModel.stats.collectAsState()
    var showCustomizeDialog by remember { mutableStateOf(false) }
    
    val context = LocalContext.current
    val sharedPref = context.getSharedPreferences("dashboard_prefs", Context.MODE_PRIVATE)

    val defaultOrder = listOf(
        "goal", "ring", "streak", "running", "next", "summary", 
        "hours", "score", "subject", "app_usage", "weekly", "achievements"
    )

    var cardOrder by remember { 
        mutableStateOf(
            sharedPref.getString("card_order", defaultOrder.joinToString(","))!!.split(",")
        ) 
    }
    
    var cardEnabled by remember {
        mutableStateOf(
            defaultOrder.associateWith { sharedPref.getBoolean("card_enabled_$it", true) }
        )
    }

    if (showCustomizeDialog) {
        CustomizeDashboardDialog(
            currentOrder = cardOrder,
            currentEnabled = cardEnabled,
            onDismiss = { showCustomizeDialog = false },
            onSave = { newOrder, newEnabled ->
                cardOrder = newOrder
                cardEnabled = newEnabled
                sharedPref.edit().apply {
                    putString("card_order", newOrder.joinToString(","))
                    newEnabled.forEach { (k, v) -> putBoolean("card_enabled_$k", v) }
                }.apply()
                showCustomizeDialog = false
            }
        )
    }

    
    var showGoalDialog by remember { mutableStateOf(false) }
    var hourGoalStr by remember { mutableStateOf(stats?.dailyStudyHourGoal?.toString() ?: "4") }
    var taskGoalStr by remember { mutableStateOf(stats?.dailyTaskGoal?.toString() ?: "5") }

    if (showGoalDialog) {
        AlertDialog(
            onDismissRequest = { showGoalDialog = false },
            title = { Text("Daily Goals") },
            text = {
                Column {
                    OutlinedTextField(
                        value = hourGoalStr,
                        onValueChange = { hourGoalStr = it },
                        label = { Text("Study Hours Goal") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = taskGoalStr,
                        onValueChange = { taskGoalStr = it },
                        label = { Text("Tasks Completed Goal") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val hourGoal = hourGoalStr.toIntOrNull() ?: 4
                    val taskGoal = taskGoalStr.toIntOrNull() ?: 5
                    if (stats != null) {
                        viewModel.updateStats(stats!!.copy(dailyStudyHourGoal = hourGoal, dailyTaskGoal = taskGoal))
                    }
                    showGoalDialog = false
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showGoalDialog = false }) { Text("Cancel") }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings & About", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(padding).fillMaxSize().padding(horizontal = 16.dp)) {
            item { Spacer(modifier = Modifier.height(16.dp)) }
            item {
                Text("App Settings", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(8.dp))
                ListItem(
                    headlineContent = { Text("Daily Goals") },
                    supportingContent = { Text("Set your daily study hours and task goals") },
                    modifier = Modifier.clickable { showGoalDialog = true }
                )
                HorizontalDivider()
                val context = LocalContext.current
                val sharedPref = context.getSharedPreferences("studyflow_prefs", Context.MODE_PRIVATE)
                var popupMode by remember { mutableStateOf(sharedPref.getBoolean("popup_mode", false)) }
                ListItem(
                    headlineContent = { Text("Popup Mode") },
                    supportingContent = { Text("Show full-screen alerts for reminders") },
                    trailingContent = {
                        Switch(
                            checked = popupMode,
                            onCheckedChange = { isChecked ->
                                if (isChecked && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                                        data = Uri.parse("package:${context.packageName}")
                                    }
                                    context.startActivity(intent)
                                } else {
                                    popupMode = isChecked
                                    sharedPref.edit().putBoolean("popup_mode", isChecked).apply()
                                }
                            }
                        )
                    }
                )
                                HorizontalDivider()
                                ListItem(
                    headlineContent = { Text("Study Apps List") },
                    supportingContent = { Text("Select apps tracked for real study time") },
                    modifier = Modifier.clickable { onNavigateToStudyApps() }
                )
                HorizontalDivider()
                ListItem(
                    headlineContent = { Text("Customize Dashboard") },
                    supportingContent = { Text("Enable, hide, and reorder dashboard widgets") },
                    modifier = Modifier.clickable { showCustomizeDialog = true }
                )
                HorizontalDivider()
                ListItem(
                    headlineContent = { Text("Permissions & Deep Access") },
                    supportingContent = { Text("Manage required and optional permissions") },
                    modifier = Modifier.clickable { onNavigateToPermissions() }
                )
                HorizontalDivider()
            }
            
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Text("About", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(8.dp))
                ListItem(headlineContent = { Text("App Name") }, supportingContent = { Text("StudyFlow Premium") })
                HorizontalDivider()
                ListItem(headlineContent = { Text("Version") }, supportingContent = { Text("1.5.1.3") })
                HorizontalDivider()
                ListItem(headlineContent = { Text("Build Number") }, supportingContent = { Text("1513") })
                HorizontalDivider()
                
                var lastUpdateTime by remember { mutableStateOf(0L) }
                val pkgContext = LocalContext.current
                LaunchedEffect(Unit) {
                    try {
                        val packageInfo = pkgContext.packageManager.getPackageInfo(pkgContext.packageName, 0)
                        lastUpdateTime = packageInfo.lastUpdateTime
                    } catch (e: Exception) {}
                }
                
                var now by remember { mutableStateOf(System.currentTimeMillis()) }
                LaunchedEffect(Unit) {
                    while(true) {
                        now = System.currentTimeMillis()
                        kotlinx.coroutines.delay(1000)
                    }
                }
                
                val diff = now - lastUpdateTime
                val minutes = diff / (60 * 1000)
                val hours = diff / (60 * 60 * 1000)
                val days = diff / (24 * 60 * 60 * 1000)
                
                val relativeTime = when {
                    lastUpdateTime == 0L -> "Unknown"
                    days > 1 -> "$days days ago"
                    days == 1L -> "1 day ago"
                    hours > 1 -> "$hours hours ago"
                    hours == 1L -> "1 hour ago"
                    minutes > 1 -> "$minutes minutes ago"
                    minutes == 1L -> "1 minute ago"
                    else -> "Just now"
                }

                ListItem(headlineContent = { Text("Last Updated") }, supportingContent = { Text(relativeTime) })
                HorizontalDivider()
                ListItem(headlineContent = { Text("What's New") }, supportingContent = { Text("- App optimizations\n- Bug fixes\n- Enhanced timer\n- UI improvements") })
                HorizontalDivider()
                ListItem(headlineContent = { Text("Privacy Policy") }, modifier = Modifier.clickable { })
                HorizontalDivider()
                ListItem(headlineContent = { Text("Terms of Use") }, modifier = Modifier.clickable { })
                HorizontalDivider()
                ListItem(headlineContent = { Text("Report Bug") }, modifier = Modifier.clickable { })
                HorizontalDivider()
                ListItem(headlineContent = { Text("Send Feedback") }, modifier = Modifier.clickable { })
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}
