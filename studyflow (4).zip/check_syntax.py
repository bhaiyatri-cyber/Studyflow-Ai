with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    text = f.read()

def check(char_open, char_close):
    count = 0
    in_string = False
    escape = False
    for i, char in enumerate(text):
        if escape:
            escape = False
            continue
        if char == '\\':
            escape = True
            continue
        if char == '"' and not in_string:
            in_string = True
            continue
        if char == '"' and in_string:
            in_string = False
            continue
            
        if not in_string:
            if char == char_open:
                count += 1
            elif char == char_close:
                count -= 1
    return count

print("() balance:", check('(', ')'))
print("[] balance:", check('[', ']'))
print("{} balance:", check('{', '}'))
