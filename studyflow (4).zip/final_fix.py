import re

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'r') as f:
    content = f.read()

content = content.replace("Icons.AutoMirrored.Filled.TrendingUp", "Icons.Default.TrendingUp")
content = content.replace("Icons.AutoMirrored.Filled.DirectionsWalk", "Icons.Default.DirectionsWalk")
content = content.replace("Icons.AutoMirrored.Filled.ArrowBack", "Icons.Default.ArrowBack")
content = content.replace("Icons.AutoMirrored.Filled.KeyboardArrowLeft", "Icons.Default.KeyboardArrowLeft")
content = content.replace("Icons.AutoMirrored.Filled.KeyboardArrowRight", "Icons.Default.KeyboardArrowRight")

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'w') as f:
    f.write(content)
