import sys

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "r") as f:
    lines = f.readlines()

count = 0
for i, line in enumerate(lines):
    if i < 96: continue # skip to fun HomeScreen
    for char in line:
        if char == '{': count += 1
        elif char == '}': count -= 1
    
    if count == 0 and i >= 96:
        print(f"HomeScreen ends at line {i+1}")
        break
