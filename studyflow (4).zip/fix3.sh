sed -i 's/                    Card(/                item {\n                    Card(/g' app/src/main/java/com/example/ui/screens/HomeScreen.kt
