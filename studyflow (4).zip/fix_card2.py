import re
with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "r") as f:
    content = f.read()

target = """            val timeStudiedMs = if (isCurrentCompleted) {
                block.actualTimeTakenMs ?: durationMs
            } else if (isCurrentRunning) {
                currentNow - block.startTimeMs
            } else {
                0L
            }"""

replacement = """            val timeStudiedMs = block.actualTimeTakenMs ?: 0L"""

if target in content:
    content = content.replace(target, replacement)
    print("Replaced timeStudiedMs")

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "w") as f:
    f.write(content)
