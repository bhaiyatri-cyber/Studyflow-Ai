import re

with open('app/src/main/java/com/example/ui/screens/ProgressScreen.kt', 'r') as f:
    content = f.read()

# Add missing imports
imports = [
    "import androidx.compose.foundation.horizontalScroll",
    "import androidx.compose.foundation.rememberScrollState"
]
for imp in imports:
    if imp not in content:
        content = content.replace("import androidx.compose.foundation.layout.*", f"import androidx.compose.foundation.layout.*\n{imp}")

# Fix premiumSkyBlueContainer
content = content.replace("premiumSkyBlueContainer", "MaterialTheme.colorScheme.primaryContainer")

# Fix Icons.AutoMirrored.Filled.TrendingUp -> Icons.Default.TrendingUp
content = content.replace("Icons.AutoMirrored.Filled.TrendingUp", "Icons.Default.TrendingUp")
content = content.replace("Icons.AutoMirrored.Filled.DirectionsWalk", "Icons.Default.DirectionsWalk")

# Fix premiumSkyBlue missing in some scopes
# Just define premiumSkyBlue globally at the top of the file!
content = content.replace(
    "@OptIn(ExperimentalMaterial3Api::class)",
    "val premiumSkyBlue = Color(0xFF38BDF8)\n\n@OptIn(ExperimentalMaterial3Api::class)"
)
# And remove the local definitions to avoid hiding
content = content.replace("val premiumSkyBlue = Color(0xFF38BDF8)", "")
content = content.replace("val premiumSkyBlue\n", "")

# Fix @Composable invocations in item { ... }
# What was the exact error? line 561: "@Composable invocations can only happen from the context of a @Composable function"
# Let's find line 561
