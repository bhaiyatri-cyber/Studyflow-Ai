import re
with open("app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt", "r") as f:
    content = f.read()

target = """    val timeStudiedMs = if (isCompleted) {
        block.actualTimeTakenMs ?: durationMs
    } else if (isRunning) {
        now - block.startTimeMs
    } else {
        0L
    }"""

replacement = """    val timeStudiedMs = block.actualTimeTakenMs ?: 0L"""

if target in content:
    content = content.replace(target, replacement)
    print("Replaced timeStudiedMs in details")

with open("app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt", "w") as f:
    f.write(content)
