import re
with open("app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt", "r") as f:
    content = f.read()

target = """    if (block == null) {
        Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }"""

replacement = """    if (block == null) {
        LaunchedEffect(Unit) {
            onNavigateBack()
        }
        Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background))
        return
    }"""

if target in content:
    content = content.replace(target, replacement)
    print("Replaced null block handling in Details")

with open("app/src/main/java/com/example/ui/screens/TaskDetailsScreen.kt", "w") as f:
    f.write(content)
