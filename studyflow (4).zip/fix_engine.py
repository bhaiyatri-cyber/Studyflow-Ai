import re
with open("app/src/main/java/com/example/util/ScheduleStatusEngine.kt", "r") as f:
    content = f.read()

content = content.replace('        if (currentTimestampMs >= block.endTimeMs) {\n            return "Completed"\n        }', '        if (currentTimestampMs >= block.endTimeMs) {\n            return "Missed"\n        }')

with open("app/src/main/java/com/example/util/ScheduleStatusEngine.kt", "w") as f:
    f.write(content)
