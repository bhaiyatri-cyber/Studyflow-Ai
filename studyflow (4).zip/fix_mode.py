import re
with open("app/src/main/java/com/example/ui/screens/AddEditBlockScreen.kt", "r") as f:
    content = f.read()

target = """            Spacer(modifier = Modifier.height(24.dp))
            
            Text("Study Applications", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedCard(modifier = Modifier.fillMaxWidth().clickable { showAppSelection = true }) {"""

replacement = """            Spacer(modifier = Modifier.height(24.dp))
            
            Text("Study Mode", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            var studyMode by remember { mutableStateOf(if (block?.studyApps?.isEmpty() == true) "Offline" else "Online") }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = studyMode == "Online",
                    onClick = { studyMode = "Online" },
                    label = { Text("Online / App Tracking") },
                    leadingIcon = { Icon(Icons.Default.Apps, contentDescription = null) }
                )
                FilterChip(
                    selected = studyMode == "Offline",
                    onClick = { studyMode = "Offline"; selectedApps = emptySet() },
                    label = { Text("Offline / Face-Down") },
                    leadingIcon = { Icon(Icons.Default.PhoneAndroid, contentDescription = null) }
                )
            }
            
            if (studyMode == "Online") {
                Spacer(modifier = Modifier.height(16.dp))
                Text("Study Applications", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedCard(modifier = Modifier.fillMaxWidth().clickable { showAppSelection = true }) {"""

if target in content:
    content = content.replace(target, replacement)
    print("Replaced Study Applications section 1")

target2 = """                    Button(onClick = { showAppSelection = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Select Apps")
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))"""

replacement2 = """                    Button(onClick = { showAppSelection = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Select Apps")
                    }
                }
            }
            } else {
                Spacer(modifier = Modifier.height(8.dp))
                Text("In Offline Mode, simply place your phone face-down on a flat surface. The timer will pause if you lift or use your phone.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            
            Spacer(modifier = Modifier.height(24.dp))"""

if target2 in content:
    content = content.replace(target2, replacement2)
    print("Replaced Study Applications section 2")

with open("app/src/main/java/com/example/ui/screens/AddEditBlockScreen.kt", "w") as f:
    f.write(content)
