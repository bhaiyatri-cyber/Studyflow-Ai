import re
with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "r") as f:
    content = f.read()

target = """                                            val completedMs = todaysBlocks.filter { it.status == "Completed" }.sumOf { it.endTimeMs - it.startTimeMs }
                                            val runningMs = todaysBlocks.filter { it.status == "Running" }.sumOf { (liveNow - it.startTimeMs).coerceIn(0L, it.endTimeMs - it.startTimeMs) }"""

replacement = """                                            val completedMs = todaysBlocks.filter { it.status == "Completed" }.sumOf { it.actualTimeTakenMs ?: 0L }
                                            val runningMs = todaysBlocks.filter { it.status == "Running" || it.status == "Paused" }.sumOf { it.actualTimeTakenMs ?: 0L }"""

if target in content:
    content = content.replace(target, replacement)
    print("Replaced todays progress calculation")

with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "w") as f:
    f.write(content)
