import os

code = """package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.StudyViewModel
import com.example.data.model.TimeBlock
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen(
    viewModel: StudyViewModel,
    onNavigateBack: () -> Unit
) {
    val allBlocks by viewModel.allBlocks.collectAsState()
    
    val now = System.currentTimeMillis()
    val evaluatedBlocks = allBlocks.map { block ->
        block.copy(status = com.example.util.ScheduleStatusEngine.calculateStatus(block, now))
    }
    
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("This Year") } // Today, This Week, This Month, This Year, Custom
    var currentYear by remember { mutableStateOf(Calendar.getInstance().get(Calendar.YEAR)) }
    
    var selectedDate by remember { mutableStateOf<Long?>(null) }
    var selectedDayBlocks by remember { mutableStateOf<List<TimeBlock>>(emptyList()) }
    var showCustomDateDialog by remember { mutableStateOf(false) }
    
    val calendar = Calendar.getInstance()
    calendar.timeInMillis = now
    calendar.set(Calendar.HOUR_OF_DAY, 0)
    calendar.set(Calendar.MINUTE, 0)
    calendar.set(Calendar.SECOND, 0)
    calendar.set(Calendar.MILLISECOND, 0)
    val startOfToday = calendar.timeInMillis

    // Parsing search query logic
    val parsedSearchStartEnd = remember(searchQuery) {
        if (searchQuery.isBlank()) null
        else {
            try {
                // Try DD/MM/YYYY
                if (searchQuery.matches(Regex("\\\\d{1,2}/\\\\d{1,2}/\\\\d{4}"))) {
                    val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                    val d = sdf.parse(searchQuery)
                    if (d != null) Pair(d.time, d.time + 24*3600*1000L - 1) else null
                } else if (searchQuery.matches(Regex("\\\\d{4}"))) {
                    val y = searchQuery.toInt()
                    val c = Calendar.getInstance()
                    c.set(y, 0, 1, 0, 0, 0)
                    val s = c.timeInMillis
                    c.set(y, 11, 31, 23, 59, 59)
                    Pair(s, c.timeInMillis)
                } else {
                    // Try parsing as month name
                    val sdf = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
                    try {
                        val d = sdf.parse(searchQuery)
                        if (d != null) {
                            val c = Calendar.getInstance()
                            c.timeInMillis = d.time
                            val s = c.timeInMillis
                            c.add(Calendar.MONTH, 1)
                            c.add(Calendar.MILLISECOND, -1)
                            Pair(s, c.timeInMillis)
                        } else null
                    } catch (e: Exception) { null }
                }
            } catch (e: Exception) { null }
        }
    }
    
    val filteredBlocks = remember(selectedFilter, currentYear, evaluatedBlocks, parsedSearchStartEnd) {
        if (parsedSearchStartEnd != null) {
            evaluatedBlocks.filter { it.startTimeMs in parsedSearchStartEnd.first..parsedSearchStartEnd.second }
        } else {
            val c = Calendar.getInstance()
            c.timeInMillis = startOfToday
            when (selectedFilter) {
                "Today" -> evaluatedBlocks.filter { it.startTimeMs >= startOfToday && it.startTimeMs < startOfToday + 24*3600*1000L }
                "This Week" -> {
                    c.set(Calendar.DAY_OF_WEEK, c.firstDayOfWeek)
                    val startOfWeek = c.timeInMillis
                    evaluatedBlocks.filter { it.startTimeMs >= startOfWeek }
                }
                "This Month" -> {
                    c.set(Calendar.DAY_OF_MONTH, 1)
                    val startOfMonth = c.timeInMillis
                    evaluatedBlocks.filter { it.startTimeMs >= startOfMonth }
                }
                "This Year" -> {
                    c.set(currentYear, 0, 1, 0, 0, 0)
                    val startOfYear = c.timeInMillis
                    c.set(currentYear, 11, 31, 23, 59, 59)
                    val endOfYear = c.timeInMillis
                    evaluatedBlocks.filter { it.startTimeMs in startOfYear..endOfYear }
                }
                else -> evaluatedBlocks
            }
        }
    }

    // Heatmap Generation for the currently selected year
    val heatmapData = remember(currentYear, evaluatedBlocks) {
        val data = mutableListOf<HeatmapDay>()
        val cal = Calendar.getInstance()
        cal.set(currentYear, 0, 1, 0, 0, 0)
        cal.set(Calendar.MILLISECOND, 0)
        
        // Find the first Sunday before Jan 1st (if Jan 1 is not Sunday) to pad the grid
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
        if (dayOfWeek != Calendar.SUNDAY) {
            cal.add(Calendar.DAY_OF_YEAR, -(dayOfWeek - Calendar.SUNDAY))
        }
        
        val maxDays = 371 // 53 weeks * 7
        for (i in 0 until maxDays) {
            val dStart = cal.timeInMillis
            val dEnd = dStart + 24*3600*1000L - 1
            
            val dayBlocks = evaluatedBlocks.filter { it.startTimeMs in dStart..dEnd && it.status == "Completed" }
            val time = dayBlocks.sumOf { it.actualTimeTakenMs ?: (it.endTimeMs - it.startTimeMs) }
            val intensity = when {
                time == 0L -> 0
                time < 1 * 3600 * 1000L -> 1
                time < 2 * 3600 * 1000L -> 2
                time < 4 * 3600 * 1000L -> 3
                else -> 4
            }
            data.add(HeatmapDay(dStart, intensity, time, cal.get(Calendar.MONTH), cal.get(Calendar.YEAR)))
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        data
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Progress & Analytics", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Search and Filters
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { 
                        searchQuery = it
                        if (it.isNotEmpty()) selectedDate = null
                    },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search DD/MM/YYYY, YYYY...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = null)
                            }
                        }
                    },
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    )
                )
                Spacer(modifier = Modifier.height(16.dp))
                ScrollableTabRow(
                    selectedTabIndex = listOf("Today", "This Week", "This Month", "This Year", "Custom").indexOf(selectedFilter).coerceAtLeast(0),
                    edgePadding = 0.dp,
                    containerColor = Color.Transparent,
                    divider = {}
                ) {
                    listOf("Today", "This Week", "This Month", "This Year", "Custom").forEach { filter ->
                        FilterChip(
                            selected = selectedFilter == filter && searchQuery.isEmpty(),
                            onClick = { 
                                selectedFilter = filter
                                searchQuery = ""
                                selectedDate = null
                            },
                            label = { Text(filter) },
                            modifier = Modifier.padding(end = 8.dp)
                        )
                    }
                }
            }
            
            // GitHub-style Calendar Heatmap
            if (searchQuery.isEmpty() && (selectedFilter == "This Year" || selectedFilter == "Custom")) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(24.dp)),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("Study Heatmap", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { currentYear--; selectedDate = null }) {
                                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Previous Year")
                                    }
                                    Text("$currentYear", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    IconButton(onClick = { currentYear++; selectedDate = null }) {
                                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next Year")
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            
                            GitHubHeatmap(heatmapData, currentYear) { day ->
                                selectedDate = day.dateMs
                                val dStart = day.dateMs
                                val dEnd = dStart + (24 * 60 * 60 * 1000L) - 1
                                selectedDayBlocks = evaluatedBlocks.filter { it.startTimeMs in dStart..dEnd }
                            }
                            
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                                Text("Less", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.width(4.dp))
                                val colors = listOf(
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                                    MaterialTheme.colorScheme.primary
                                )
                                colors.forEach { color ->
                                    Box(modifier = Modifier.padding(2.dp).size(12.dp).clip(RoundedCornerShape(2.dp)).background(color))
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("More", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
            
            // Selected Date Analytics OR Aggregate Analytics
            item {
                val title = if (selectedDate != null) {
                    SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault()).format(Date(selectedDate!!))
                } else if (searchQuery.isNotEmpty()) {
                    "Search Results"
                } else {
                    "$selectedFilter Overview"
                }
                
                val blocksToShow = if (selectedDate != null) selectedDayBlocks else filteredBlocks
                
                val completed = blocksToShow.count { it.status == "Completed" }
                val missed = blocksToShow.count { it.status == "Missed" }
                val totalTimeMs = blocksToShow.filter { it.status == "Completed" }.sumOf { it.actualTimeTakenMs ?: (it.endTimeMs - it.startTimeMs) }
                
                val focusScore = if (completed + missed > 0) ((completed.toFloat() / (completed + missed)) * 100).toInt() else 0
                
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                    MiniStat("Completed", "$completed")
                    MiniStat("Missed", "$missed")
                    MiniStat("Hours", String.format("%.1f", totalTimeMs / 3600000f))
                    MiniStat("Focus Score", "$focusScore%")
                }
                
                Spacer(modifier = Modifier.height(24.dp))
                
                if (selectedDate != null || searchQuery.isNotEmpty() || selectedFilter == "Today") {
                    Text(if (selectedDate != null) "Tasks & Notes" else "Recent Tasks", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    if (blocksToShow.isEmpty()) {
                        Text("No tasks found.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        blocksToShow.take(10).forEach { block -> // Show max 10 to avoid huge lists in search
                            val color = if (block.status == "Completed") MaterialTheme.colorScheme.primary else if (block.status == "Missed") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha=0.3f))
                            ) {
                                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(color))
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column {
                                        Text(block.title, fontWeight = FontWeight.Bold)
                                        Text("${block.subject} • ${block.status}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                        if (blocksToShow.size > 10) {
                            Text("... and ${blocksToShow.size - 10} more", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

data class HeatmapDay(val dateMs: Long, val intensity: Int, val timeMs: Long, val month: Int, val year: Int)

@Composable
fun GitHubHeatmap(data: List<HeatmapDay>, currentYear: Int, onDayClick: (HeatmapDay) -> Unit) {
    val scrollState = rememberScrollState()
    val primary = MaterialTheme.colorScheme.primary
    val boxSize = 12.dp
    val spacing = 4.dp
    
    // Create columns of weeks (7 days each)
    val weeks = data.chunked(7)
    
    // Month labels logic
    val months = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    
    Column(modifier = Modifier.fillMaxWidth().horizontalScroll(scrollState)) {
        // Months Header
        Row(modifier = Modifier.padding(start = 24.dp, bottom = 4.dp)) {
            var lastMonth = -1
            weeks.forEach { week ->
                val dayInYear = week.firstOrNull { it.year == currentYear }
                if (dayInYear != null && dayInYear.month != lastMonth && week.first().month == dayInYear.month) {
                    Text(
                        text = months[dayInYear.month],
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.width((boxSize + spacing) * (4.2f))
                    )
                    lastMonth = dayInYear.month
                } else {
                    Spacer(modifier = Modifier.width(boxSize + spacing))
                }
            }
        }
        
        Row {
            // Days of Week Labels
            Column(modifier = Modifier.padding(end = 8.dp, top = 2.dp), verticalArrangement = Arrangement.spacedBy(spacing)) {
                listOf("Mon", "Wed", "Fri").forEach { day ->
                    Text(day, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.height(boxSize))
                    if (day != "Fri") Spacer(modifier = Modifier.height(boxSize + spacing))
                }
            }
            
            // Grid
            Row(horizontalArrangement = Arrangement.spacedBy(spacing)) {
                weeks.forEach { week ->
                    Column(verticalArrangement = Arrangement.spacedBy(spacing)) {
                        week.forEach { day ->
                            val isCurrentYear = day.year == currentYear
                            val color = if (!isCurrentYear) Color.Transparent else when (day.intensity) {
                                0 -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                                1 -> primary.copy(alpha = 0.3f)
                                2 -> primary.copy(alpha = 0.6f)
                                3 -> primary.copy(alpha = 0.8f)
                                else -> primary
                            }
                            Box(
                                modifier = Modifier
                                    .size(boxSize)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(color)
                                    .clickable(enabled = isCurrentYear) { onDayClick(day) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MiniStat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
"""

with open("app/src/main/java/com/example/ui/screens/ProgressScreen.kt", "w", encoding="utf-8") as f:
    f.write(code)

