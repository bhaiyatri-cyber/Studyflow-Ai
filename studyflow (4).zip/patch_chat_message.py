import sys

with open("app/src/main/java/com/example/api/GeminiApi.kt", "r") as f:
    content = f.read()

if "@JsonClass(generateAdapter = true)\ndata class ChatMessage" not in content:
    content = content.replace("data class ChatMessage(", "@JsonClass(generateAdapter = true)\ndata class ChatMessage(")

with open("app/src/main/java/com/example/api/GeminiApi.kt", "w") as f:
    f.write(content)
