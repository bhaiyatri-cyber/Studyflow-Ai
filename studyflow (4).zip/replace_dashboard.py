import re

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

start_marker = "                // Premium Single-Card Carousel"
end_marker = "                if (currentTask != null) {"

start_idx = content.find(start_marker)
end_idx = content.find(end_marker, start_idx)

old_carousel = content[start_idx:end_idx]

new_dashboard = """                // Smart Dashboard Container
                val smartCards = mutableListOf<String>()
                smartCards.add("streak")
                smartCards.add("progress")
                smartCards.add("study_time")
                if (currentTask != null) smartCards.add("running")
                if (nextTask != null) smartCards.add("next")
                smartCards.add("score")
                
                if (smartCards.isNotEmpty()) {
                    item(key = "smart_dashboard_container") {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        ) {
                            val pagerState = rememberPagerState(pageCount = { smartCards.size })
                            var isTouched by remember { mutableStateOf(false) }

                            // Auto-slide effect
                            if (smartCards.size > 1) {
                                LaunchedEffect(smartCards.size, isTouched) {
                                    while (true) {
                                        kotlinx.coroutines.delay(5000)
                                        if (!isTouched && !pagerState.isScrollInProgress) {
                                            val nextPage = (pagerState.currentPage + 1) % smartCards.size
                                            pagerState.animateScrollToPage(nextPage)
                                        }
                                    }
                                }
                            }

                            HorizontalPager(
                                state = pagerState,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .pointerInput(Unit) {
                                        awaitPointerEventScope {
                                            while (true) {
                                                val event = awaitPointerEvent()
                                                if (event.type == androidx.compose.ui.input.pointer.PointerEventType.Press) {
                                                    isTouched = true
                                                } else if (event.type == androidx.compose.ui.input.pointer.PointerEventType.Release) {
                                                    isTouched = false
                                                }
                                            }
                                        }
                                    }
                            ) { pageIndex ->
                                val cardId = smartCards[pageIndex]
                                val currentStreak = stats?.currentStreak ?: 0
                                val weeklyScore = stats?.weeklyScore ?: 0
                                
                                when (cardId) {
                                    "streak" -> {
                                        PremiumDashboardCard(
                                            title = "Daily Focus Streak",
                                            icon = Icons.Default.LocalFireDepartment,
                                            iconColor = Color(0xFF38BDF8)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "$currentStreak",
                                                    style = MaterialTheme.typography.displayMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White
                                                )
                                                Spacer(modifier = Modifier.width(16.dp))
                                                Text(
                                                    text = "days in a row.\\nKeep the momentum going!",
                                                    style = MaterialTheme.typography.bodyLarge,
                                                    color = Color.White.copy(alpha = 0.7f)
                                                )
                                            }
                                        }
                                    }
                                    "progress" -> {
                                        PremiumDashboardCard(
                                            title = "Today's Progress",
                                            icon = Icons.Default.CheckCircle,
                                            iconColor = Color(0xFF38BDF8)
                                        ) {
                                            val completionRate = if (todaysBlocks.isNotEmpty()) completedBlocks.size.toFloat() / todaysBlocks.size.toFloat() else 0f
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = "${(completionRate * 100).toInt()}% Done",
                                                        style = MaterialTheme.typography.displaySmall,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFF38BDF8)
                                                    )
                                                    Text(
                                                        text = "${completedBlocks.size} of ${todaysBlocks.size} tasks finished",
                                                        style = MaterialTheme.typography.bodyLarge,
                                                        color = Color.White.copy(alpha = 0.7f)
                                                    )
                                                }
                                                CircularProgressIndicator(
                                                    progress = { completionRate },
                                                    modifier = Modifier.size(72.dp),
                                                    color = Color(0xFF38BDF8),
                                                    strokeWidth = 6.dp,
                                                    trackColor = Color.White.copy(alpha = 0.1f)
                                                )
                                            }
                                        }
                                    }
                                    "study_time" -> {
                                        PremiumDashboardCard(
                                            title = "Study Time Today",
                                            icon = Icons.Default.Timer,
                                            iconColor = Color(0xFF38BDF8)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = String.format(Locale.US, "%.1f", todayStudyHours),
                                                    style = MaterialTheme.typography.displayMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White
                                                )
                                                Text(
                                                    text = " hours",
                                                    style = MaterialTheme.typography.titleLarge,
                                                    color = Color(0xFF38BDF8),
                                                    modifier = Modifier.padding(top = 12.dp)
                                                )
                                                Spacer(modifier = Modifier.width(16.dp))
                                                Text(
                                                    text = "Dedicated to\\nlearning.",
                                                    style = MaterialTheme.typography.bodyLarge,
                                                    color = Color.White.copy(alpha = 0.7f)
                                                )
                                            }
                                        }
                                    }
                                    "running" -> {
                                        PremiumDashboardCard(
                                            title = "Running Task",
                                            icon = Icons.Default.PlayCircleFilled,
                                            iconColor = Color(0xFF38BDF8),
                                            onClick = { currentTask?.let { onNavigateToDetails(it) } }
                                        ) {
                                            Column {
                                                Text(
                                                    text = currentTask?.subject ?: "No task",
                                                    style = MaterialTheme.typography.headlineSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White
                                                )
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.Schedule, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        "Focusing right now...",
                                                        style = MaterialTheme.typography.bodyMedium,
                                                        color = Color(0xFF38BDF8)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    "next" -> {
                                        PremiumDashboardCard(
                                            title = "Next Task",
                                            icon = Icons.Default.SkipNext,
                                            iconColor = Color(0xFF38BDF8),
                                            onClick = { nextTask?.let { onNavigateToDetails(it) } }
                                        ) {
                                            Column {
                                                Text(
                                                    text = nextTask?.subject ?: "No task",
                                                    style = MaterialTheme.typography.headlineSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White
                                                )
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.Schedule, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        if (nextTask != null) "${timeFormat.format(Date(nextTask.startTimeMs))} - ${timeFormat.format(Date(nextTask.endTimeMs))}" else "Upcoming",
                                                        style = MaterialTheme.typography.bodyMedium,
                                                        color = Color.White.copy(alpha = 0.7f)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    "score" -> {
                                        PremiumDashboardCard(
                                            title = "Performance Score",
                                            icon = Icons.Default.EmojiEvents,
                                            iconColor = Color(0xFF38BDF8)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = "$weeklyScore",
                                                        style = MaterialTheme.typography.displaySmall,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFF38BDF8)
                                                    )
                                                    Text(
                                                        text = "Weekly XP",
                                                        style = MaterialTheme.typography.bodyLarge,
                                                        color = Color.White.copy(alpha = 0.7f)
                                                    )
                                                }
                                                Icon(
                                                    Icons.Default.EmojiEvents,
                                                    contentDescription = null,
                                                    tint = Color(0xFF38BDF8),
                                                    modifier = Modifier.size(72.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            
                            // Page indicators below the card
                            if (smartCards.size > 1) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    repeat(smartCards.size) { iteration ->
                                        val isSelected = pagerState.currentPage == iteration
                                        val size = if (isSelected) 8.dp else 6.dp
                                        val color = if (isSelected) Color(0xFF38BDF8) else Color(0xFF38BDF8).copy(alpha = 0.3f)
                                        Box(
                                            modifier = Modifier
                                                .padding(horizontal = 4.dp)
                                                .clip(CircleShape)
                                                .background(color)
                                                .size(size)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                
"""

content = content.replace(old_carousel, new_dashboard)

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)

