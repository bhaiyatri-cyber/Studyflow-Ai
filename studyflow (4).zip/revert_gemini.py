import sys

with open("app/src/main/java/com/example/api/GeminiApi.kt", "r") as f:
    content = f.read()

content = content.replace(
    "suspend fun generateAiResponse(prompt: String, history: List<ChatMessage>, contextData: String = \"\"): String = withContext(Dispatchers.IO) {",
    "suspend fun generateAiResponse(prompt: String, history: List<ChatMessage>): String = withContext(Dispatchers.IO) {"
)

# We can just match `val systemInstruction = ...` since it's one line
import re
content = re.sub(
    r'val systemInstruction = Content\(parts = listOf\(Part\(text = "You are Flow X AI, a central assistant for StudyFlow.*"\)\)\)',
    'val systemInstruction = Content(parts = listOf(Part(text = "You are Flow X AI, a helpful AI assistant for the StudyFlow app. You help students with their studies, exams, Maths, Reasoning, English, Hindi, GK, Science, Computer, notes, revision and general questions. Be concise and friendly.")))',
    content
)

with open("app/src/main/java/com/example/api/GeminiApi.kt", "w") as f:
    f.write(content)
