with open("app/src/main/java/com/example/ui/screens/HomeScreen.kt", "r") as f:
    lines = f.readlines()

part1 = lines[:891]
part2 = lines[891:1274]
part3 = lines[1274:1873]
part4 = lines[1873:]

print("Part 1 last line:", part1[-1].strip())
print("Part 2 first line:", part2[0].strip())
print("Part 2 last line:", part2[-1].strip())
print("Part 3 first line:", part3[0].strip())
print("Part 3 last line:", part3[-1].strip())
print("Part 4 first line:", part4[0].strip())

