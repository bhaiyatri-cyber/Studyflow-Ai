#!/bin/bash
cat << 'INNER' > app/src/main/java/com/example/util/LocalAssistant.kt
package com.example.util

import com.example.data.model.TimeBlock
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

data class AssistantResponse(val text: String, val chips: List<String>)

object LocalAssistant {
    fun processQuery(query: String, blocks: List<TimeBlock>, userName: String?): AssistantResponse {
        val q = query.lowercase(Locale.getDefault())
        
        val now = System.currentTimeMillis()
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = now
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        val startOfToday = calendar.timeInMillis
        val endOfToday = startOfToday + 24 * 60 * 60 * 1000L
        
        val todayBlocks = blocks.filter { it.startTimeMs in startOfToday until endOfToday }
        
        val namePrefix = if (!userName.isNullOrBlank()) "$userName, " else ""
        
        // A. GREETING INTENTS
        if (matchesAny(q, listOf("hello", "hi", "hey", "namaste", "good morning", "good afternoon", "good evening", "good night"))) {
            return AssistantResponse(
                text = "Hello ${userName ?: "👋"}\nAaj ki study ke baare me kya jaanna chahoge?",
                chips = listOf("Aaj ki progress", "Aaj ka schedule")
            )
        }
        
        // B. TODAY STUDY INTENTS
        if (matchesAny(q, listOf("how much did i study today", "today study time", "aaj kitna padha", "aaj kitna pdha", "today study kitni hui", "aaj kitni study hui", "what is my today study time", "today actual study", "today learning hours"))) {
            val totalTimeMs = todayBlocks.filter { it.status == "Completed" }.sumOf { it.actualTimeTakenMs ?: (it.endTimeMs - it.startTimeMs) }
            if (totalTimeMs == 0L) {
                return AssistantResponse(
                    text = "Aaj abhi koi study time record nahi hua hai.",
                    chips = listOf("Aaj ka schedule", "Today progress")
                )
            }
            val hours = totalTimeMs / 3600000
            val mins = (totalTimeMs % 3600000) / 60000
            val timeText = if (hours > 0) "$hours ghante $mins minute" else "$mins minute"
            return AssistantResponse(
                text = "${namePrefix}aaj aapne $timeText actual study ki hai.",
                chips = listOf("Aaj ki progress", "Focus score")
            )
        }
        
        // C. PROGRESS INTENTS
        if (matchesAny(q, listOf("today progress", "aaj ki progress", "what is my progress", "show progress", "completion percentage", "how much completed today", "today summary"))) {
            if (todayBlocks.isEmpty()) return AssistantResponse("Aaj koi task schedule nahi hai.", listOf("Aaj ka schedule", "Completed tasks"))
            val completed = todayBlocks.count { it.status == "Completed" }
            val total = todayBlocks.size
            val percentage = if (total > 0) (completed.toFloat() / total * 100).toInt() else 0
            return AssistantResponse(
                text = "Aaj aapki progress $percentage% hai. $total me se $completed tasks complete hue hain.",
                chips = listOf("Completed tasks", "Remaining tasks")
            )
        }
        
        // D. CURRENT TASK INTENTS
        if (matchesAny(q, listOf("what is running now", "current task", "abhi kya chal raha hai", "which subject is running", "current session"))) {
            val current = todayBlocks.find { it.status == "Running" || (now in it.startTimeMs..it.endTimeMs && it.status != "Completed" && it.status != "Skipped") }
            if (current != null) {
                val leftMs = current.endTimeMs - now
                val minsLeft = if (leftMs > 0) leftMs / 60000 else 0
                return AssistantResponse(
                    text = "Abhi ${current.subject} session running hai. $minsLeft minute baaki hain.",
                    chips = listOf("Remaining time", "Next task")
                )
            }
            return AssistantResponse("Abhi koi task running nahi hai.", listOf("Today's schedule", "Remaining tasks"))
        }
        
        // E. NEXT TASK INTENTS
        if (matchesAny(q, listOf("what is my next task", "next subject", "agla task kya hai", "what comes next", "next schedule"))) {
            val next = todayBlocks.filter { it.startTimeMs > now && it.status != "Completed" && it.status != "Skipped" }.minByOrNull { it.startTimeMs }
            if (next != null) {
                val cal = Calendar.getInstance()
                cal.timeInMillis = next.startTimeMs
                val timeStr = java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(cal.time)
                return AssistantResponse(
                    text = "Aapka next task ${next.subject} hai, jo $timeStr se start hoga.",
                    chips = listOf("Running task", "Today's schedule")
                )
            }
            return AssistantResponse("Aaj ke liye koi next task schedule nahi hai.", listOf("Today progress", "Today summary"))
        }
        
        // F. REMAINING TIME INTENTS
        if (matchesAny(q, listOf("how much time is left", "timer remaining", "kitna time bacha hai", "remaining time", "current session time left"))) {
            val current = todayBlocks.find { it.status == "Running" || (now in it.startTimeMs..it.endTimeMs && it.status != "Completed" && it.status != "Skipped") }
            if (current != null) {
                val leftMs = current.endTimeMs - now
                if (leftMs > 0) {
                    val mins = leftMs / 60000
                    return AssistantResponse("${mins} minute baaki hain ${current.subject} ke liye.", listOf("Current task", "Next task"))
                }
                return AssistantResponse("${current.subject} ka time poora ho gaya hai!", listOf("Next task", "Completed tasks"))
            }
            return AssistantResponse("Abhi koi task running nahi hai.", listOf("Today's schedule", "Aaj ki progress"))
        }
        
        // G. COMPLETED TASK INTENTS
        if (matchesAny(q, listOf("how many tasks completed today", "completed tasks", "aaj kitne task complete hue", "which tasks completed today", "today completed list"))) {
            val completed = todayBlocks.filter { it.status == "Completed" }
            if (completed.isEmpty()) return AssistantResponse("Aaj abhi tak koi task complete nahi hua hai.", listOf("Remaining tasks", "Today's schedule"))
            val names = completed.joinToString(", ") { it.subject }
            return AssistantResponse("Aaj ${completed.size} tasks complete hue hain: $names.", listOf("Today progress", "Remaining tasks"))
        }
        
        // H. REMAINING TASK INTENTS
        if (matchesAny(q, listOf("how many tasks are left", "pending tasks", "aaj kya remaining hai", "upcoming tasks", "today remaining schedule"))) {
            val remaining = todayBlocks.filter { it.startTimeMs > now && it.status != "Completed" && it.status != "Skipped" }
            if (remaining.isEmpty()) return AssistantResponse("Aaj ke sabhi tasks ho gaye hain!", listOf("Today summary", "Completed tasks"))
            val names = remaining.joinToString(", ") { it.subject }
            return AssistantResponse("Aaj ${remaining.size} tasks remaining hain: $names.", listOf("Next task", "Today's schedule"))
        }
        
        // I. MISSED TASK INTENTS
        if (matchesAny(q, listOf("what did i miss today", "missed tasks", "aaj kya miss hua", "missed schedule", "missed count"))) {
            val missed = todayBlocks.filter { it.status == "Missed" || (it.endTimeMs < now && it.status != "Completed" && it.status != "Skipped" && it.status != "Running") }
            if (missed.isEmpty()) return AssistantResponse("Great! Aaj koi task miss nahi hua hai.", listOf("Completed tasks", "Today progress"))
            val names = missed.joinToString(", ") { it.subject }
            return AssistantResponse("Aaj ${missed.size} tasks missed hue hain: $names.", listOf("Remaining tasks", "Daily review"))
        }
        
        // J. FOCUS / STREAK INTENTS
        if (matchesAny(q, listOf("what is my focus score", "focus percentage", "meri streak kitni hai", "current streak", "longest streak"))) {
            val completed = todayBlocks.count { it.status == "Completed" }
            val total = todayBlocks.size
            val focus = if (total > 0) (completed.toFloat() / total * 100).toInt() else 0
            
            return AssistantResponse("Aaj ka focus score $focus% hai.", listOf("Best subject", "Weekly study"))
        }
        
        // K. SUBJECT / REPORT INTENTS
        if (matchesAny(q, listOf("which subject did i study most", "best subject today", "subject-wise time", "weekly study time", "monthly study time"))) {
            val completed = todayBlocks.filter { it.status == "Completed" }
            if (completed.isEmpty()) return AssistantResponse("Aaj kisi subject ki study record nahi hui hai.", listOf("Aaj ka schedule", "Remaining tasks"))
            val subjectTimes = completed.groupBy { it.subject }.mapValues { entry ->
                entry.value.sumOf { it.actualTimeTakenMs ?: (it.endTimeMs - it.startTimeMs) }
            }
            val best = subjectTimes.maxByOrNull { it.value }
            if (best != null) {
                val mins = best.value / 60000
                return AssistantResponse("Aaj sabse zyada ${best.key} padha gaya hai ($mins min).", listOf("Subject progress", "Weak subject"))
            }
            return AssistantResponse("Not enough data.", listOf("Today progress", "Today's schedule"))
        }
        
        // N. REVIEW / INSIGHT INTENTS (Using Today Summary as requested)
        if (matchesAny(q, listOf("daily review", "what went wrong today", "what should i improve", "study suggestion", "weak subject"))) {
            val totalTimeMs = todayBlocks.filter { it.status == "Completed" }.sumOf { it.actualTimeTakenMs ?: (it.endTimeMs - it.startTimeMs) }
            val hours = totalTimeMs / 3600000
            val mins = (totalTimeMs % 3600000) / 60000
            val completed = todayBlocks.count { it.status == "Completed" }
            val missed = todayBlocks.count { it.status == "Missed" || (it.endTimeMs < now && it.status != "Completed" && it.status != "Skipped" && it.status != "Running") }
            val focus = if (todayBlocks.isNotEmpty()) (completed.toFloat() / todayBlocks.size * 100).toInt() else 0
            
            val summary = "Aaj ka summary:\nStudy Time: ${hours}h ${mins}m\nCompleted: $completed\nMissed: $missed\nFocus Score: $focus%"
            return AssistantResponse(summary, listOf("Weak subject", "Best subject"))
        }
        
        // M. TRACKING INTENTS
        if (matchesAny(q, listOf("selected study apps", "app-wise time", "which app was used most", "study app usage report", "real study time", "pause time", "waiting time", "distraction time"))) {
            val usageMap = mutableMapOf<String, Long>()
            todayBlocks.filter { it.status == "Completed" }.forEach { block ->
                try {
                    val jsonObj = JSONObject(block.appUsageStatsJson)
                    val keys = jsonObj.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        val ms = jsonObj.optLong(key, 0L)
                        usageMap[key] = usageMap.getOrDefault(key, 0L) + ms
                    }
                } catch (e: Exception) {
                    // Ignore parsing errors
                }
            }
            if (usageMap.isEmpty()) {
                return AssistantResponse("Aaj kisi study app ka tracked data available nahi hai.", listOf("Aaj ka schedule", "Today summary"))
            }
            val usageStr = usageMap.entries.sortedByDescending { it.value }.joinToString("\n") { 
                val mins = it.value / 60000
                "${getAppName(it.key)} → $mins min"
            }
            return AssistantResponse(usageStr, listOf("Most used study app", "Today summary"))
        }
        
        // L. SCHEDULE INTENTS
        if (matchesAny(q, listOf("show today's schedule", "today plan", "aaj ka schedule", "what should i study now", "schedule details"))) {
            if (todayBlocks.isEmpty()) return AssistantResponse("Aaj ka schedule empty hai.", listOf("Add schedule", "Today summary"))
            val names = todayBlocks.joinToString(", ") { it.subject }
            return AssistantResponse("Aaj ka schedule: $names.", listOf("Running task", "Remaining tasks"))
        }
        
        // O. HELP / GENERAL
        if (matchesAny(q, listOf("help", "what can you do", "supported questions", "how do i use this", "explain the app"))) {
            return AssistantResponse(
                "Mai aapka offline Study Assistant hu! Aap mujhse apne schedule, study time, missed tasks, aur progress ke baare me pooch sakte hain.",
                listOf("Aaj kitna padha?", "Aaj ki progress")
            )
        }
        
        // Fallback
        return AssistantResponse(
            "Sorry, mai yeh samajh nahi paaya. Try asking about your study time, progress, or schedule.",
            listOf("Aaj ka schedule", "Aaj ki progress")
        )
    }
    
    private fun getAppName(packageName: String): String {
        val parts = packageName.split(".")
        if (parts.isNotEmpty()) {
            return parts.last().replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
        }
        return packageName
    }
    
    private fun matchesAny(query: String, intents: List<String>): Boolean {
        for (intent in intents) {
            val words = intent.split(" ")
            val queryWords = query.split(Regex("\\W+")).filter { it.isNotBlank() }
            if (query.contains(intent)) return true
            val matchCount = words.count { queryWords.contains(it) }
            if (matchCount.toFloat() / words.size > 0.8f) return true
        }
        return false
    }
}
INNER

cat << 'INNER' > app/src/main/java/com/example/ui/screens/AssistantScreen.kt
package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.viewmodel.StudyViewModel
import com.example.util.LocalAssistant
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String, 
    val isUser: Boolean, 
    val chips: List<String> = emptyList(),
    val isTypingIndicator: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssistantScreen(viewModel: StudyViewModel, onNavigateBack: () -> Unit) {
    val context = LocalContext.current
    val profilePrefs = context.getSharedPreferences("local_profile", Context.MODE_PRIVATE)
    val userName = profilePrefs.getString("name", null)
    
    val blocks by viewModel.allBlocks.collectAsState()
    
    var messages by remember { 
        val greetingText = if (!userName.isNullOrBlank()) "Hello $userName 👋\nMain aapka StudyFlow Assistant hoon.\nAaj aap apni study ke baare me kya jaanna chahoge?" else "Hello 👋\nMain aapka StudyFlow Assistant hoon.\nAaj aap apni study ke baare me kya jaanna chahoge?"
        mutableStateOf(listOf(ChatMessage(text = greetingText, isUser = false, chips = listOf("Aaj kitna padha?", "Aaj ka schedule")))) 
    }
    
    var inputText by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    
    // Premium dark theme colors for Assistant
    val surfaceColor = Color(0xFF1E1E1E)
    val backgroundColor = Color(0xFF121212)
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Column {
                        Text("Study Assistant", fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Offline & Local", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = surfaceColor)
            )
        },
        containerColor = backgroundColor
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize().consumeWindowInsets(padding)) {
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                reverseLayout = true
            ) {
                items(messages.reversed(), key = { it.id }) { msg ->
                    ChatBubble(
                        message = msg, 
                        onChipClick = { chipText ->
                            inputText = chipText
                            val userMsg = chipText
                            inputText = ""
                            
                            messages = messages + ChatMessage(text = userMsg, isUser = true)
                            messages = messages + ChatMessage(text = "", isUser = false, isTypingIndicator = true)
                            
                            coroutineScope.launch {
                                listState.animateScrollToItem(0)
                                delay(1500) // Natural reply delay
                                
                                val reply = LocalAssistant.processQuery(userMsg, blocks, userName)
                                messages = messages.filter { !it.isTypingIndicator } + ChatMessage(text = reply.text, isUser = false, chips = reply.chips.take(2))
                            }
                        }
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
            
            Surface(
                color = surfaceColor,
                shadowElevation = 8.dp,
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .navigationBarsPadding(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Ask about your study...", color = Color.Gray) },
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF2C2C2C),
                            unfocusedContainerColor = Color(0xFF2C2C2C),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    FloatingActionButton(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                val userMsg = inputText
                                inputText = ""
                                
                                messages = messages + ChatMessage(text = userMsg, isUser = true)
                                messages = messages + ChatMessage(text = "", isUser = false, isTypingIndicator = true)
                                
                                coroutineScope.launch {
                                    listState.animateScrollToItem(0)
                                    delay(1500) // Natural reply delay
                                    
                                    val reply = LocalAssistant.processQuery(userMsg, blocks, userName)
                                    messages = messages.filter { !it.isTypingIndicator } + ChatMessage(text = reply.text, isUser = false, chips = reply.chips.take(2))
                                }
                            }
                        },
                        modifier = Modifier.size(56.dp),
                        shape = RoundedCornerShape(16.dp),
                        containerColor = MaterialTheme.colorScheme.primary
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            }
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage, onChipClick: (String) -> Unit) {
    if (message.isTypingIndicator) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.Start
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp, 20.dp, 20.dp, 4.dp),
                color = Color(0xFF2C2C2C),
                modifier = Modifier.widthIn(max = 100.dp),
                shadowElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val transition = rememberInfiniteTransition(label = "typing")
                    for (i in 0..2) {
                        val scale by transition.animateFloat(
                            initialValue = 0.5f,
                            targetValue = 1.2f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(300, delayMillis = i * 150),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "dot"
                        )
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .scale(scale)
                                .background(Color.Gray, CircleShape)
                        )
                    }
                }
            }
        }
        return
    }

    var displayedText by remember { mutableStateOf(if (message.isUser) message.text else "") }
    var showChips by remember { mutableStateOf(message.isUser || message.text.contains("Main aapka StudyFlow Assistant hoon.")) }

    LaunchedEffect(message.id) {
        if (!message.isUser && !message.text.contains("Main aapka StudyFlow Assistant hoon.")) {
            val words = message.text.split(" ")
            var current = ""
            for (i in words.indices) {
                current += if (i == 0) words[i] else " ${words[i]}"
                displayedText = current
                delay(50) // typing speed
            }
            showChips = true
        } else if (!message.isUser) {
            displayedText = message.text
        }
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (message.isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 20.dp,
                topEnd = 20.dp,
                bottomStart = if (message.isUser) 20.dp else 4.dp,
                bottomEnd = if (message.isUser) 4.dp else 20.dp
            ),
            color = if (message.isUser) MaterialTheme.colorScheme.primary else Color(0xFF2C2C2C),
            modifier = Modifier.widthIn(max = 300.dp),
            shadowElevation = 2.dp
        ) {
            Text(
                text = displayedText,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                color = if (message.isUser) MaterialTheme.colorScheme.onPrimary else Color.White,
                style = MaterialTheme.typography.bodyLarge
            )
        }
        
        if (message.chips.isNotEmpty() && !message.isUser && showChips) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(start = 4.dp)
            ) {
                message.chips.forEach { chipText ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.Transparent,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { onChipClick(chipText) }
                    ) {
                        Text(
                            text = chipText,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}
INNER
