import sys

with open('app/src/main/java/com/example/data/local/AppDatabase.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'import com.example.data.model.StopwatchSession',
    'import com.example.data.model.StopwatchSession\nimport com.example.data.model.CustomTimer'
)
content = content.replace(
    'StopwatchSession::class]',
    'StopwatchSession::class, CustomTimer::class]'
)
content = content.replace('version = 5', 'version = 6')
content = content.replace(
    'abstract fun stopwatchDao(): StopwatchDao',
    'abstract fun stopwatchDao(): StopwatchDao\n    abstract fun customTimerDao(): CustomTimerDao'
)

with open('app/src/main/java/com/example/data/local/AppDatabase.kt', 'w') as f:
    f.write(content)

with open('app/src/main/java/com/example/ui/viewmodel/StudyViewModel.kt', 'r') as f:
    content = f.read()

migration_6_code = '''
val MIGRATION_5_6 = object : Migration(5, 6) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `custom_timers` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `hours` INTEGER NOT NULL, `minutes` INTEGER NOT NULL, `seconds` INTEGER NOT NULL, `color` INTEGER NOT NULL, `iconName` TEXT NOT NULL, `notes` TEXT NOT NULL, `useAlarmSound` INTEGER NOT NULL, `useVibration` INTEGER NOT NULL)")
    }
}
'''
if 'MIGRATION_5_6' not in content:
    content = content.replace('val MIGRATION_4_5 =', migration_6_code + '\nval MIGRATION_4_5 =')
    content = content.replace(
        '.addMigrations(MIGRATION_4_5)',
        '.addMigrations(MIGRATION_4_5, MIGRATION_5_6)'
    )
    with open('app/src/main/java/com/example/ui/viewmodel/StudyViewModel.kt', 'w') as f:
        f.write(content)

# Update Repository
with open('app/src/main/java/com/example/data/repository/StudyRepository.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'import com.example.data.local.StopwatchDao',
    'import com.example.data.local.StopwatchDao\nimport com.example.data.local.CustomTimerDao'
)
content = content.replace(
    'import com.example.data.model.StopwatchSession',
    'import com.example.data.model.StopwatchSession\nimport com.example.data.model.CustomTimer'
)
content = content.replace(
    'private val stopwatchDao: StopwatchDao',
    'private val stopwatchDao: StopwatchDao,\n    private val customTimerDao: CustomTimerDao'
)
content += '''
    fun getAllCustomTimers(): Flow<List<CustomTimer>> = customTimerDao.getAllCustomTimers()
    suspend fun insertCustomTimer(timer: CustomTimer) = customTimerDao.insertCustomTimer(timer)
    suspend fun updateCustomTimer(timer: CustomTimer) = customTimerDao.updateCustomTimer(timer)
    suspend fun deleteCustomTimer(timer: CustomTimer) = customTimerDao.deleteCustomTimer(timer)
'''

with open('app/src/main/java/com/example/data/repository/StudyRepository.kt', 'w') as f:
    f.write(content)

# Update ViewModel again
with open('app/src/main/java/com/example/ui/viewmodel/StudyViewModel.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'import com.example.data.model.StopwatchSession',
    'import com.example.data.model.StopwatchSession\nimport com.example.data.model.CustomTimer'
)
content = content.replace(
    'db.timeBlockDao(), db.statsDao(), db.stopwatchDao()',
    'db.timeBlockDao(), db.statsDao(), db.stopwatchDao(), db.customTimerDao()'
)

content = content.replace(
    'val stopwatchSessions: StateFlow<List<StopwatchSession>> = repository.getAllStopwatchSessions()\n        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())',
    'val stopwatchSessions: StateFlow<List<StopwatchSession>> = repository.getAllStopwatchSessions()\n        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())\n\n    val customTimers: StateFlow<List<CustomTimer>> = repository.getAllCustomTimers()\n        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())'
)

content += '''
    fun addCustomTimer(timer: CustomTimer) {
        viewModelScope.launch {
            repository.insertCustomTimer(timer)
        }
    }
    fun updateCustomTimer(timer: CustomTimer) {
        viewModelScope.launch {
            repository.updateCustomTimer(timer)
        }
    }
    fun deleteCustomTimer(timer: CustomTimer) {
        viewModelScope.launch {
            repository.deleteCustomTimer(timer)
        }
    }
'''

with open('app/src/main/java/com/example/ui/viewmodel/StudyViewModel.kt', 'w') as f:
    f.write(content)
