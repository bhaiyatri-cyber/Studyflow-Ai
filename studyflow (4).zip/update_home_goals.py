import sys

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

if 'val stats by viewModel.stats.collectAsState()' not in content:
    content = content.replace(
        'val allBlocks by viewModel.allBlocks.collectAsState()',
        'val allBlocks by viewModel.allBlocks.collectAsState()\n    val stats by viewModel.stats.collectAsState()'
    )

new_goals_card = '''
                // Daily Goals
                item {
                    val studyHourGoal = stats?.dailyStudyHourGoal ?: 4
                    val taskGoal = stats?.dailyTaskGoal ?: 5
                    val completedMins = completedTasks.sumOf { (it.endTimeMs - it.startTimeMs) / 60000 }
                    val completedTasksCount = completedTasks.size
                    
                    val studyProgress = (completedMins.toFloat() / (studyHourGoal * 60)).coerceIn(0f, 1f)
                    val taskProgress = (completedTasksCount.toFloat() / taskGoal).coerceIn(0f, 1f)
                    
                    Column {
                        SectionHeader("Daily Goals", Icons.Default.Star, MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            // Study Goal Card
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Study Time", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Box(modifier = Modifier.size(72.dp), contentAlignment = Alignment.Center) {
                                        CircularProgressIndicator(progress = { 1f }, modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.primary.copy(alpha=0.1f), strokeWidth = 5.dp)
                                        CircularProgressIndicator(progress = { studyProgress }, modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.primary, strokeWidth = 5.dp)
                                        Text("${(studyProgress*100).toInt()}%", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text("${completedMins / 60}h ${completedMins % 60}m / ${studyHourGoal}h", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            // Task Goal Card
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Tasks", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Box(modifier = Modifier.size(72.dp), contentAlignment = Alignment.Center) {
                                        CircularProgressIndicator(progress = { 1f }, modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.secondary.copy(alpha=0.1f), strokeWidth = 5.dp)
                                        CircularProgressIndicator(progress = { taskProgress }, modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.secondary, strokeWidth = 5.dp)
                                        Text("${(taskProgress*100).toInt()}%", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text("$completedTasksCount / $taskGoal tasks", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
'''

content = content.replace(
    "item {\n                    val totalMins = todaysBlocks.sumOf",
    new_goals_card + "\n                item {\n                    val totalMins = todaysBlocks.sumOf"
)

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)
