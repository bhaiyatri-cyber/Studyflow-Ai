import sys
content = open('app/src/main/java/com/example/MainActivity.kt').read()

target = '''                                    val block = viewModel.allBlocks.value.find { it.id == blockId }
                                    AddEditBlockScreen(
                                        block = block,
                                        onSave = { updatedBlock ->'''
replacement = '''                                    val block = viewModel.allBlocks.value.find { it.id == blockId }
                                    AddEditBlockScreen(
                                        block = block,
                                        allBlocks = viewModel.allBlocks.value,
                                        onSave = { updatedBlock ->'''
content = content.replace(target, replacement)
open('app/src/main/java/com/example/MainActivity.kt', 'w').write(content)
