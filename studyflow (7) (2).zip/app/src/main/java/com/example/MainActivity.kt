package com.example

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material3.FloatingActionButton
import com.example.ui.AssistantBottomSheet
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.engine.PermissionState
import com.example.engine.PermissionType
import com.example.ui.HistoryRoute
import com.example.ui.HistoryScreen
import com.example.ui.HomeRoute
import com.example.ui.HomeScreen
import com.example.ui.ProgressRoute
import com.example.ui.ProgressScreen
import com.example.ui.ScheduleRoute
import com.example.ui.ScheduleScreen
import com.example.ui.SettingsRoute
import com.example.ui.SettingsScreen
import com.example.ui.StudyViewModel
import com.example.ui.components.PermissionPopup
import com.example.ui.theme.MyApplicationTheme

import com.example.ui.StartupState
import com.example.ui.startup.SplashScreen
import com.example.ui.startup.WelcomeScreen

class MainActivity : ComponentActivity() {
    private val viewModel: StudyViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val startupState by viewModel.startupState.collectAsState()
                
                when (startupState) {
                    StartupState.LOADING -> SplashScreen()
                    StartupState.NEEDS_SETUP -> WelcomeScreen(
                        viewModel = viewModel,
                        onSetupComplete = { viewModel.markSetupComplete() }
                    )
                    StartupState.READY -> StudyFlowApp(viewModel)
                }
            }
        }
    }
}

@Composable
fun StudyFlowApp(viewModel: StudyViewModel) {
    val navController = rememberNavController()
    val context = LocalContext.current

    var showAssistant by remember { mutableStateOf(false) }

    val notificationState by viewModel.notificationPermissionState.collectAsState()
    val pendingRequest by viewModel.pendingPermissionRequest.collectAsState()

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        viewModel.refreshPermissions()
        viewModel.clearPermissionRequest()
    }

    val generalIntentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        viewModel.refreshPermissions()
        viewModel.clearPermissionRequest()
    }

    LaunchedEffect(notificationState) {
        if (notificationState == PermissionState.MISSING && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            viewModel.requestPermission(PermissionType.NOTIFICATIONS)
        }
    }

    pendingRequest?.let { permissionType ->
        PermissionPopup(
            permissionType = permissionType,
            onDismiss = { viewModel.clearPermissionRequest() },
            onContinue = {
                when (permissionType) {
                    PermissionType.NOTIFICATIONS -> {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notificationLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            viewModel.clearPermissionRequest()
                        }
                    }
                    PermissionType.USAGE_ACCESS -> {
                        generalIntentLauncher.launch(viewModel.getUsageAccessIntent())
                    }
                    PermissionType.BATTERY_OPTIMIZATION -> {
                        generalIntentLauncher.launch(viewModel.getBatteryOptimizationIntent())
                    }
                }
            }
        )
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = navBackStackEntry?.destination

            NavigationBar {
                NavigationBarItem(
                    icon = { Icon(Icons.Filled.Home, contentDescription = "Home") },
                    label = { Text("Home") },
                    selected = currentDestination?.hierarchy?.any { it.route == HomeRoute::class.qualifiedName } == true,
                    onClick = {
                        navController.navigate(HomeRoute) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Filled.DateRange, contentDescription = "Schedule") },
                    label = { Text("Schedule") },
                    selected = currentDestination?.hierarchy?.any { it.route == ScheduleRoute::class.qualifiedName } == true,
                    onClick = {
                        navController.navigate(ScheduleRoute) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Filled.History, contentDescription = "History") },
                    label = { Text("History") },
                    selected = currentDestination?.hierarchy?.any { it.route == HistoryRoute::class.qualifiedName } == true,
                    onClick = {
                        navController.navigate(HistoryRoute) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Filled.BarChart, contentDescription = "Progress") },
                    label = { Text("Progress") },
                    selected = currentDestination?.hierarchy?.any { it.route == ProgressRoute::class.qualifiedName } == true,
                    onClick = {
                        navController.navigate(ProgressRoute) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Filled.Settings, contentDescription = "Settings") },
                    label = { Text("Settings") },
                    selected = currentDestination?.hierarchy?.any { it.route == SettingsRoute::class.qualifiedName } == true,
                    onClick = {
                        navController.navigate(SettingsRoute) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAssistant = true }) {
                Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = "Assistant")
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = HomeRoute,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable<HomeRoute> { HomeScreen(viewModel) }
            composable<ScheduleRoute> { ScheduleScreen(viewModel) }
            composable<HistoryRoute> { HistoryScreen(viewModel) }
            composable<ProgressRoute> { ProgressScreen(viewModel) }
            composable<SettingsRoute> { SettingsScreen(viewModel) }
        }
        
        if (showAssistant) {
            AssistantBottomSheet(viewModel, onDismiss = { showAssistant = false })
        }
    }
}
