package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Entity(tableName = "schedules")
@Serializable
data class StudySchedule(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subjectName: String,
    val startTime: Long, // timestamp
    val endTime: Long, // timestamp
    val repeatType: String, // ONE_TIME, DAILY, WEEKLY
    val isOfflineMode: Boolean,
    val selectedAppPackage: String? = null,
    val colorAccent: Long, // color value
    val notes: String = "",
    val status: String = "Upcoming" // Upcoming, Waiting, Running, Paused, Completed, Missed
)

@Entity(tableName = "chat_messages")
@Serializable
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val text: String,
    val isUser: Boolean,
    val timestamp: Long
)

@Entity(tableName = "sessions")
@Serializable
data class StudySession(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val scheduleId: Int,
    val subjectName: String,
    val date: Long,
    val scheduledDurationMs: Long,
    val actualDurationMs: Long,
    val status: String,
    val isOfflineMode: Boolean,
    val selectedAppPackage: String? = null,
    val notes: String = "",
    val timelineEvents: String = ""
)

@Serializable
data class BackupData(
    val version: Int = 1,
    val userName: String,
    val schedules: List<StudySchedule>,
    val sessions: List<StudySession>,
    val chatMessages: List<ChatMessageEntity>
)
