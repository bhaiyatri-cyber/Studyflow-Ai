package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface StudyDao {
    @Query("SELECT * FROM schedules ORDER BY startTime ASC")
    fun getAllSchedules(): Flow<List<StudySchedule>>

    @Query("SELECT * FROM schedules WHERE id = :id")
    fun getScheduleById(id: Int): Flow<StudySchedule?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedule(schedule: StudySchedule)

    @Update
    suspend fun updateSchedule(schedule: StudySchedule)

    @Query("DELETE FROM schedules WHERE id = :id")
    suspend fun deleteSchedule(id: Int)

    @Query("SELECT * FROM sessions ORDER BY date DESC")
    fun getAllSessions(): Flow<List<StudySession>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: StudySession)
    
    @Query("DELETE FROM sessions WHERE id = :id")
    suspend fun deleteSession(id: Int)
    
    @Query("SELECT SUM(actualDurationMs) FROM sessions")
    fun getTotalStudyTime(): Flow<Long?>

    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllChatMessages(): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChatMessage(message: ChatMessageEntity)
    
    @Query("DELETE FROM schedules")
    suspend fun clearAllSchedules()
    
    @Query("DELETE FROM sessions")
    suspend fun clearAllSessions()
    
    @Query("DELETE FROM chat_messages")
    suspend fun clearAllChatMessages()
}
