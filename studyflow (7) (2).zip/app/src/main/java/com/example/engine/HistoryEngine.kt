package com.example.engine

import com.example.data.StudyDao
import com.example.data.StudySchedule
import com.example.data.StudySession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HistoryEngine private constructor(private val studyDao: StudyDao) {
    private val engineScope = CoroutineScope(Dispatchers.Default)

    val historySessions: StateFlow<List<StudySession>> = studyDao.getAllSessions()
        .stateIn(engineScope, SharingStarted.Lazily, emptyList())

    fun recordSession(schedule: StudySchedule, finalStatus: TaskStatus, actualDurationMs: Long) {
        engineScope.launch {
            // Check if we already have a terminal session for this scheduleId (to avoid duplicates)
            // Wait, StudySession doesn't have a unique constraint on scheduleId, but we can check.
            val existing = studyDao.getAllSessions().first().find { it.scheduleId == schedule.id }
            if (existing != null) {
                // If it exists, we might want to update it, but typically we only write once on terminal state.
                return@launch
            }

            val session = StudySession(
                scheduleId = schedule.id,
                subjectName = schedule.subjectName,
                date = System.currentTimeMillis(),
                scheduledDurationMs = schedule.endTime - schedule.startTime,
                actualDurationMs = actualDurationMs,
                status = finalStatus.displayName,
                isOfflineMode = schedule.isOfflineMode,
                selectedAppPackage = schedule.selectedAppPackage,
                notes = schedule.notes,
                timelineEvents = "Schedule created -> ${finalStatus.displayName}"
            )
            studyDao.insertSession(session)
        }
    }
    
    fun deleteSession(sessionId: Int) {
        engineScope.launch {
            studyDao.deleteSession(sessionId)
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: HistoryEngine? = null

        fun getInstance(studyDao: StudyDao): HistoryEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: HistoryEngine(studyDao).also { INSTANCE = it }
            }
        }
    }
}
