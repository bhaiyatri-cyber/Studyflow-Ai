package com.example.engine

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.StudySchedule
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.Calendar

class NotificationEngine private constructor(
    private val context: Context,
    private val permissionEngine: PermissionEngine,
    private val runningScheduleFlow: StateFlow<StudySchedule?>,
    private val timerStateFlow: StateFlow<TimerState>,
    private val timerDurationMsFlow: StateFlow<Long>
) {
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val channelId = "studyflow_channel"
    private val notificationId = 1001

    private val engineScope = CoroutineScope(Dispatchers.Default)
    private var monitorJob: Job? = null

    init {
        createNotificationChannel()
        startMonitoring()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "StudyFlow Notifications"
            val descriptionText = "Notifications for active study sessions"
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(channelId, name, importance).apply {
                description = descriptionText
            }
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    private fun startMonitoring() {
        engineScope.launch {
            launch {
                runningScheduleFlow.collect { updateNotification() }
            }
            launch {
                timerStateFlow.collect { updateNotification() }
            }
            launch {
                timerDurationMsFlow.collect { updateNotification() }
            }
        }
    }
    
    private fun updateNotification() {
        if (permissionEngine.notificationState.value != PermissionState.GRANTED) {
            return
        }

        val schedule = runningScheduleFlow.value
        if (schedule == null) {
            notificationManager.cancel(notificationId)
            return
        }

        val state = timerStateFlow.value
        val durationMs = timerDurationMsFlow.value

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .setOnlyAlertOnce(true)
            .setOngoing(state == TimerState.RUNNING || state == TimerState.WAITING || state == TimerState.PAUSED)
            .setColor(0xFF00E5FF.toInt()) // CyanAccent

        val totalDurationMs = schedule.endTime - schedule.startTime
        val progressPercent = if (totalDurationMs > 0) (durationMs * 100 / totalDurationMs).toInt() else 0
        
        when (state) {
            TimerState.NOT_STARTED -> {
                builder.setContentTitle("Upcoming: ${schedule.subjectName}")
                builder.setContentText("Starts at ${formatTimeDisplay(schedule.startTime)}")
            }
            TimerState.WAITING -> {
                builder.setContentTitle("Study Ready")
                builder.setContentText("Status: Waiting - ${schedule.subjectName}")
            }
            TimerState.RUNNING -> {
                builder.setContentTitle(schedule.subjectName)
                builder.setContentText("Status: Running | Studied: ${formatDuration(durationMs)} / ${formatDuration(totalDurationMs)}")
                builder.setProgress(100, progressPercent, false)
            }
            TimerState.PAUSED -> {
                builder.setContentTitle(schedule.subjectName)
                builder.setContentText("Status: Paused | Studied: ${formatDuration(durationMs)}")
                builder.setProgress(100, progressPercent, false)
            }
            TimerState.COMPLETED -> {
                builder.setContentTitle(schedule.subjectName)
                builder.setContentText("Status: Completed | Total Studied: ${formatDuration(durationMs)}")
                builder.setOngoing(false)
            }
            TimerState.MISSED -> {
                builder.setContentTitle(schedule.subjectName)
                builder.setContentText("Status: Missed")
                builder.setOngoing(false)
            }
        }

        notificationManager.notify(notificationId, builder.build())
    }

    private fun formatTimeDisplay(timestamp: Long): String {
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = timestamp
        val hours = calendar.get(Calendar.HOUR_OF_DAY)
        val mins = calendar.get(Calendar.MINUTE)
        return String.format("%02d:%02d", hours, mins)
    }

    private fun formatDuration(timeMs: Long): String {
        val totalSeconds = timeMs / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format("%dh %02dm", hours, minutes)
        } else if (minutes > 0) {
            String.format("%dm %02ds", minutes, seconds)
        } else {
            String.format("%ds", seconds)
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: NotificationEngine? = null

        fun getInstance(
            context: Context,
            permissionEngine: PermissionEngine,
            runningScheduleFlow: StateFlow<StudySchedule?>,
            timerStateFlow: StateFlow<TimerState>,
            timerDurationMsFlow: StateFlow<Long>
        ): NotificationEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: NotificationEngine(
                    context.applicationContext,
                    permissionEngine,
                    runningScheduleFlow,
                    timerStateFlow,
                    timerDurationMsFlow
                ).also { INSTANCE = it }
            }
        }
    }
}
