package com.example.engine

import com.example.data.StudyDao
import com.example.data.StudySession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Calendar

data class ProgressStats(
    val totalStudyTimeMs: Long = 0L,
    val xp: Int = 0,
    val level: Int = 1,
    val streak: Int = 0,
    val completionPercentage: Float = 0f,
    val focusScore: Int = 0,
    val subjectAnalytics: Map<String, Long> = emptyMap(),
    val hasData: Boolean = false
)

class ProgressEngine private constructor(private val studyDao: StudyDao) {
    private val engineScope = CoroutineScope(Dispatchers.Default)

    private val _progressStats = MutableStateFlow(ProgressStats())
    val progressStats: StateFlow<ProgressStats> = _progressStats.asStateFlow()

    init {
        engineScope.launch {
            studyDao.getAllSessions().collect { sessions ->
                calculateStats(sessions)
            }
        }
    }

    private fun calculateStats(sessions: List<StudySession>) {
        val validSessions = sessions.filter { it.actualDurationMs > 0 }
        if (validSessions.isEmpty()) {
            _progressStats.value = ProgressStats(hasData = false)
            return
        }

        var totalStudyTimeMs = 0L
        var scheduledTimeMs = 0L
        val subjectAnalytics = mutableMapOf<String, Long>()

        for (session in validSessions) {
            if (session.status == TaskStatus.COMPLETED.displayName || session.status == TaskStatus.MISSED.displayName) {
                totalStudyTimeMs += session.actualDurationMs
                scheduledTimeMs += session.scheduledDurationMs
                
                val currentSubjectTime = subjectAnalytics[session.subjectName] ?: 0L
                subjectAnalytics[session.subjectName] = currentSubjectTime + session.actualDurationMs
            }
        }

        val totalMinutes = (totalStudyTimeMs / 60000).toInt()
        val xp = totalMinutes * 10
        val level = (xp / 1000) + 1

        val completionPercentage = if (scheduledTimeMs > 0) {
            (totalStudyTimeMs.toFloat() / scheduledTimeMs.toFloat()) * 100f
        } else {
            0f
        }

        val streak = calculateStreak(validSessions)
        val focusScore = calculateFocusScore(completionPercentage)

        _progressStats.value = ProgressStats(
            totalStudyTimeMs = totalStudyTimeMs,
            xp = xp,
            level = level,
            streak = streak,
            completionPercentage = completionPercentage,
            focusScore = focusScore,
            subjectAnalytics = subjectAnalytics,
            hasData = true
        )
    }

    private fun calculateStreak(sessions: List<StudySession>): Int {
        val completedSessions = sessions.filter { it.status == TaskStatus.COMPLETED.displayName }
            .sortedByDescending { it.date }
        
        if (completedSessions.isEmpty()) return 0

        var streak = 0
        var lastDay = -1

        val calendar = Calendar.getInstance()

        for (session in completedSessions) {
            calendar.timeInMillis = session.date
            val dayOfYear = calendar.get(Calendar.DAY_OF_YEAR)
            val year = calendar.get(Calendar.YEAR)
            val absoluteDay = year * 365 + dayOfYear

            if (lastDay == -1) {
                val currentAbsoluteDay = Calendar.getInstance().get(Calendar.YEAR) * 365 + Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
                if (absoluteDay == currentAbsoluteDay || absoluteDay == currentAbsoluteDay - 1) {
                    streak++
                    lastDay = absoluteDay
                } else {
                    break 
                }
            } else {
                if (absoluteDay == lastDay) {
                    continue 
                } else if (absoluteDay == lastDay - 1) {
                    streak++
                    lastDay = absoluteDay
                } else {
                    break 
                }
            }
        }
        return streak
    }

    private fun calculateFocusScore(completionRate: Float): Int {
        return minOf(100, maxOf(0, completionRate.toInt()))
    }

    companion object {
        @Volatile
        private var INSTANCE: ProgressEngine? = null

        fun getInstance(studyDao: StudyDao): ProgressEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: ProgressEngine(studyDao).also { INSTANCE = it }
            }
        }
    }
}
