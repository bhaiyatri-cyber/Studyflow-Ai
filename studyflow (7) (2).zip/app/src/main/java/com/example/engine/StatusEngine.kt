package com.example.engine

import com.example.data.StudyDao
import com.example.data.StudySchedule
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

enum class TaskStatus(val displayName: String) {
    UPCOMING("Upcoming"),
    WAITING("Waiting"),
    RUNNING("Running"),
    PAUSED("Paused"),
    COMPLETED("Completed"),
    SKIPPED("Skipped"),
    MISSED("Missed")
}

class StatusEngine private constructor(
    private val studyDao: StudyDao,
    private val timerEngine: TimerEngine,
    private val historyEngine: HistoryEngine,
    private val runningScheduleFlow: StateFlow<StudySchedule?>
) {
    private val engineScope = CoroutineScope(Dispatchers.Default)
    private var monitorJob: Job? = null

    init {
        startMonitoring()
    }

    private fun startMonitoring() {
        monitorJob = engineScope.launch {
            while (true) {
                updateStatuses()
                delay(1000)
            }
        }
    }

    private suspend fun updateStatuses() {
        val schedules = studyDao.getAllSchedules().first()
        val now = System.currentTimeMillis()
        val currentTimerState = timerEngine.timerState.value
        val activeSchedule = runningScheduleFlow.value
        val currentDuration = timerEngine.elapsedTimeMs.value

        for (schedule in schedules) {
            val newStatus = calculateStatus(schedule, now, currentTimerState, activeSchedule)
            if (schedule.status != newStatus.displayName) {
                studyDao.updateSchedule(schedule.copy(status = newStatus.displayName))
                
                if (newStatus == TaskStatus.COMPLETED || newStatus == TaskStatus.MISSED) {
                    val actualTime = if (activeSchedule?.id == schedule.id) currentDuration else 0L
                    historyEngine.recordSession(schedule, newStatus, actualTime)
                }
            }
        }
    }

    fun markAsSkipped(scheduleId: Int) {
        engineScope.launch {
            val schedule = studyDao.getScheduleById(scheduleId).first()
            if (schedule != null) {
                studyDao.updateSchedule(schedule.copy(status = TaskStatus.SKIPPED.displayName))
                val actualTime = if (runningScheduleFlow.value?.id == schedule.id) timerEngine.elapsedTimeMs.value else 0L
                historyEngine.recordSession(schedule, TaskStatus.SKIPPED, actualTime)
            }
        }
    }

    private fun calculateStatus(
        schedule: StudySchedule,
        now: Long,
        currentTimerState: TimerState,
        activeSchedule: StudySchedule?
    ): TaskStatus {
        val currentStatusStr = schedule.status.uppercase()
        val currentStatus = try {
            TaskStatus.valueOf(currentStatusStr)
        } catch (e: Exception) {
            TaskStatus.UPCOMING
        }

        // Terminal states should not change automatically
        if (currentStatus == TaskStatus.COMPLETED || currentStatus == TaskStatus.SKIPPED || currentStatus == TaskStatus.MISSED) {
            return currentStatus
        }

        // If this schedule is currently being handled by TimerEngine
        if (activeSchedule?.id == schedule.id) {
            return when (currentTimerState) {
                TimerState.NOT_STARTED -> if (now < schedule.startTime) TaskStatus.UPCOMING else TaskStatus.WAITING
                TimerState.WAITING -> TaskStatus.WAITING
                TimerState.RUNNING -> TaskStatus.RUNNING
                TimerState.PAUSED -> TaskStatus.PAUSED
                TimerState.COMPLETED -> TaskStatus.COMPLETED
                TimerState.MISSED -> TaskStatus.MISSED
            }
        }

        // If not the active one being tracked
        if (now < schedule.startTime) {
            return TaskStatus.UPCOMING
        } else if (now >= schedule.startTime && now < schedule.endTime) {
            return TaskStatus.WAITING
        } else if (now >= schedule.endTime) {
            return TaskStatus.MISSED
        }

        return currentStatus
    }

    companion object {
        @Volatile
        private var INSTANCE: StatusEngine? = null

        fun getInstance(
            studyDao: StudyDao,
            timerEngine: TimerEngine,
            historyEngine: HistoryEngine,
            runningScheduleFlow: StateFlow<StudySchedule?>
        ): StatusEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: StatusEngine(studyDao, timerEngine, historyEngine, runningScheduleFlow).also { INSTANCE = it }
            }
        }
    }
}
