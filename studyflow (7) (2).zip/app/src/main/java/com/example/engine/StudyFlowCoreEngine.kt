package com.example.engine

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.AppDatabase
import com.example.data.StudyDao
import com.example.data.StudySchedule
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

private val Context.dataStore by preferencesDataStore(name = "studyflow_prefs")

/**
 * The single source of truth for the entire application.
 */
class StudyFlowCoreEngine private constructor(private val context: Context) {
    private val database = AppDatabase.getDatabase(context)
    val studyDao: StudyDao = database.studyDao()
    
    val permissionEngine: PermissionEngine = PermissionEngine.getInstance(context)
    val timerEngine: TimerEngine = TimerEngine.getInstance(context, permissionEngine)
    val historyEngine: HistoryEngine = HistoryEngine.getInstance(studyDao)

    private val engineScope = CoroutineScope(Dispatchers.IO)

    // DataStore keys
    private val USER_NAME_KEY = stringPreferencesKey("user_name")

    val userName: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[USER_NAME_KEY] ?: ""
    }

    // Engine States
    private val _runningSchedule = MutableStateFlow<StudySchedule?>(null)
    val runningSchedule: StateFlow<StudySchedule?> = _runningSchedule.asStateFlow()

    val statusEngine: StatusEngine = StatusEngine.getInstance(studyDao, timerEngine, historyEngine, runningSchedule)

    val timerDurationMs: StateFlow<Long> = timerEngine.elapsedTimeMs
    val timerState: StateFlow<TimerState> = timerEngine.timerState
    
    val notificationEngine: NotificationEngine = NotificationEngine.getInstance(
        context, permissionEngine, runningSchedule, timerState, timerDurationMs
    )
    
    val progressEngine: ProgressEngine = ProgressEngine.getInstance(studyDao)
    val progressStats: StateFlow<ProgressStats> = progressEngine.progressStats

    val assistantEngine: AssistantEngine = AssistantEngine.getInstance(
        studyDao, progressEngine, historyEngine, runningSchedule, timerState, userName
    )

    val backupEngine: BackupEngine by lazy {
        BackupEngine.getInstance(context, studyDao, this)
    }

    init {
        // Monitor running schedule changes and update TimerEngine
        engineScope.launch {
            _runningSchedule.collect { schedule ->
                timerEngine.setActiveSchedule(schedule)
            }
        }
    }

    fun setRunningSchedule(schedule: StudySchedule?) {
        _runningSchedule.value = schedule
    }

    fun markAsSkipped(scheduleId: Int) {
        statusEngine.markAsSkipped(scheduleId)
    }

    fun updateUserName(name: String) {
        engineScope.launch {
            context.dataStore.edit { prefs ->
                prefs[USER_NAME_KEY] = name
            }
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: StudyFlowCoreEngine? = null

        fun getInstance(context: Context): StudyFlowCoreEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: StudyFlowCoreEngine(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
