package com.example.engine

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import com.example.data.StudySchedule
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

enum class TimerState(val statusName: String) {
    NOT_STARTED("Not Started"),
    WAITING("Waiting"),
    RUNNING("Running"),
    PAUSED("Paused"),
    COMPLETED("Completed"),
    MISSED("Missed")
}

class TimerEngine private constructor(
    private val context: Context,
    private val permissionEngine: PermissionEngine
) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

    private val _timerState = MutableStateFlow(TimerState.NOT_STARTED)
    val timerState: StateFlow<TimerState> = _timerState.asStateFlow()

    private val _elapsedTimeMs = MutableStateFlow(0L)
    val elapsedTimeMs: StateFlow<Long> = _elapsedTimeMs.asStateFlow()

    private var activeSchedule: StudySchedule? = null
    
    private var timerJob: Job? = null
    private val engineScope = CoroutineScope(Dispatchers.Default)

    // Sensor state
    private var isFaceDown = false
    private var isStable = false
    private var lastAccelValues = FloatArray(3)
    private var lastSensorUpdateTime = 0L

    fun setActiveSchedule(schedule: StudySchedule?) {
        activeSchedule = schedule
        _elapsedTimeMs.value = 0L
        _timerState.value = if (schedule == null) TimerState.NOT_STARTED else TimerState.WAITING
        
        if (schedule != null) {
            startMonitoring()
        } else {
            stopMonitoring()
        }
    }

    private fun startMonitoring() {
        stopMonitoring()
        
        if (activeSchedule?.isOfflineMode == true) {
            accelerometer?.let {
                sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
            }
        }
        
        timerJob = engineScope.launch {
            var lastTickTime = System.currentTimeMillis()
            
            while (isActive) {
                val schedule = activeSchedule ?: break
                val now = System.currentTimeMillis()
                val delta = now - lastTickTime
                lastTickTime = now

                val isConditionMet = checkConditions(schedule, now)

                if (isConditionMet) {
                    _timerState.value = TimerState.RUNNING
                    _elapsedTimeMs.value += delta
                } else {
                    if (_timerState.value == TimerState.RUNNING) {
                        _timerState.value = TimerState.PAUSED
                    } else if (_timerState.value == TimerState.NOT_STARTED) {
                        if (now >= schedule.startTime) {
                            _timerState.value = TimerState.WAITING
                        }
                    }
                }
                
                if (now >= schedule.endTime) {
                    val requiredDuration = schedule.endTime - schedule.startTime
                    if (_elapsedTimeMs.value >= requiredDuration * 0.8) {
                        _timerState.value = TimerState.COMPLETED
                    } else {
                        _timerState.value = TimerState.MISSED
                    }
                    stopMonitoring()
                    break
                }
                
                delay(1000)
            }
        }
    }

    private fun stopMonitoring() {
        timerJob?.cancel()
        timerJob = null
        sensorManager.unregisterListener(this)
    }

    private fun checkConditions(schedule: StudySchedule, now: Long): Boolean {
        // 1. Check time
        if (now < schedule.startTime) return false

        // 2. Check permissions
        if (!schedule.isOfflineMode) {
             if (permissionEngine.usageAccessState.value != PermissionState.GRANTED) {
                 return false
             }
        }

        // 3. Check specific mode conditions
        return if (schedule.isOfflineMode) {
            isFaceDown && isStable
        } else {
            schedule.selectedAppPackage?.let { checkForegroundApp(it, now) } ?: false
        }
    }
    
    private fun checkForegroundApp(targetPackage: String, now: Long): Boolean {
        val startTime = now - 1000 * 60 * 60 // Look back 1 hour to find current state
        val events = usageStatsManager.queryEvents(startTime, now)
        val event = UsageEvents.Event()
        
        var currentForeground: String? = null
        
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                currentForeground = event.packageName
            } else if (event.eventType == UsageEvents.Event.ACTIVITY_PAUSED || event.eventType == UsageEvents.Event.ACTIVITY_STOPPED) {
                if (currentForeground == event.packageName) {
                    currentForeground = null
                }
            }
        }
        
        return currentForeground == targetPackage
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_ACCELEROMETER) {
            val z = event.values[2]
            // Face down means Z is close to -9.8 (gravity pointing "out" of screen)
            isFaceDown = z < -8.0f 

            val now = System.currentTimeMillis()
            if (now - lastSensorUpdateTime > 500) {
                val dx = abs(event.values[0] - lastAccelValues[0])
                val dy = abs(event.values[1] - lastAccelValues[1])
                val dz = abs(event.values[2] - lastAccelValues[2])
                
                isStable = (dx < 0.5f && dy < 0.5f && dz < 0.5f)
                
                lastAccelValues[0] = event.values[0]
                lastAccelValues[1] = event.values[1]
                lastAccelValues[2] = event.values[2]
                lastSensorUpdateTime = now
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    companion object {
        @Volatile
        private var INSTANCE: TimerEngine? = null

        fun getInstance(context: Context, permissionEngine: PermissionEngine): TimerEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: TimerEngine(context.applicationContext, permissionEngine).also { INSTANCE = it }
            }
        }
    }
}
