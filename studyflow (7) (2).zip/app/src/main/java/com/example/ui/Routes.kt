package com.example.ui

import kotlinx.serialization.Serializable

@Serializable
object HomeRoute

@Serializable
object ScheduleRoute

@Serializable
object HistoryRoute

@Serializable
object ProgressRoute

@Serializable
object SettingsRoute
