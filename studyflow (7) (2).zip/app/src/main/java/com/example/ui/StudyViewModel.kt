package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.StudySchedule
import com.example.data.StudySession
import com.example.engine.PermissionState
import com.example.engine.PermissionType
import com.example.engine.StudyFlowCoreEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.delay

enum class StartupState {
    LOADING,
    NEEDS_SETUP,
    READY
}

class StudyViewModel(application: Application) : AndroidViewModel(application) {
    private val engine = StudyFlowCoreEngine.getInstance(application)

    private val _startupState = MutableStateFlow(StartupState.LOADING)
    val startupState = _startupState.asStateFlow()

    init {
        viewModelScope.launch {
            delay(1500) // Splash minimum duration
            val name = engine.userName.first()
            if (name.isBlank()) {
                _startupState.value = StartupState.NEEDS_SETUP
            } else {
                _startupState.value = StartupState.READY
            }
        }
    }

    val userName: StateFlow<String> = engine.userName.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), ""
    )

    val allSchedules: StateFlow<List<StudySchedule>> = engine.studyDao.getAllSchedules().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val allSessions: StateFlow<List<StudySession>> = engine.historyEngine.historySessions

    val totalStudyTime: StateFlow<Long?> = engine.studyDao.getTotalStudyTime().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), 0L
    )
    
    val notificationPermissionState: StateFlow<PermissionState> = engine.permissionEngine.notificationState
    val usageAccessPermissionState: StateFlow<PermissionState> = engine.permissionEngine.usageAccessState
    val batteryOptimizationPermissionState: StateFlow<PermissionState> = engine.permissionEngine.batteryOptimizationState
    
    val runningSchedule: StateFlow<StudySchedule?> = engine.runningSchedule
    val timerDurationMs: StateFlow<Long> = engine.timerDurationMs
    val timerState = engine.timerState
    val progressStats = engine.progressStats
    val chatHistory = engine.assistantEngine.chatHistory
    
    fun sendChatMessage(text: String) {
        engine.assistantEngine.sendMessage(text)
    }
    
    fun setRunningSchedule(schedule: StudySchedule?) {
        engine.setRunningSchedule(schedule)
    }
    
    fun markAsSkipped(scheduleId: Int) {
        engine.markAsSkipped(scheduleId)
    }
    
    private val _pendingPermissionRequest = MutableStateFlow<PermissionType?>(null)
    val pendingPermissionRequest: StateFlow<PermissionType?> = _pendingPermissionRequest.asStateFlow()

    fun requestPermission(type: PermissionType) {
        _pendingPermissionRequest.value = type
    }
    
    fun clearPermissionRequest() {
        _pendingPermissionRequest.value = null
    }

    fun getUsageAccessIntent() = engine.permissionEngine.getUsageAccessIntent()
    fun getBatteryOptimizationIntent() = engine.permissionEngine.getBatteryOptimizationIntent()

    fun refreshPermissions() {
        engine.permissionEngine.refreshPermissions()
    }

    fun markSetupComplete() {
        _startupState.value = StartupState.READY
    }

    fun updateUserName(name: String) {
        engine.updateUserName(name)
    }

    fun addSchedule(schedule: StudySchedule) {
        viewModelScope.launch {
            engine.studyDao.insertSchedule(schedule)
        }
    }
    
    fun deleteSchedule(id: Int) {
        viewModelScope.launch {
            engine.studyDao.deleteSchedule(id)
        }
    }
    
    fun deleteSession(id: Int) {
        engine.historyEngine.deleteSession(id)
    }
    
    fun createBackup(uri: android.net.Uri, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = engine.backupEngine.createBackup(uri)
            if (result.isSuccess) {
                onResult(true, "Backup created successfully")
            } else {
                onResult(false, result.exceptionOrNull()?.message ?: "Unknown error")
            }
        }
    }
    
    fun restoreBackup(uri: android.net.Uri, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = engine.backupEngine.restoreBackup(uri)
            if (result.isSuccess) {
                val data = result.getOrNull()
                if (data != null) {
                    engine.backupEngine.commitRestore(data)
                    onResult(true, "Data restored successfully")
                } else {
                    onResult(false, "Invalid backup data")
                }
            } else {
                onResult(false, result.exceptionOrNull()?.message ?: "Invalid backup file")
            }
        }
    }
}
