package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepCharcoal = Color(0xFF121212)
val DarkCharcoal = Color(0xFF1E1E1E)
val LightCharcoal = Color(0xFF2C2C2C)

val SkyBlue = Color(0xFF5AC8FA)
val CyanAccent = Color(0xFF00E5FF)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFAAAAAA)
val TextTertiary = Color(0xFF666666)

val GradientStart = Color(0xFF1A237E)
val GradientEnd = Color(0xFF00E5FF)

val SuccessGreen = Color(0xFF00C853)
val WarningOrange = Color(0xFFFFAB00)
val ErrorRed = Color(0xFFFF3D00)
val PausedYellow = Color(0xFFFFEA00)
