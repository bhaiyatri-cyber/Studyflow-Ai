package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Entity(tableName = "schedules")
@Serializable
data class StudySchedule(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subjectName: String,
    val subjectIcon: String = "MenuBook", // default icon
    val description: String = "",
    val startTime: Long, // timestamp
    val endTime: Long, // timestamp
    val repeatType: String, // ONE_TIME, DAILY, WEEKLY, MONTHLY, CUSTOM
    val isOfflineMode: Boolean,
    val selectedAppPackage: String? = null,
    val colorAccent: Long, // color value
    val reminderMinutes: Int = 0, // 0 for off
    val priority: String = "Medium", // Low, Medium, High
    val notes: String = "",
    val status: String = "Upcoming" // Upcoming, Waiting, Running, Paused, Completed, Missed
)

@Entity(tableName = "chat_messages")
@Serializable
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val text: String,
    val isUser: Boolean,
    val timestamp: Long
)

@Entity(tableName = "sessions")
@Serializable
data class StudySession(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val scheduleId: Int,
    val subjectName: String,
    val date: Long,
    val scheduledDurationMs: Long,
    val actualDurationMs: Long,
    val status: String,
    val isOfflineMode: Boolean,
    val selectedAppPackage: String? = null,
    val notes: String = "",
    val timelineEvents: String = ""
)

@Serializable
data class BackupData(
    val version: Int = 2,
    val userName: String,
    val userAvatar: String = "person",
    val studyGoal: String = "Learn something new",
    val dailyStudyGoalMs: Long = 7200000L,
    val createdDate: Long = 0L,
    val schedules: List<StudySchedule> = emptyList(),
    val sessions: List<StudySession> = emptyList(),
    val chatMessages: List<ChatMessageEntity> = emptyList()
)
