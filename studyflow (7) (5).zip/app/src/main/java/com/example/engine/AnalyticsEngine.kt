package com.example.engine

import com.example.data.StudyDao
import com.example.data.StudySession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

data class AnalyticsDashboard(
    val dailyStudyMs: Long,
    val weeklyStudyMs: Long,
    val monthlyStudyMs: Long,
    val yearlyStudyMs: Long,
    
    val totalSessions: Int,
    val completedSessions: Int,
    val missedSessions: Int,
    val skippedSessions: Int,
    
    val averageStudyTimeMs: Long,
    val averageSessionLengthMs: Long,
    
    val bestStudyDay: String,
    val bestStudyHour: String,
    
    val mostStudiedSubject: String,
    val leastStudiedSubject: String,
    
    val focusScoreTrend: List<Float>,
    val streakHistory: List<Int>,
    
    val level: Int,
    val xp: Int,
    val achievementsCount: Int,
    
    val hasData: Boolean,
    val dailyGoalMs: Long = 7200000L,
    val dailyGoalProgress: Float = 0f
)

data class SubjectAnalyticsItem(
    val subjectName: String,
    val totalStudyTimeMs: Long,
    val completedSessions: Int,
    val missedSessions: Int,
    val averageTimeMs: Long,
    val longestSessionMs: Long,
    val lastStudiedMs: Long,
    val completionPercentage: Float
)

data class TimeAnalytics(
    val morningStudyMs: Long,
    val afternoonStudyMs: Long,
    val eveningStudyMs: Long,
    val nightStudyMs: Long,
    val bestPerformingTime: String,
    val weakestTime: String
)

data class GoalAnalytics(
    val todayGoalMs: Long,
    val weeklyGoalMs: Long,
    val monthlyGoalMs: Long,
    val todayProgressMs: Long,
    val weeklyProgressMs: Long,
    val monthlyProgressMs: Long,
    val goalCompletionPercentage: Float,
    val remainingGoalMs: Long
)

data class FocusAnalytics(
    val longestFocusSessionMs: Long,
    val averageFocusSessionMs: Long,
    val pauseCount: Int,
    val resumeCount: Int,
    val interruptedSessions: Int
)

data class OnlineOfflineAnalytics(
    val studyAppsUsage: Map<String, Long>,
    val mostUsedApp: String,
    val averageAppSessionMs: Long,
    val offlineStudyTimeMs: Long,
    val offlineSessions: Int,
    val averageOfflineSessionMs: Long
)

enum class ReportType {
    DAILY, WEEKLY, MONTHLY, YEARLY
}

data class Report(
    val type: ReportType,
    val dateRange: String,
    val studyTimeMs: Long,
    val completedSessions: Int,
    val missedSessions: Int,
    val focusScore: Float
)

class AnalyticsEngine private constructor(
    private val studyDao: StudyDao,
    private val progressEngine: ProgressEngine
) {
    private val engineScope = CoroutineScope(Dispatchers.Default)
    
    private val _dashboard = MutableStateFlow(createEmptyDashboard())
    val dashboard: StateFlow<AnalyticsDashboard> = _dashboard.asStateFlow()
    
    private val _subjectAnalytics = MutableStateFlow<List<SubjectAnalyticsItem>>(emptyList())
    val subjectAnalytics: StateFlow<List<SubjectAnalyticsItem>> = _subjectAnalytics.asStateFlow()
    
    private val _timeAnalytics = MutableStateFlow(createEmptyTimeAnalytics())
    val timeAnalytics: StateFlow<TimeAnalytics> = _timeAnalytics.asStateFlow()
    
    private val _goalAnalytics = MutableStateFlow(createEmptyGoalAnalytics())
    val goalAnalytics: StateFlow<GoalAnalytics> = _goalAnalytics.asStateFlow()
    
    private val _focusAnalytics = MutableStateFlow(createEmptyFocusAnalytics())
    val focusAnalytics: StateFlow<FocusAnalytics> = _focusAnalytics.asStateFlow()
    
    private val _onlineOfflineAnalytics = MutableStateFlow(createEmptyOnlineOfflineAnalytics())
    val onlineOfflineAnalytics: StateFlow<OnlineOfflineAnalytics> = _onlineOfflineAnalytics.asStateFlow()
    
    private val _reports = MutableStateFlow<List<Report>>(emptyList())
    val reports: StateFlow<List<Report>> = _reports.asStateFlow()
    
    private val _insights = MutableStateFlow<List<String>>(emptyList())
    val insights: StateFlow<List<String>> = _insights.asStateFlow()
    
    init {
        engineScope.launch {
            studyDao.getAllSessions().collect { sessions ->
                calculateAnalytics(sessions)
            }
        }
    }
    
    private fun calculateAnalytics(sessions: List<StudySession>) {
        if (sessions.isEmpty() || !sessions.any { it.actualDurationMs > 0 }) {
            _dashboard.value = createEmptyDashboard()
            _subjectAnalytics.value = emptyList()
            _timeAnalytics.value = createEmptyTimeAnalytics()
            _goalAnalytics.value = createEmptyGoalAnalytics()
            _focusAnalytics.value = createEmptyFocusAnalytics()
            _onlineOfflineAnalytics.value = createEmptyOnlineOfflineAnalytics()
            _reports.value = emptyList()
            _insights.value = emptyList()
            return
        }
        
        val zoneId = ZoneId.systemDefault()
        val now = Instant.now().atZone(zoneId)
        val todayStart = now.toLocalDate().atStartOfDay(zoneId).toInstant().toEpochMilli()
        val weekStart = now.toLocalDate().minusDays(now.dayOfWeek.value.toLong() - 1).atStartOfDay(zoneId).toInstant().toEpochMilli()
        val monthStart = now.toLocalDate().withDayOfMonth(1).atStartOfDay(zoneId).toInstant().toEpochMilli()
        val yearStart = now.toLocalDate().withDayOfYear(1).atStartOfDay(zoneId).toInstant().toEpochMilli()

        var dailyStudy = 0L
        var weeklyStudy = 0L
        var monthlyStudy = 0L
        var yearlyStudy = 0L
        
        var completed = 0
        var missed = 0
        var skipped = 0
        
        val dayCounts = mutableMapOf<java.time.DayOfWeek, Long>()
        val hourCounts = mutableMapOf<Int, Long>()
        
        val subjectStats = mutableMapOf<String, SubjectTempStats>()
        
        var morning = 0L
        var afternoon = 0L
        var evening = 0L
        var night = 0L
        
        var longestFocus = 0L
        var pauseCount = 0
        var resumeCount = 0
        var interruptedSessions = 0
        
        val appUsage = mutableMapOf<String, Long>()
        var offlineTime = 0L
        var offlineSessions = 0
        
        val dailyFocusScores = mutableMapOf<LocalDate, Pair<Long, Long>>() // date -> (actualMs, scheduledMs)

        for (session in sessions) {
            val sDate = session.date
            val sDur = session.actualDurationMs
            val schedDur = session.scheduledDurationMs
            
            when (session.status) {
                TaskStatus.COMPLETED.displayName -> completed++
                TaskStatus.MISSED.displayName -> missed++
                "Skipped" -> skipped++
            }
            
            if (sDur > 0) {
                if (sDate >= todayStart) dailyStudy += sDur
                if (sDate >= weekStart) weeklyStudy += sDur
                if (sDate >= monthStart) monthlyStudy += sDur
                if (sDate >= yearStart) yearlyStudy += sDur
                
                val dt = Instant.ofEpochMilli(sDate).atZone(zoneId)
                dayCounts[dt.dayOfWeek] = (dayCounts[dt.dayOfWeek] ?: 0L) + sDur
                hourCounts[dt.hour] = (hourCounts[dt.hour] ?: 0L) + sDur
                
                val sStats = subjectStats.getOrPut(session.subjectName) { SubjectTempStats() }
                sStats.totalTime += sDur
                if (session.status == TaskStatus.COMPLETED.displayName) sStats.completed++
                if (session.status == TaskStatus.MISSED.displayName) sStats.missed++
                if (sDur > sStats.longestSession) sStats.longestSession = sDur
                if (sDate > sStats.lastStudied) sStats.lastStudied = sDate
                sStats.totalScheduled += schedDur
                
                val h = dt.hour
                if (h in 5..11) morning += sDur
                else if (h in 12..16) afternoon += sDur
                else if (h in 17..20) evening += sDur
                else night += sDur
                
                if (sDur > longestFocus) longestFocus = sDur
                
                if (session.isOfflineMode) {
                    offlineTime += sDur
                    offlineSessions++
                } else {
                    session.selectedAppPackage?.let {
                        appUsage[it] = (appUsage[it] ?: 0L) + sDur
                    }
                }
                
                val dateKey = dt.toLocalDate()
                val (currAct, currSched) = dailyFocusScores[dateKey] ?: Pair(0L, 0L)
                dailyFocusScores[dateKey] = Pair(currAct + sDur, currSched + schedDur)
            }
        }
        
        val bestDay = dayCounts.maxByOrNull { it.value }?.key?.name?.lowercase()?.replaceFirstChar { it.uppercase() } ?: "None"
        val bestHour = hourCounts.maxByOrNull { it.value }?.key?.let { h ->
            if (h == 0) "12 AM" else if (h < 12) "$h AM" else if (h == 12) "12 PM" else "${h-12} PM"
        } ?: "None"
        
        val mostStudied = subjectStats.maxByOrNull { it.value.totalTime }?.key ?: "None"
        val leastStudied = subjectStats.minByOrNull { it.value.totalTime }?.key ?: "None"
        
        val validDurSessions = sessions.filter { it.actualDurationMs > 0 }
        val avgStudyTime = if (dayCounts.isNotEmpty()) validDurSessions.sumOf { it.actualDurationMs } / dayCounts.size else 0L
        val avgSessionLen = if (validDurSessions.isNotEmpty()) validDurSessions.sumOf { it.actualDurationMs } / validDurSessions.size else 0L

        // Focus Score Trend (last 7 days)
        val trend = mutableListOf<Float>()
        for (i in 6 downTo 0) {
            val d = now.toLocalDate().minusDays(i.toLong())
            val stats = dailyFocusScores[d]
            if (stats != null && stats.second > 0) {
                trend.add(minOf(100f, (stats.first.toFloat() / stats.second.toFloat()) * 100f))
            } else {
                trend.add(0f)
            }
        }

        val prog = progressEngine.progressStats.value
        _dashboard.value = AnalyticsDashboard(
            dailyStudyMs = dailyStudy,
            weeklyStudyMs = weeklyStudy,
            monthlyStudyMs = monthlyStudy,
            yearlyStudyMs = yearlyStudy,
            totalSessions = sessions.size,
            completedSessions = completed,
            missedSessions = missed,
            skippedSessions = skipped,
            averageStudyTimeMs = avgStudyTime,
            averageSessionLengthMs = avgSessionLen,
            bestStudyDay = bestDay,
            bestStudyHour = bestHour,
            mostStudiedSubject = mostStudied,
            leastStudiedSubject = leastStudied,
            focusScoreTrend = trend,
            streakHistory = listOf(prog.streak), // read from progress engine
            level = prog.level,
            xp = prog.xp,
            achievementsCount = prog.achievements.count { it.isUnlocked },
            hasData = true,
            dailyGoalMs = 7200000L,
            dailyGoalProgress = (dailyStudy.toFloat() / 7200000f).coerceIn(0f, 1f)
        )
        
        _subjectAnalytics.value = subjectStats.map { (name, s) ->
            SubjectAnalyticsItem(
                subjectName = name,
                totalStudyTimeMs = s.totalTime,
                completedSessions = s.completed,
                missedSessions = s.missed,
                averageTimeMs = if ((s.completed + s.missed) > 0) s.totalTime / (s.completed + s.missed) else s.totalTime,
                longestSessionMs = s.longestSession,
                lastStudiedMs = s.lastStudied,
                completionPercentage = if (s.totalScheduled > 0) minOf(100f, (s.totalTime.toFloat() / s.totalScheduled.toFloat()) * 100f) else 0f
            )
        }.sortedByDescending { it.totalStudyTimeMs }
        
        val times = listOf(
            "Morning" to morning,
            "Afternoon" to afternoon,
            "Evening" to evening,
            "Night" to night
        )
        val bestTime = times.maxByOrNull { it.second }?.first ?: "None"
        val weakestTime = times.minByOrNull { it.second }?.first ?: "None"
        
        _timeAnalytics.value = TimeAnalytics(
            morningStudyMs = morning,
            afternoonStudyMs = afternoon,
            eveningStudyMs = evening,
            nightStudyMs = night,
            bestPerformingTime = bestTime,
            weakestTime = weakestTime
        )
        
        _goalAnalytics.value = GoalAnalytics(
            todayGoalMs = 4 * 3600 * 1000L, // 4 hours
            weeklyGoalMs = 20 * 3600 * 1000L, // 20 hours
            monthlyGoalMs = 80 * 3600 * 1000L, // 80 hours
            todayProgressMs = dailyStudy,
            weeklyProgressMs = weeklyStudy,
            monthlyProgressMs = monthlyStudy,
            goalCompletionPercentage = minOf(100f, (dailyStudy.toFloat() / (4 * 3600 * 1000f)) * 100f),
            remainingGoalMs = maxOf(0L, (4 * 3600 * 1000L) - dailyStudy)
        )
        
        _focusAnalytics.value = FocusAnalytics(
            longestFocusSessionMs = longestFocus,
            averageFocusSessionMs = avgSessionLen,
            pauseCount = pauseCount,
            resumeCount = resumeCount,
            interruptedSessions = interruptedSessions
        )
        
        _onlineOfflineAnalytics.value = OnlineOfflineAnalytics(
            studyAppsUsage = appUsage,
            mostUsedApp = appUsage.maxByOrNull { it.value }?.key ?: "None",
            averageAppSessionMs = if (validDurSessions.size - offlineSessions > 0) (validDurSessions.sumOf { it.actualDurationMs } - offlineTime) / (validDurSessions.size - offlineSessions) else 0L,
            offlineStudyTimeMs = offlineTime,
            offlineSessions = offlineSessions,
            averageOfflineSessionMs = if (offlineSessions > 0) offlineTime / offlineSessions else 0L
        )
        
        _reports.value = generateReports(sessions)
        _insights.value = generateInsights(sessions, _dashboard.value, _timeAnalytics.value, _subjectAnalytics.value)
    }

    private fun generateReports(sessions: List<StudySession>): List<Report> {
        return listOf(
            Report(ReportType.DAILY, "Today", _dashboard.value.dailyStudyMs, _dashboard.value.completedSessions, _dashboard.value.missedSessions, _dashboard.value.focusScoreTrend.lastOrNull() ?: 0f)
        )
    }

    private fun generateInsights(sessions: List<StudySession>, dash: AnalyticsDashboard, time: TimeAnalytics, subjects: List<SubjectAnalyticsItem>): List<String> {
        val insights = mutableListOf<String>()
        if (time.bestPerformingTime != "None") {
            insights.add("You study best during the ${time.bestPerformingTime}.")
        }
        val topSubject = subjects.firstOrNull()
        if (topSubject != null) {
            insights.add("${topSubject.subjectName} has your highest completion rate.")
        }
        val mostMissed = subjects.maxByOrNull { it.missedSessions }
        if (mostMissed != null && mostMissed.missedSessions > 0) {
            insights.add("You missed ${mostMissed.subjectName} ${mostMissed.missedSessions} times.")
        }
        return insights
    }
    
    private fun createEmptyDashboard() = AnalyticsDashboard(0L, 0L, 0L, 0L, 0, 0, 0, 0, 0L, 0L, "None", "None", "None", "None", emptyList(), emptyList(), 1, 0, 0, false)
    private fun createEmptyTimeAnalytics() = TimeAnalytics(0L, 0L, 0L, 0L, "None", "None")
    private fun createEmptyGoalAnalytics() = GoalAnalytics(0L, 0L, 0L, 0L, 0L, 0L, 0f, 0L)
    private fun createEmptyFocusAnalytics() = FocusAnalytics(0L, 0L, 0, 0, 0)
    private fun createEmptyOnlineOfflineAnalytics() = OnlineOfflineAnalytics(emptyMap(), "None", 0L, 0L, 0, 0L)

    class SubjectTempStats {
        var totalTime = 0L
        var completed = 0
        var missed = 0
        var longestSession = 0L
        var lastStudied = 0L
        var totalScheduled = 0L
    }

    companion object {
        @Volatile
        private var INSTANCE: AnalyticsEngine? = null
        fun getInstance(studyDao: StudyDao, progressEngine: ProgressEngine): AnalyticsEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: AnalyticsEngine(studyDao, progressEngine).also { INSTANCE = it }
            }
        }
    }
}
