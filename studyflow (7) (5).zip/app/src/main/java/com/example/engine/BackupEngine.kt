package com.example.engine

import android.content.Context
import android.net.Uri
import com.example.data.BackupData
import com.example.data.StudyDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.InputStreamReader
import java.io.OutputStreamWriter

class BackupEngine private constructor(
    private val context: Context,
    private val studyDao: StudyDao,
    private val coreEngine: StudyFlowCoreEngine
) {

    suspend fun createBackup(uri: Uri): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val userName = coreEngine.userName.first()
            val userAvatar = coreEngine.settingsEngine.userAvatar.first()
            val studyGoal = coreEngine.settingsEngine.studyGoal.first()
            val dailyGoalMs = coreEngine.settingsEngine.dailyStudyGoalMs.first()
            val createdDate = coreEngine.settingsEngine.createdDate.first()
            
            val schedules = studyDao.getAllSchedules().first()
            val sessions = studyDao.getAllSessions().first()
            val chatMessages = studyDao.getAllChatMessages().first()

            val backupData = BackupData(
                version = 2,
                userName = userName,
                userAvatar = userAvatar,
                studyGoal = studyGoal,
                dailyStudyGoalMs = dailyGoalMs,
                createdDate = createdDate,
                schedules = schedules,
                sessions = sessions,
                chatMessages = chatMessages
            )

            val jsonString = Json { ignoreUnknownKeys = true }.encodeToString(backupData)

            context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                OutputStreamWriter(outputStream).use { writer ->
                    writer.write(jsonString)
                }
            } ?: throw Exception("Failed to open output stream")

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun restoreBackup(uri: Uri): Result<BackupData> = withContext(Dispatchers.IO) {
        try {
            val jsonString = context.contentResolver.openInputStream(uri)?.use { inputStream ->
                InputStreamReader(inputStream).use { reader ->
                    reader.readText()
                }
            } ?: throw Exception("Failed to open input stream")

            val backupData = Json { ignoreUnknownKeys = true }.decodeFromString<BackupData>(jsonString)

            // Validate data briefly (not strictly required but good to have)
            if (backupData.schedules == null || backupData.sessions == null) {
                throw Exception("Invalid backup format")
            }

            // Restore username
            coreEngine.updateUserName(backupData.userName)
            
            // Restore profile
            coreEngine.settingsEngine.updateUserAvatar(backupData.userAvatar)
            coreEngine.settingsEngine.updateStudyGoal(backupData.studyGoal)
            coreEngine.settingsEngine.updateDailyStudyGoalMs(backupData.dailyStudyGoalMs)
            coreEngine.settingsEngine.updateCreatedDate(backupData.createdDate)

            // Clear existing and restore new data
            // We need DAO methods to clear tables, or we can just delete everything and insert.
            // But we don't have clear tables in DAO right now. We can add them.
            
            Result.success(backupData)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun commitRestore(backupData: BackupData) = withContext(Dispatchers.IO) {
        studyDao.clearAllSchedules()
        studyDao.clearAllSessions()
        studyDao.clearAllChatMessages()
        
        backupData.schedules.forEach { studyDao.insertSchedule(it) }
        backupData.sessions.forEach { studyDao.insertSession(it) }
        backupData.chatMessages.forEach { studyDao.insertChatMessage(it) }
    }

    companion object {
        @Volatile
        private var INSTANCE: BackupEngine? = null

        fun getInstance(
            context: Context,
            studyDao: StudyDao,
            coreEngine: StudyFlowCoreEngine
        ): BackupEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: BackupEngine(context, studyDao, coreEngine).also { INSTANCE = it }
            }
        }
    }
}
