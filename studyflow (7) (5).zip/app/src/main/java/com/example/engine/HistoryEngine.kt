package com.example.engine

import com.example.data.StudyDao
import com.example.data.StudySchedule
import com.example.data.StudySession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HistoryEngine private constructor(private val studyDao: StudyDao) {
    private val engineScope = CoroutineScope(Dispatchers.Default)

    val historySessions: StateFlow<List<StudySession>> = studyDao.getAllSessions()
        .stateIn(engineScope, SharingStarted.Lazily, emptyList())

    fun recordSession(schedule: StudySchedule, finalStatus: TaskStatus, actualDurationMs: Long) {
        engineScope.launch {
            val sessions = studyDao.getAllSessions().first()
            val now = System.currentTimeMillis()
            
            val existing = sessions.find { 
                it.scheduleId == schedule.id && (now - it.date) < (12L * 60 * 60 * 1000)
            }
            if (existing != null) {
                return@launch
            }

            val session = StudySession(
                scheduleId = schedule.id,
                subjectName = schedule.subjectName,
                date = now,
                scheduledDurationMs = schedule.endTime - schedule.startTime,
                actualDurationMs = actualDurationMs,
                status = finalStatus.displayName,
                isOfflineMode = schedule.isOfflineMode,
                selectedAppPackage = schedule.selectedAppPackage,
                notes = schedule.notes,
                timelineEvents = "Schedule created -> ${finalStatus.displayName}"
            )
            studyDao.insertSession(session)
        }
    }

    fun deleteSession(sessionId: Int) {
        engineScope.launch {
            studyDao.deleteSession(sessionId)
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: HistoryEngine? = null

        fun getInstance(studyDao: StudyDao): HistoryEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: HistoryEngine(studyDao).also { INSTANCE = it }
            }
        }
    }
}
