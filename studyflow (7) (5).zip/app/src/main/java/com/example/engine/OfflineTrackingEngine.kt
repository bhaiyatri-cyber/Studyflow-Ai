package com.example.engine

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.PowerManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

class OfflineTrackingEngine private constructor(private val context: Context) : SensorEventListener {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    
    private val _isTrackingConditionsMet = MutableStateFlow(false)
    val isTrackingConditionsMet: StateFlow<Boolean> = _isTrackingConditionsMet.asStateFlow()

    private var isFaceDown = false
    private var isStable = false
    private var lastAccelValues = FloatArray(3)
    private var lastSensorUpdateTime = 0L

    fun startMonitoring() {
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
        updateConditions()
    }

    fun stopMonitoring() {
        sensorManager.unregisterListener(this)
        _isTrackingConditionsMet.value = false
        isFaceDown = false
        isStable = false
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_ACCELEROMETER) {
            val z = event.values[2]
            isFaceDown = z < -8.0f 

            val now = System.currentTimeMillis()
            if (now - lastSensorUpdateTime > 500) {
                val dx = abs(event.values[0] - lastAccelValues[0])
                val dy = abs(event.values[1] - lastAccelValues[1])
                val dz = abs(event.values[2] - lastAccelValues[2])
                
                isStable = (dx < 0.5f && dy < 0.5f && dz < 0.5f)
                
                lastAccelValues[0] = event.values[0]
                lastAccelValues[1] = event.values[1]
                lastAccelValues[2] = event.values[2]
                lastSensorUpdateTime = now
                
                updateConditions()
            }
        }
    }
    
    private fun updateConditions() {
        // "If screen unlocks, motion changes, or phone is used -> Timer pauses immediately"
        // Phone is used or screen unlocks: meaning screen is interactive
        val isScreenOn = powerManager.isInteractive
        
        // Timer counts ONLY if phone is face-down and stable and screen is not interactively being used
        // Usually face-down turns off screen, but just in case:
        _isTrackingConditionsMet.value = isFaceDown && isStable && !isScreenOn
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    companion object {
        @Volatile
        private var INSTANCE: OfflineTrackingEngine? = null

        fun getInstance(context: Context): OfflineTrackingEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: OfflineTrackingEngine(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
