package com.example.engine

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityManager

enum class PermissionType {
    NOTIFICATIONS,
    USAGE_ACCESS,
    FOREGROUND_SERVICE,
    BATTERY_OPTIMIZATION,
    OVERLAY,
    ACCESSIBILITY
}

enum class PermissionState {
    GRANTED,
    MISSING,
    REQUIRED,
    OPTIONAL,
    DISABLED
}

class PermissionEngine private constructor(private val context: Context) {

    private val _notificationState = MutableStateFlow(checkNotificationPermission())
    val notificationState: StateFlow<PermissionState> = _notificationState.asStateFlow()

    private val _usageAccessState = MutableStateFlow(checkUsageAccessPermission())
    val usageAccessState: StateFlow<PermissionState> = _usageAccessState.asStateFlow()
    
    private val _foregroundServiceState = MutableStateFlow(checkForegroundServicePermission())
    val foregroundServiceState: StateFlow<PermissionState> = _foregroundServiceState.asStateFlow()

    private val _batteryOptimizationState = MutableStateFlow(checkBatteryOptimization())
    val batteryOptimizationState: StateFlow<PermissionState> = _batteryOptimizationState.asStateFlow()
    
    private val _overlayState = MutableStateFlow(checkOverlayPermission())
    val overlayState: StateFlow<PermissionState> = _overlayState.asStateFlow()
    
    private val _accessibilityState = MutableStateFlow(checkAccessibilityPermission())
    val accessibilityState: StateFlow<PermissionState> = _accessibilityState.asStateFlow()

    fun refreshPermissions() {
        _notificationState.value = checkNotificationPermission()
        _usageAccessState.value = checkUsageAccessPermission()
        _foregroundServiceState.value = checkForegroundServicePermission()
        _batteryOptimizationState.value = checkBatteryOptimization()
        _overlayState.value = checkOverlayPermission()
        _accessibilityState.value = checkAccessibilityPermission()
    }

    fun getUsageAccessIntent(): Intent {
        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            intent.data = android.net.Uri.parse("package:${context.packageName}")
        }
        return intent
    }

    fun getBatteryOptimizationIntent(): Intent {
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
        intent.data = android.net.Uri.parse("package:${context.packageName}")
        return intent
    }
    
    fun getOverlayIntent(): Intent {
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
        intent.data = android.net.Uri.parse("package:${context.packageName}")
        return intent
    }
    
    fun getAccessibilityIntent(): Intent {
        return Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
    }

    private fun checkNotificationPermission(): PermissionState {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return if (ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                PermissionState.GRANTED
            } else {
                PermissionState.MISSING
            }
        }
        return PermissionState.GRANTED
    }

    private fun checkUsageAccessPermission(): PermissionState {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                context.packageName
            )
        }
        return if (mode == AppOpsManager.MODE_ALLOWED) {
            PermissionState.GRANTED
        } else {
            PermissionState.MISSING
        }
    }
    
    private fun checkForegroundServicePermission(): PermissionState {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            return if (ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.FOREGROUND_SERVICE
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                PermissionState.GRANTED
            } else {
                PermissionState.MISSING
            }
        }
        return PermissionState.GRANTED
    }

    private fun checkBatteryOptimization(): PermissionState {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return if (powerManager.isIgnoringBatteryOptimizations(context.packageName)) {
            PermissionState.GRANTED
        } else {
            PermissionState.MISSING
        }
    }
    
    private fun checkOverlayPermission(): PermissionState {
        return if (Settings.canDrawOverlays(context)) {
            PermissionState.GRANTED
        } else {
            PermissionState.MISSING // OR OPTIONAL
        }
    }
    
    private fun checkAccessibilityPermission(): PermissionState {
        val accessibilityManager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = accessibilityManager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        for (enabledService in enabledServices) {
            val serviceInfo = enabledService.resolveInfo.serviceInfo
            if (serviceInfo.packageName == context.packageName) {
                return PermissionState.GRANTED
            }
        }
        return PermissionState.MISSING // OR OPTIONAL
    }

    companion object {
        @Volatile
        private var INSTANCE: PermissionEngine? = null

        fun getInstance(context: Context): PermissionEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: PermissionEngine(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
