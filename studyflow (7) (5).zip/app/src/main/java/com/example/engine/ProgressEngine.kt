package com.example.engine

import com.example.data.StudyDao
import com.example.data.StudySession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Calendar

data class Achievement(
    val id: String,
    val name: String,
    val description: String,
    val isUnlocked: Boolean,
    val progress: Float, // 0.0 to 1.0
    val targetValue: Int,
    val currentValue: Int,
    val iconName: String = "Star" // Can be used for icon mapping in UI
)

data class ProgressStats(
    val totalStudyTimeMs: Long = 0L,
    val xp: Int = 0,
    val level: Int = 1,
    val xpToNextLevel: Int = 1000,
    val currentLevelXp: Int = 0,
    val streak: Int = 0,
    val completionPercentage: Float = 0f,
    val focusScore: Int = 0,
    val subjectAnalytics: Map<String, Long> = emptyMap(),
    val achievements: List<Achievement> = emptyList(),
    val hasData: Boolean = false
)

class ProgressEngine private constructor(private val studyDao: StudyDao) {
    private val engineScope = CoroutineScope(Dispatchers.Default)

    private val _progressStats = MutableStateFlow(ProgressStats())
    val progressStats: StateFlow<ProgressStats> = _progressStats.asStateFlow()

    init {
        engineScope.launch {
            studyDao.getAllSessions().collect { sessions ->
                calculateStats(sessions)
            }
        }
    }

    private fun calculateStats(sessions: List<StudySession>) {
        val validSessions = sessions.filter { it.actualDurationMs > 0 }
        
        if (validSessions.isEmpty()) {
            _progressStats.value = ProgressStats(
                hasData = false,
                achievements = generateEmptyAchievements()
            )
            return
        }

        var totalStudyTimeMs = 0L
        var scheduledTimeMs = 0L
        var completedTasks = 0
        var totalXp = 0
        
        val subjectAnalytics = mutableMapOf<String, Long>()

        for (session in validSessions) {
            if (session.status == TaskStatus.COMPLETED.displayName) {
                totalStudyTimeMs += session.actualDurationMs
                scheduledTimeMs += session.scheduledDurationMs
                completedTasks++
                
                val currentSubjectTime = subjectAnalytics[session.subjectName] ?: 0L
                subjectAnalytics[session.subjectName] = currentSubjectTime + session.actualDurationMs
                
                // XP Calculation
                val minutes = (session.actualDurationMs / 60000).toInt()
                val sessionXp = minutes * 10
                val bonusXp = 50 // Bonus for completion
                val lengthBonus = (minutes / 60) * 50 // Bonus for longer sessions (1 hr+)
                totalXp += (sessionXp + bonusXp + lengthBonus)
            }
        }

        val streak = calculateStreak(validSessions)
        totalXp += streak * 10 // Bonus for streak

        val levelInfo = calculateLevel(totalXp)

        val completionPercentage = if (scheduledTimeMs > 0) {
            (totalStudyTimeMs.toFloat() / scheduledTimeMs.toFloat()) * 100f
        } else {
            0f
        }

        val focusScore = calculateFocusScore(completionPercentage)
        
        val achievements = calculateAchievements(
            totalStudyTimeMs = totalStudyTimeMs,
            completedTasks = completedTasks,
            streak = streak,
            subjectAnalytics = subjectAnalytics
        )

        _progressStats.value = ProgressStats(
            totalStudyTimeMs = totalStudyTimeMs,
            xp = totalXp,
            level = levelInfo.first,
            currentLevelXp = levelInfo.second,
            xpToNextLevel = levelInfo.third,
            streak = streak,
            completionPercentage = completionPercentage,
            focusScore = focusScore,
            subjectAnalytics = subjectAnalytics,
            achievements = achievements,
            hasData = true
        )
    }
    
    private fun calculateLevel(totalXp: Int): Triple<Int, Int, Int> {
        // Simple scaling: Level 1 = 0-999, Level 2 = 1000-2499, Level 3 = 2500-4499
        // Formula: xpReq = level * level * 500
        var currentLevel = 1
        var xpRequiredForNext = 1000
        var xpInCurrentLevel = totalXp
        
        while (true) {
            xpRequiredForNext = currentLevel * 1000
            if (xpInCurrentLevel >= xpRequiredForNext) {
                xpInCurrentLevel -= xpRequiredForNext
                currentLevel++
            } else {
                break
            }
        }
        
        return Triple(currentLevel, xpInCurrentLevel, xpRequiredForNext)
    }

    private fun generateEmptyAchievements(): List<Achievement> {
        return calculateAchievements(0L, 0, 0, emptyMap())
    }

    private fun calculateAchievements(
        totalStudyTimeMs: Long,
        completedTasks: Int,
        streak: Int,
        subjectAnalytics: Map<String, Long>
    ): List<Achievement> {
        val totalHours = (totalStudyTimeMs / (1000 * 60 * 60)).toInt()
        val maxSubjectHours = (subjectAnalytics.values.maxOrNull() ?: 0L) / (1000 * 60 * 60).toInt()
        
        return listOf(
            createAchievement(
                id = "first_step",
                name = "First Step",
                description = "Complete your first task",
                iconName = "Flag",
                currentValue = completedTasks,
                targetValue = 1
            ),
            createAchievement(
                id = "tasks_10",
                name = "Task Master",
                description = "Complete 10 tasks",
                iconName = "List",
                currentValue = completedTasks,
                targetValue = 10
            ),
            createAchievement(
                id = "tasks_50",
                name = "Productivity Machine",
                description = "Complete 50 tasks",
                iconName = "CheckCircle",
                currentValue = completedTasks,
                targetValue = 50
            ),
            createAchievement(
                id = "streak_7",
                name = "7 Day Streak",
                description = "Maintain a 7 day streak",
                iconName = "LocalFireDepartment",
                currentValue = streak,
                targetValue = 7
            ),
            createAchievement(
                id = "streak_30",
                name = "30 Day Streak",
                description = "Maintain a 30 day streak",
                iconName = "Whatshot",
                currentValue = streak,
                targetValue = 30
            ),
            createAchievement(
                id = "hours_100",
                name = "100 Hours Studied",
                description = "Reach 100 total hours of study time",
                iconName = "AccessTime",
                currentValue = totalHours,
                targetValue = 100
            ),
            createAchievement(
                id = "subject_mastery",
                name = "Subject Mastery",
                description = "Study a single subject for 10 hours",
                iconName = "School",
                currentValue = maxSubjectHours.toInt(),
                targetValue = 10
            )
        )
    }
    
    private fun createAchievement(
        id: String,
        name: String,
        description: String,
        iconName: String,
        currentValue: Int,
        targetValue: Int
    ): Achievement {
        val progress = if (targetValue > 0) (currentValue.toFloat() / targetValue.toFloat()).coerceIn(0f, 1f) else 0f
        return Achievement(
            id = id,
            name = name,
            description = description,
            isUnlocked = currentValue >= targetValue,
            progress = progress,
            targetValue = targetValue,
            currentValue = minOf(currentValue, targetValue),
            iconName = iconName
        )
    }

    private fun calculateStreak(sessions: List<StudySession>): Int {
        val completedSessions = sessions.filter { it.status == TaskStatus.COMPLETED.displayName }
            .sortedByDescending { it.date }
        
        if (completedSessions.isEmpty()) return 0
        
        var streak = 0
        var lastDay = -1L
        
        val zoneId = java.time.ZoneId.systemDefault()
        
        for (session in completedSessions) {
            val absoluteDay = java.time.Instant.ofEpochMilli(session.date).atZone(zoneId).toLocalDate().toEpochDay()
            
            if (lastDay == -1L) {
                val currentAbsoluteDay = java.time.LocalDate.now(zoneId).toEpochDay()
                if (absoluteDay == currentAbsoluteDay || absoluteDay == currentAbsoluteDay - 1) {
                    streak++
                    lastDay = absoluteDay
                } else {
                    break 
                }
            } else {
                if (absoluteDay == lastDay) {
                    continue 
                } else if (absoluteDay == lastDay - 1) {
                    streak++
                    lastDay = absoluteDay
                } else {
                    break 
                }
            }
        }
        return streak
    }

    private fun calculateFocusScore(completionRate: Float): Int {
        return minOf(100, maxOf(0, completionRate.toInt()))
    }

    companion object {
        @Volatile
        private var INSTANCE: ProgressEngine? = null

        fun getInstance(studyDao: StudyDao): ProgressEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: ProgressEngine(studyDao).also { INSTANCE = it }
            }
        }
    }
}
