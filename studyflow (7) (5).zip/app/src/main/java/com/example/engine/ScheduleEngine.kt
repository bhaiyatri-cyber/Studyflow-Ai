package com.example.engine

import com.example.data.StudyDao
import com.example.data.StudySchedule
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.example.engine.TaskStatus

class ScheduleEngine private constructor(
    private val studyDao: StudyDao,
    private val statusEngine: StatusEngine,
    private val notificationEngine: NotificationEngine,
    private val timerEngine: TimerEngine,
    private val progressEngine: ProgressEngine
) {
    private val engineScope = CoroutineScope(Dispatchers.IO)

    fun createSchedule(schedule: StudySchedule) {
        engineScope.launch {
            // Validate first
            if (schedule.subjectName.isBlank()) return@launch
            if (schedule.endTime <= schedule.startTime) return@launch
            if (schedule.isOfflineMode) {
                // validation for offline
            } else {
                if (schedule.selectedAppPackage.isNullOrBlank()) return@launch
            }

            // Make sure status is upcoming
            val newSchedule = schedule.copy(status = TaskStatus.UPCOMING.displayName)
            
            // Save to database
            studyDao.insertSchedule(newSchedule)
            
            // Engines naturally react to database changes, but we could explicitly trigger them if needed.
            // Notifications are handled by NotificationEngine observing the DB or we can call it.
        }
    }

    fun updateSchedule(schedule: StudySchedule) {
        engineScope.launch {
            if (schedule.subjectName.isBlank()) return@launch
            if (schedule.endTime <= schedule.startTime) return@launch
            
            studyDao.updateSchedule(schedule)
        }
    }

    fun deleteSchedule(id: Int) {
        engineScope.launch {
            studyDao.deleteSchedule(id)
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: ScheduleEngine? = null

        fun getInstance(
            studyDao: StudyDao,
            statusEngine: StatusEngine,
            notificationEngine: NotificationEngine,
            timerEngine: TimerEngine,
            progressEngine: ProgressEngine
        ): ScheduleEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: ScheduleEngine(
                    studyDao, statusEngine, notificationEngine, timerEngine, progressEngine
                ).also { INSTANCE = it }
            }
        }
    }
}
