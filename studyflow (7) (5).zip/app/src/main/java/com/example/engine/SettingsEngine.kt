package com.example.engine

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

val Context.settingsDataStore by preferencesDataStore(name = "studyflow_settings")

class SettingsEngine private constructor(private val context: Context) {
    private val engineScope = CoroutineScope(Dispatchers.IO)

    // Local Profile
    private val AVATAR_KEY = stringPreferencesKey("user_avatar")
    val userAvatar: Flow<String> = context.settingsDataStore.data.map { it[AVATAR_KEY] ?: "person" }
    
    private val CREATED_DATE_KEY = longPreferencesKey("created_date")
    val createdDate: Flow<Long> = context.settingsDataStore.data.map { it[CREATED_DATE_KEY] ?: 0L }
    
    private val LAST_ACTIVE_DATE_KEY = longPreferencesKey("last_active_date")
    val lastActiveDate: Flow<Long> = context.settingsDataStore.data.map { it[LAST_ACTIVE_DATE_KEY] ?: 0L }
    
    private val STUDY_GOAL_KEY = stringPreferencesKey("study_goal")
    val studyGoal: Flow<String> = context.settingsDataStore.data.map { it[STUDY_GOAL_KEY] ?: "Learn something new" }
    
    private val DAILY_STUDY_GOAL_KEY = longPreferencesKey("daily_study_goal_ms")
    val dailyStudyGoalMs: Flow<Long> = context.settingsDataStore.data.map { it[DAILY_STUDY_GOAL_KEY] ?: (2 * 3600 * 1000L) }
    
    private val WEEKLY_STUDY_GOAL_KEY = longPreferencesKey("weekly_study_goal_ms")
    val weeklyStudyGoalMs: Flow<Long> = context.settingsDataStore.data.map { it[WEEKLY_STUDY_GOAL_KEY] ?: (14 * 3600 * 1000L) }
    
    private val MONTHLY_STUDY_GOAL_KEY = longPreferencesKey("monthly_study_goal_ms")
    val monthlyStudyGoalMs: Flow<Long> = context.settingsDataStore.data.map { it[MONTHLY_STUDY_GOAL_KEY] ?: (60 * 3600 * 1000L) }

    fun updateUserAvatar(avatar: String) = engineScope.launch { context.settingsDataStore.edit { it[AVATAR_KEY] = avatar } }
    fun updateCreatedDate(date: Long) = engineScope.launch { context.settingsDataStore.edit { it[CREATED_DATE_KEY] = date } }
    fun updateLastActiveDate(date: Long) = engineScope.launch { context.settingsDataStore.edit { it[LAST_ACTIVE_DATE_KEY] = date } }
    fun updateStudyGoal(goal: String) = engineScope.launch { context.settingsDataStore.edit { it[STUDY_GOAL_KEY] = goal } }
    fun updateDailyStudyGoalMs(ms: Long) = engineScope.launch { context.settingsDataStore.edit { it[DAILY_STUDY_GOAL_KEY] = ms } }
    fun updateWeeklyStudyGoalMs(ms: Long) = engineScope.launch { context.settingsDataStore.edit { it[WEEKLY_STUDY_GOAL_KEY] = ms } }
    fun updateMonthlyStudyGoalMs(ms: Long) = engineScope.launch { context.settingsDataStore.edit { it[MONTHLY_STUDY_GOAL_KEY] = ms } }

    // Study Preferences
    private val DEFAULT_STUDY_MODE = booleanPreferencesKey("default_study_mode_offline")
    val defaultStudyModeOffline: Flow<Boolean> = context.settingsDataStore.data.map { it[DEFAULT_STUDY_MODE] ?: false }

    private val DEFAULT_REMINDER = intPreferencesKey("default_reminder_minutes")
    val defaultReminderMinutes: Flow<Int> = context.settingsDataStore.data.map { it[DEFAULT_REMINDER] ?: 10 }

    private val DEFAULT_PRIORITY = stringPreferencesKey("default_priority")
    val defaultPriority: Flow<String> = context.settingsDataStore.data.map { it[DEFAULT_PRIORITY] ?: "Medium" }

    private val DEFAULT_REPEAT = stringPreferencesKey("default_repeat")
    val defaultRepeat: Flow<String> = context.settingsDataStore.data.map { it[DEFAULT_REPEAT] ?: "ONE_TIME" }

    private val DEFAULT_STUDY_DURATION = intPreferencesKey("default_study_duration")
    val defaultStudyDuration: Flow<Int> = context.settingsDataStore.data.map { it[DEFAULT_STUDY_DURATION] ?: 60 }

    fun updateDefaultStudyModeOffline(offline: Boolean) = engineScope.launch { context.settingsDataStore.edit { it[DEFAULT_STUDY_MODE] = offline } }
    fun updateDefaultReminderMinutes(minutes: Int) = engineScope.launch { context.settingsDataStore.edit { it[DEFAULT_REMINDER] = minutes } }
    fun updateDefaultPriority(priority: String) = engineScope.launch { context.settingsDataStore.edit { it[DEFAULT_PRIORITY] = priority } }
    fun updateDefaultRepeat(repeat: String) = engineScope.launch { context.settingsDataStore.edit { it[DEFAULT_REPEAT] = repeat } }
    fun updateDefaultStudyDuration(duration: Int) = engineScope.launch { context.settingsDataStore.edit { it[DEFAULT_STUDY_DURATION] = duration } }

    // Notification Settings
    private val ENABLE_NOTIFICATIONS = booleanPreferencesKey("enable_notifications")
    val enableNotifications: Flow<Boolean> = context.settingsDataStore.data.map { it[ENABLE_NOTIFICATIONS] ?: true }

    private val REMINDER_SOUND = booleanPreferencesKey("reminder_sound")
    val reminderSound: Flow<Boolean> = context.settingsDataStore.data.map { it[REMINDER_SOUND] ?: true }

    private val VIBRATION = booleanPreferencesKey("vibration")
    val vibration: Flow<Boolean> = context.settingsDataStore.data.map { it[VIBRATION] ?: true }

    private val DAILY_SUMMARY = booleanPreferencesKey("daily_summary")
    val dailySummary: Flow<Boolean> = context.settingsDataStore.data.map { it[DAILY_SUMMARY] ?: true }

    private val SILENT_MODE = booleanPreferencesKey("silent_mode")
    val silentMode: Flow<Boolean> = context.settingsDataStore.data.map { it[SILENT_MODE] ?: false }

    fun updateEnableNotifications(enable: Boolean) = engineScope.launch { context.settingsDataStore.edit { it[ENABLE_NOTIFICATIONS] = enable } }
    fun updateReminderSound(enable: Boolean) = engineScope.launch { context.settingsDataStore.edit { it[REMINDER_SOUND] = enable } }
    fun updateVibration(enable: Boolean) = engineScope.launch { context.settingsDataStore.edit { it[VIBRATION] = enable } }
    fun updateDailySummary(enable: Boolean) = engineScope.launch { context.settingsDataStore.edit { it[DAILY_SUMMARY] = enable } }
    fun updateSilentMode(enable: Boolean) = engineScope.launch { context.settingsDataStore.edit { it[SILENT_MODE] = enable } }

    // Appearance
    private val DARK_MODE = booleanPreferencesKey("dark_mode")
    val darkMode: Flow<Boolean> = context.settingsDataStore.data.map { it[DARK_MODE] ?: true }

    private val ACCENT_COLOR = longPreferencesKey("accent_color")
    val accentColor: Flow<Long> = context.settingsDataStore.data.map { it[ACCENT_COLOR] ?: 0xFF00E5FF } // CyanAccent

    private val DYNAMIC_THEME = booleanPreferencesKey("dynamic_theme")
    val dynamicTheme: Flow<Boolean> = context.settingsDataStore.data.map { it[DYNAMIC_THEME] ?: false }

    private val ANIMATION_TOGGLE = booleanPreferencesKey("animation_toggle")
    val animationToggle: Flow<Boolean> = context.settingsDataStore.data.map { it[ANIMATION_TOGGLE] ?: true }

    fun updateDarkMode(enable: Boolean) = engineScope.launch { context.settingsDataStore.edit { it[DARK_MODE] = enable } }
    fun updateAccentColor(color: Long) = engineScope.launch { context.settingsDataStore.edit { it[ACCENT_COLOR] = color } }
    fun updateDynamicTheme(enable: Boolean) = engineScope.launch { context.settingsDataStore.edit { it[DYNAMIC_THEME] = enable } }
    fun updateAnimationToggle(enable: Boolean) = engineScope.launch { context.settingsDataStore.edit { it[ANIMATION_TOGGLE] = enable } }

    companion object {
        @Volatile
        private var INSTANCE: SettingsEngine? = null

        fun getInstance(context: Context): SettingsEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SettingsEngine(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
