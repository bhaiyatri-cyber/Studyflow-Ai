package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.ChatMessage
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkCharcoal
import com.example.ui.theme.DeepCharcoal

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssistantBottomSheet(
    viewModel: StudyViewModel,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = DeepCharcoal,
        modifier = Modifier.imePadding().fillMaxHeight(0.85f)
    ) {
        AssistantScreen(viewModel)
    }
}

@Composable
fun AssistantScreen(viewModel: StudyViewModel) {
    val chatHistory by viewModel.chatHistory.collectAsState()
    var inputText by remember { mutableStateOf("") }
    
    Column(
        modifier = Modifier.imePadding()
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "StudyFlow Assistant",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.imePadding().padding(bottom = 16.dp)
        )
        
        LazyColumn(
            modifier = Modifier.imePadding()
                .weight(1f)
                .fillMaxWidth(),
            reverseLayout = true
        ) {
            items(chatHistory.reversed(), key = { it.id }) { message ->
                ChatMessageItem(message)
            }
        }
        
        Spacer(modifier = Modifier.imePadding().height(12.dp))
        
        Row(
            modifier = Modifier.imePadding()
                .fillMaxWidth()
                .background(DarkCharcoal, RoundedCornerShape(24.dp))
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BasicTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.imePadding().weight(1f),
                textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp),
                decorationBox = { innerTextField ->
                    if (inputText.isEmpty()) {
                        Text("Ask about your study...", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    innerTextField()
                }
            )
            
            IconButton(
                onClick = {
                    if (inputText.isNotBlank()) {
                        viewModel.sendChatMessage(inputText)
                        inputText = ""
                    }
                },
                enabled = inputText.isNotBlank()
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send",
                    tint = if (inputText.isNotBlank()) CyanAccent else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(modifier = Modifier.imePadding().height(16.dp))
    }
}

@Composable
fun ChatMessageItem(message: ChatMessage) {
    val alignment = if (message.isUser) Alignment.CenterEnd else Alignment.CenterStart
    val bgColor = if (message.isUser) CyanAccent.copy(alpha = 0.2f) else DarkCharcoal
    val textColor = if (message.isUser) CyanAccent else MaterialTheme.colorScheme.onSurface
    
    Box(
        modifier = Modifier.imePadding()
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        contentAlignment = alignment
    ) {
        Box(
            modifier = Modifier.imePadding()
                .background(
                    color = bgColor,
                    shape = RoundedCornerShape(16.dp)
                )
                .padding(12.dp)
                .widthIn(max = 280.dp)
        ) {
            Text(
                text = message.text,
                color = textColor,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
