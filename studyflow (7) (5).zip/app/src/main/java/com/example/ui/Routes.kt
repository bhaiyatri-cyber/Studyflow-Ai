package com.example.ui

import kotlinx.serialization.Serializable

@Serializable
object HomeRoute

@Serializable
object ScheduleRoute

@Serializable
data class CreateScheduleRoute(val scheduleId: Int = -1) // -1 for new

@Serializable
object HistoryRoute

@Serializable
object ProgressRoute

@Serializable
object SettingsRoute

@Serializable
object PermissionsRoute

@Serializable
object AnalyticsRoute
