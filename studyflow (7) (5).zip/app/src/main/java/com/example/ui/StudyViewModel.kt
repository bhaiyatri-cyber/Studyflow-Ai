package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.StudySchedule
import com.example.data.StudySession
import com.example.engine.PermissionState
import com.example.engine.PermissionType
import com.example.engine.StudyFlowCoreEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.delay

enum class StartupState {
    LOADING,
    NEEDS_SETUP,
    READY
}

data class AppInfo(
    val packageName: String,
    val appName: String,
    val icon: android.graphics.drawable.Drawable? = null
)

class StudyViewModel(application: Application) : AndroidViewModel(application) {
    private val engine = StudyFlowCoreEngine.getInstance(application)

    private val _startupState = MutableStateFlow(StartupState.LOADING)
    val startupState = _startupState.asStateFlow()

    private val _loadingStatus = MutableStateFlow("Initializing StudyFlowCoreEngine...")
    val loadingStatus = _loadingStatus.asStateFlow()

    init {
        viewModelScope.launch {
            delay(500) // Animation intro
            
            _loadingStatus.value = "Loading Local Database..."
            delay(300)
            
            _loadingStatus.value = "Loading Profile..."
            val name = engine.userName.first()
            delay(200)
            
            _loadingStatus.value = "Loading Settings..."
            delay(200)
            
            _loadingStatus.value = "Loading Permissions..."
            engine.permissionEngine.refreshPermissions()
            delay(200)
            
            _loadingStatus.value = "Loading Schedule..."
            delay(200)
            
            _loadingStatus.value = "Loading Timer State..."
            delay(200)
            
            _loadingStatus.value = "Loading Progress..."
            delay(200)
            
            _loadingStatus.value = "Loading History..."
            delay(200)
            
            _loadingStatus.value = "Initialization Complete"
            delay(300)

            if (name.isBlank()) {
                _startupState.value = StartupState.NEEDS_SETUP
            } else {
                _startupState.value = StartupState.READY
            }
        }
    }

    
    // Settings Exports
    val userAvatar: StateFlow<String> = engine.settingsEngine.userAvatar.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "default_avatar")
    fun updateUserAvatar(avatar: String) = engine.settingsEngine.updateUserAvatar(avatar)

    val createdDate: StateFlow<Long> = engine.settingsEngine.createdDate.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
    fun updateCreatedDate(date: Long) = engine.settingsEngine.updateCreatedDate(date)

    val lastActiveDate: StateFlow<Long> = engine.settingsEngine.lastActiveDate.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
    fun updateLastActiveDate(date: Long) = engine.settingsEngine.updateLastActiveDate(date)

    val studyGoal: StateFlow<String> = engine.settingsEngine.studyGoal.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Learn something new")
    fun updateStudyGoal(goal: String) = engine.settingsEngine.updateStudyGoal(goal)

    val dailyStudyGoalMs: StateFlow<Long> = engine.settingsEngine.dailyStudyGoalMs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 2 * 3600 * 1000L)
    fun updateDailyStudyGoalMs(ms: Long) = engine.settingsEngine.updateDailyStudyGoalMs(ms)

    val weeklyStudyGoalMs: StateFlow<Long> = engine.settingsEngine.weeklyStudyGoalMs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 14 * 3600 * 1000L)
    fun updateWeeklyStudyGoalMs(ms: Long) = engine.settingsEngine.updateWeeklyStudyGoalMs(ms)

    val monthlyStudyGoalMs: StateFlow<Long> = engine.settingsEngine.monthlyStudyGoalMs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 60 * 3600 * 1000L)
    fun updateMonthlyStudyGoalMs(ms: Long) = engine.settingsEngine.updateMonthlyStudyGoalMs(ms)


    val defaultStudyModeOffline: StateFlow<Boolean> = engine.settingsEngine.defaultStudyModeOffline.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    fun updateDefaultStudyModeOffline(offline: Boolean) = engine.settingsEngine.updateDefaultStudyModeOffline(offline)

    val defaultReminderMinutes: StateFlow<Int> = engine.settingsEngine.defaultReminderMinutes.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 10)
    fun updateDefaultReminderMinutes(minutes: Int) = engine.settingsEngine.updateDefaultReminderMinutes(minutes)

    val defaultPriority: StateFlow<String> = engine.settingsEngine.defaultPriority.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Medium")
    fun updateDefaultPriority(priority: String) = engine.settingsEngine.updateDefaultPriority(priority)

    val defaultRepeat: StateFlow<String> = engine.settingsEngine.defaultRepeat.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "ONE_TIME")
    fun updateDefaultRepeat(repeat: String) = engine.settingsEngine.updateDefaultRepeat(repeat)

    val defaultStudyDuration: StateFlow<Int> = engine.settingsEngine.defaultStudyDuration.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 60)
    fun updateDefaultStudyDuration(duration: Int) = engine.settingsEngine.updateDefaultStudyDuration(duration)

    val enableNotifications: StateFlow<Boolean> = engine.settingsEngine.enableNotifications.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    fun updateEnableNotifications(enable: Boolean) = engine.settingsEngine.updateEnableNotifications(enable)

    val reminderSound: StateFlow<Boolean> = engine.settingsEngine.reminderSound.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    fun updateReminderSound(enable: Boolean) = engine.settingsEngine.updateReminderSound(enable)

    val vibration: StateFlow<Boolean> = engine.settingsEngine.vibration.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    fun updateVibration(enable: Boolean) = engine.settingsEngine.updateVibration(enable)

    val dailySummary: StateFlow<Boolean> = engine.settingsEngine.dailySummary.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    fun updateDailySummary(enable: Boolean) = engine.settingsEngine.updateDailySummary(enable)

    val silentMode: StateFlow<Boolean> = engine.settingsEngine.silentMode.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    fun updateSilentMode(enable: Boolean) = engine.settingsEngine.updateSilentMode(enable)

    val darkMode: StateFlow<Boolean> = engine.settingsEngine.darkMode.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    fun updateDarkMode(enable: Boolean) = engine.settingsEngine.updateDarkMode(enable)

    val accentColor: StateFlow<Long> = engine.settingsEngine.accentColor.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0xFF00E5FF)
    fun updateAccentColor(color: Long) = engine.settingsEngine.updateAccentColor(color)

    val dynamicTheme: StateFlow<Boolean> = engine.settingsEngine.dynamicTheme.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    fun updateDynamicTheme(enable: Boolean) = engine.settingsEngine.updateDynamicTheme(enable)

    val animationToggle: StateFlow<Boolean> = engine.settingsEngine.animationToggle.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    fun updateAnimationToggle(enable: Boolean) = engine.settingsEngine.updateAnimationToggle(enable)

    val dbSize: StateFlow<Long> = flow { emit(engine.context.getDatabasePath("studyflow_database").length()) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
    
    val backupFileDate: StateFlow<Long> = flow { 
        val file = java.io.File(engine.context.filesDir, "studyflow_backup.json")
        emit(if (file.exists()) file.lastModified() else 0L)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
    
    val backupFileSize: StateFlow<Long> = flow { 
        val file = java.io.File(engine.context.filesDir, "studyflow_backup.json")
        emit(if (file.exists()) file.length() else 0L)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val userName: StateFlow<String> = engine.userName.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), ""
    )

    val allSchedules: StateFlow<List<StudySchedule>> = engine.studyDao.getAllSchedules().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )
    val upcomingSchedules: StateFlow<List<StudySchedule>> = allSchedules.map { list ->
        list.filter { it.status == com.example.engine.TaskStatus.UPCOMING.displayName }
            .sortedBy { it.startTime }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())


    val allSessions: StateFlow<List<StudySession>> = engine.historyEngine.historySessions

    val totalStudyTime: StateFlow<Long?> = engine.studyDao.getTotalStudyTime().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), 0L
    )
    
    val notificationPermissionState: StateFlow<PermissionState> = engine.permissionEngine.notificationState
    val usageAccessPermissionState: StateFlow<PermissionState> = engine.permissionEngine.usageAccessState
    val batteryOptimizationPermissionState: StateFlow<PermissionState> = engine.permissionEngine.batteryOptimizationState
    val foregroundServicePermissionState: StateFlow<PermissionState> = engine.permissionEngine.foregroundServiceState
    val overlayPermissionState: StateFlow<PermissionState> = engine.permissionEngine.overlayState
    val accessibilityPermissionState: StateFlow<PermissionState> = engine.permissionEngine.accessibilityState

    val runningSchedule: StateFlow<StudySchedule?> = engine.runningSchedule
    val timerDurationMs: StateFlow<Long> = engine.timerDurationMs
    val timerState = engine.timerState
    val timerError = engine.timerError
    val progressStats = engine.progressStats
    val chatHistory = engine.assistantEngine.chatHistory
    val analyticsDashboard = engine.analyticsEngine.dashboard
    val currentTip = engine.assistantEngine.currentTip
    val currentDate: StateFlow<String> = kotlinx.coroutines.flow.flow {
        while (true) {
            val sdf = java.text.SimpleDateFormat("EEEE, MMMM d", java.util.Locale.getDefault())
            emit(sdf.format(java.util.Date()))
            kotlinx.coroutines.delay(60000)
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, "")

    
    private val _installedApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val installedApps = _installedApps.asStateFlow()

    fun loadInstalledApps() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val pm = getApplication<Application>().packageManager
            val mainIntent = android.content.Intent(android.content.Intent.ACTION_MAIN, null).apply {
                addCategory(android.content.Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
            val apps = resolveInfos.mapNotNull { resolveInfo ->
                try {
                    val packageName = resolveInfo.activityInfo.packageName
                    val appName = resolveInfo.loadLabel(pm).toString()
                    val icon = resolveInfo.loadIcon(pm)
                    AppInfo(packageName, appName, icon)
                } catch (e: Exception) {
                    null
                }
            }.distinctBy { it.packageName }.sortedBy { it.appName.lowercase() }
            _installedApps.value = apps
        }
    }
    
    fun sendChatMessage(text: String) {
        engine.assistantEngine.sendMessage(text)
    }
    
    fun setRunningSchedule(schedule: StudySchedule?) {
        engine.setRunningSchedule(schedule)
    }
    fun pauseTimer() {
        engine.timerEngine.pauseTimer()
    }
    fun resumeTimer() {
        engine.timerEngine.resumeTimer()
    }
    fun stopTimer() {
        setRunningSchedule(null)
    }

    
    fun markAsSkipped(scheduleId: Int) {
        engine.markAsSkipped(scheduleId)
    }
    
    private val _pendingPermissionRequest = MutableStateFlow<PermissionType?>(null)
    val pendingPermissionRequest: StateFlow<PermissionType?> = _pendingPermissionRequest.asStateFlow()

    fun requestPermission(type: PermissionType) {
        _pendingPermissionRequest.value = type
    }
    
    fun clearPermissionRequest() {
        _pendingPermissionRequest.value = null
    }

    fun getUsageAccessIntent() = engine.permissionEngine.getUsageAccessIntent()
    fun getBatteryOptimizationIntent() = engine.permissionEngine.getBatteryOptimizationIntent()
    fun getOverlayIntent() = engine.permissionEngine.getOverlayIntent()
    fun getAccessibilityIntent() = engine.permissionEngine.getAccessibilityIntent()

    fun refreshPermissions() {
        engine.permissionEngine.refreshPermissions()
    }

    fun markSetupComplete() {
        _startupState.value = StartupState.READY
    }

    fun updateUserName(name: String) {
        engine.updateUserName(name)
    }


    fun deleteSession(id: Int) {
        engine.historyEngine.deleteSession(id)
    }
    
    fun createBackup(uri: android.net.Uri, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = engine.backupEngine.createBackup(uri)
            if (result.isSuccess) {
                onResult(true, "Backup created successfully")
            } else {
                onResult(false, result.exceptionOrNull()?.message ?: "Unknown error")
            }
        }
    }
    
    fun createSchedule(schedule: StudySchedule) {
        engine.scheduleEngine.createSchedule(schedule)
    }

    fun updateSchedule(schedule: StudySchedule) {
        engine.scheduleEngine.updateSchedule(schedule)
    }

    fun deleteSchedule(id: Int) {
        engine.scheduleEngine.deleteSchedule(id)
    }
    
    fun restoreBackup(uri: android.net.Uri, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = engine.backupEngine.restoreBackup(uri)
            if (result.isSuccess) {
                val data = result.getOrNull()
                if (data != null) {
                    engine.backupEngine.commitRestore(data)
                    onResult(true, "Data restored successfully")
                } else {
                    onResult(false, "Invalid backup data")
                }
            } else {
                onResult(false, result.exceptionOrNull()?.message ?: "Invalid backup file")
            }
        }
    }
}
