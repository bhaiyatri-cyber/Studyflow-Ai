package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.engine.PermissionType
import com.example.ui.theme.CyanAccent

@Composable
fun PermissionPopup(
    permissionType: PermissionType,
    onDismiss: () -> Unit,
    onContinue: () -> Unit
) {
    val (title, description) = when (permissionType) {
        PermissionType.NOTIFICATIONS -> Pair(
            "Notifications Required",
            "StudyFlow needs this permission to send you study reminders.\n\nWithout this permission:\n• Timers will not alert you\n• Reminders won't work"
        )
        PermissionType.USAGE_ACCESS -> Pair(
            "Usage Access Required",
            "StudyFlow needs this permission to detect your selected study apps.\n\nWithout this permission:\n• Online Timer won't work\n• App Tracking won't work"
        )
        PermissionType.BATTERY_OPTIMIZATION -> Pair(
            "Battery Optimization Required",
            "StudyFlow needs to be exempted from battery optimizations to keep timers running in the background.\n\nWithout this permission:\n• Timers may stop unexpectedly"
        )
        PermissionType.OVERLAY -> Pair(
            "Overlay Required",
            "StudyFlow needs this permission to show floating focus popups.\n\nWithout this permission:\n• Floating features won't work"
        )
        PermissionType.ACCESSIBILITY -> Pair(
            "Accessibility Required",
            "StudyFlow needs this permission for advanced study protection.\n\nWithout this permission:\n• Distraction blocking won't work"
        )
        PermissionType.FOREGROUND_SERVICE -> Pair(
            "Foreground Service Required",
            "StudyFlow needs this permission to run background timers."
        )
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(24.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = onDismiss,
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    ) {
                        Text("Not Now")
                    }
                    Button(
                        onClick = onContinue,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyanAccent,
                            contentColor = Color.Black
                        ),
                        modifier = Modifier.padding(start = 8.dp)
                    ) {
                        Text("Continue")
                    }
                }
            }
        }
    }
}
