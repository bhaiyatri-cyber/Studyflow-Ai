package com.example.ui.schedule

import android.app.TimePickerDialog
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.StudySchedule
import com.example.ui.StudyViewModel
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkCharcoal
import com.example.ui.theme.DeepCharcoal
import java.util.Calendar
import android.app.DatePickerDialog
import android.widget.Toast

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateScheduleScreen(
    viewModel: StudyViewModel,
    scheduleId: Int,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val isEditing = scheduleId != -1

    val schedules by viewModel.allSchedules.collectAsState()
    val schedule = schedules.find { it.id == scheduleId }

    var subjectName by remember(schedule) { mutableStateOf(schedule?.subjectName ?: "") }
    var description by remember(schedule) { mutableStateOf(schedule?.description ?: "") }
    var isOfflineMode by remember(schedule) { mutableStateOf(schedule?.isOfflineMode ?: false) }
    var priority by remember(schedule) { mutableStateOf(schedule?.priority ?: "Medium") }
    var repeatType by remember(schedule) { mutableStateOf(schedule?.repeatType ?: "ONE_TIME") }
    var reminderMinutes by remember(schedule) { mutableStateOf(schedule?.reminderMinutes ?: 0) }
    
    // Time tracking
    var startCalendar by remember(schedule) { 
        mutableStateOf(
            if (schedule != null) Calendar.getInstance().apply { timeInMillis = schedule.startTime }
            else Calendar.getInstance()
        ) 
    }
    var endCalendar by remember(schedule) { 
        mutableStateOf(
            if (schedule != null) Calendar.getInstance().apply { timeInMillis = schedule.endTime }
            else Calendar.getInstance().apply { add(Calendar.HOUR, 1) }
        ) 
    }

    var selectedPackages by remember(schedule) {
        mutableStateOf(
            schedule?.selectedAppPackage?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() }?.toSet() ?: emptySet()
        )
    }
    
    var searchQuery by remember { mutableStateOf("") }
    val installedApps by viewModel.installedApps.collectAsState()
    
    LaunchedEffect(Unit) {
        viewModel.loadInstalledApps()
    }

    val usageAccessState by viewModel.usageAccessPermissionState.collectAsState()
    var pendingSave by remember { mutableStateOf(false) }

    LaunchedEffect(usageAccessState, pendingSave) {
        if (pendingSave && usageAccessState == com.example.engine.PermissionState.GRANTED) {
            val s = StudySchedule(
                id = if (isEditing) scheduleId else 0,
                subjectName = subjectName.trim(),
                description = description.trim(),
                startTime = startCalendar.timeInMillis,
                endTime = endCalendar.timeInMillis,
                repeatType = repeatType,
                isOfflineMode = isOfflineMode,
                selectedAppPackage = if (isOfflineMode) null else selectedPackages.joinToString(","),
                colorAccent = 0xFF00E5FF,
                reminderMinutes = reminderMinutes,
                priority = priority
            )
            if (isEditing) {
                viewModel.updateSchedule(s)
            } else {
                viewModel.createSchedule(s)
            }
            pendingSave = false
            onNavigateBack()
        }
    }

    // If editing, load data here (omitted for simplicity, but in a real app we'd load the schedule)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEditing) "Edit Schedule" else "Create Schedule") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepCharcoal,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                    navigationIconContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        },
        containerColor = DeepCharcoal
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(8.dp)) }

            item {
                OutlinedTextField(
                    value = subjectName,
                    onValueChange = { subjectName = it },
                    label = { Text("Subject Name (Required)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanAccent,
                        focusedLabelColor = CyanAccent
                    )
                )
            }

            item {
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description (Optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanAccent,
                        focusedLabelColor = CyanAccent
                    )
                )
            }

            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Study Mode:", color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = !isOfflineMode,
                            onClick = { isOfflineMode = false },
                            colors = RadioButtonDefaults.colors(selectedColor = CyanAccent)
                        )
                        Text("Online", color = MaterialTheme.colorScheme.onSurface)
                        Spacer(modifier = Modifier.width(16.dp))
                        RadioButton(
                            selected = isOfflineMode,
                            onClick = { isOfflineMode = true },
                            colors = RadioButtonDefaults.colors(selectedColor = CyanAccent)
                        )
                        Text("Offline", color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }

            if (!isOfflineMode) {
                item {
                    Text(
                        "Study Apps Selection (Selected: ${selectedPackages.size})",
                        style = MaterialTheme.typography.titleMedium,
                        color = CyanAccent,
                        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                    )
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Search installed apps") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = DarkCharcoal
                        ),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
                
                val filteredApps = installedApps.filter { 
                    it.appName.contains(searchQuery, ignoreCase = true) || it.packageName.contains(searchQuery, ignoreCase = true)
                }
                
                items(filteredApps.take(20)) { app ->
                    val isSelected = app.packageName in selectedPackages
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                if (isSelected) CyanAccent.copy(alpha = 0.1f) else Color.Transparent,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable {
                                selectedPackages = if (isSelected) {
                                    selectedPackages - app.packageName
                                } else {
                                    selectedPackages + app.packageName
                                }
                            }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        coil.compose.AsyncImage(
                            model = app.icon,
                            contentDescription = app.appName,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(app.appName, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
                            Text(app.packageName, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                        Checkbox(
                            checked = isSelected,
                            onCheckedChange = null,
                            colors = CheckboxDefaults.colors(checkedColor = CyanAccent)
                        )
                    }
                }
                
                item {
                    if (filteredApps.size > 20) {
                        Text("...and ${filteredApps.size - 20} more", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(8.dp))
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Start Time", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Button(
                            onClick = { showDateTimePicker(context, startCalendar) { startCalendar = it } },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkCharcoal),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(formatDateTime(startCalendar), color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("End Time", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Button(
                            onClick = { showDateTimePicker(context, endCalendar) { endCalendar = it } },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkCharcoal),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(formatDateTime(endCalendar), color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }

            item {
                Text("Repeat", color = MaterialTheme.colorScheme.onSurfaceVariant)
                androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("ONE_TIME" to "One Time", "DAILY" to "Daily", "WEEKLY" to "Weekly", "MONTHLY" to "Monthly", "CUSTOM" to "Custom")) { (type, label) ->
                        FilterChip(
                            selected = repeatType == type,
                            onClick = { repeatType = type },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyanAccent.copy(alpha = 0.2f),
                                selectedLabelColor = CyanAccent
                            )
                        )
                    }
                }
            }

            item {
                Text("Priority", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Low", "Medium", "High").forEach { p ->
                        FilterChip(
                            selected = priority == p,
                            onClick = { priority = p },
                            label = { Text(p) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyanAccent.copy(alpha = 0.2f),
                                selectedLabelColor = CyanAccent
                            )
                        )
                    }
                }
            }

            item {
                Text("Reminder", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "Off", 5 to "5m", 15 to "15m", 30 to "30m").forEach { (mins, label) ->
                        FilterChip(
                            selected = reminderMinutes == mins,
                            onClick = { reminderMinutes = mins },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyanAccent.copy(alpha = 0.2f),
                                selectedLabelColor = CyanAccent
                            )
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        if (subjectName.isBlank()) {
                            Toast.makeText(context, "Subject Name is required", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (endCalendar.timeInMillis <= startCalendar.timeInMillis) {
                            Toast.makeText(context, "End time must be after start time", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        if (!isOfflineMode && usageAccessState != com.example.engine.PermissionState.GRANTED) {
                            pendingSave = true
                            viewModel.requestPermission(com.example.engine.PermissionType.USAGE_ACCESS)
                            return@Button
                        }
                        
                        if (!isOfflineMode && selectedPackages.isEmpty()) {
                            Toast.makeText(context, "Please select at least one study app", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        val schedule = StudySchedule(
                            id = if (isEditing) scheduleId else 0,
                            subjectName = subjectName.trim(),
                            description = description.trim(),
                            startTime = startCalendar.timeInMillis,
                            endTime = endCalendar.timeInMillis,
                            repeatType = repeatType,
                            isOfflineMode = isOfflineMode,
                            selectedAppPackage = if (isOfflineMode) null else selectedPackages.joinToString(","),
                            colorAccent = 0xFF00E5FF, // CyanAccent value
                            reminderMinutes = reminderMinutes,
                            priority = priority
                        )

                        if (isEditing) {
                            viewModel.updateSchedule(schedule)
                        } else {
                            viewModel.createSchedule(schedule)
                        }
                        onNavigateBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = DeepCharcoal),
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(if (isEditing) "Save Changes" else "Create Schedule", fontWeight = FontWeight.Bold)
                }
                
                if (isEditing) {
                    var showDeleteConfirm by remember { mutableStateOf(false) }
                    
                    if (showDeleteConfirm) {
                        AlertDialog(
                            onDismissRequest = { showDeleteConfirm = false },
                            title = { Text("Delete Schedule?") },
                            text = { Text("Are you sure you want to delete this schedule? This action cannot be undone.") },
                            confirmButton = {
                                TextButton(
                                    onClick = {
                                        viewModel.deleteSchedule(scheduleId)
                                        showDeleteConfirm = false
                                        onNavigateBack()
                                    }
                                ) {
                                    Text("Delete", color = MaterialTheme.colorScheme.error)
                                }
                            },
                            dismissButton = {
                                TextButton(onClick = { showDeleteConfirm = false }) {
                                    Text("Cancel")
                                }
                            },
                            containerColor = DarkCharcoal,
                            titleContentColor = MaterialTheme.colorScheme.onSurface,
                            textContentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { showDeleteConfirm = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Delete Schedule")
                    }
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

private fun showDateTimePicker(context: Context, initial: Calendar, onDateSelected: (Calendar) -> Unit) {
    DatePickerDialog(
        context,
        { _, year, month, dayOfMonth ->
            val newCalendar = Calendar.getInstance()
            newCalendar.set(Calendar.YEAR, year)
            newCalendar.set(Calendar.MONTH, month)
            newCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)

            TimePickerDialog(
                context,
                { _, hourOfDay, minute ->
                    newCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
                    newCalendar.set(Calendar.MINUTE, minute)
                    onDateSelected(newCalendar)
                },
                initial.get(Calendar.HOUR_OF_DAY),
                initial.get(Calendar.MINUTE),
                true
            ).show()
        },
        initial.get(Calendar.YEAR),
        initial.get(Calendar.MONTH),
        initial.get(Calendar.DAY_OF_MONTH)
    ).show()
}

private fun formatDateTime(calendar: Calendar): String {
    val month = calendar.get(Calendar.MONTH) + 1
    val day = calendar.get(Calendar.DAY_OF_MONTH)
    val hour = calendar.get(Calendar.HOUR_OF_DAY)
    val minute = calendar.get(Calendar.MINUTE)
    return String.format("%02d/%02d %02d:%02d", month, day, hour, minute)
}
