package com.example.ui.settings

import android.app.Activity
import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.engine.PermissionState
import com.example.engine.PermissionType
import com.example.ui.StudyViewModel
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkCharcoal
import com.example.ui.theme.DeepCharcoal

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionManagementScreen(
    viewModel: StudyViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val notificationState by viewModel.notificationPermissionState.collectAsState()
    val usageAccessState by viewModel.usageAccessPermissionState.collectAsState()
    val batteryOptState by viewModel.batteryOptimizationPermissionState.collectAsState()
    val foregroundState by viewModel.foregroundServicePermissionState.collectAsState()
    val overlayState by viewModel.overlayPermissionState.collectAsState()
    val accessibilityState by viewModel.accessibilityPermissionState.collectAsState()

    var activePopup by remember { mutableStateOf<PermissionType?>(null) }

    val allStates = listOf(notificationState, usageAccessState, batteryOptState, foregroundState, overlayState, accessibilityState)
    val grantedCount = allStates.count { it == PermissionState.GRANTED }
    val totalCount = allStates.size
    val isGood = grantedCount == totalCount

    val intentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        viewModel.refreshPermissions()
    }
    
    val requestPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        viewModel.refreshPermissions()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Permissions", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepCharcoal,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                    navigationIconContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        },
        containerColor = DeepCharcoal
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isGood) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Permission Status Summary", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = if (isGood) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Permissions: $grantedCount / $totalCount Granted", color = if (isGood) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Overall Status: ${if (isGood) "Good" else "Needs Attention"}", color = if (isGood) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer, fontWeight = FontWeight.Bold)
                    }
                }
            }

            item {
                Text(
                    "System Permissions",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
            
            item {
                PermissionCard(
                    title = "Notification",
                    status = notificationState,
                    description = "Used for:\nStudy reminders\nRunning timer\nCompletion alerts",
                    onClick = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            activePopup = PermissionType.NOTIFICATIONS
                        }
                    }
                )
            }
            
            item {
                PermissionCard(
                    title = "Usage Access",
                    status = usageAccessState,
                    description = "Used for:\nOnline App Tracking\nDetecting running apps",
                    onClick = { activePopup = PermissionType.USAGE_ACCESS }
                )
            }
            
            item {
                PermissionCard(
                    title = "Foreground Service",
                    status = foregroundState,
                    description = "Used for:\nBackground timer\nKeeping app alive",
                    onClick = { activePopup = PermissionType.FOREGROUND_SERVICE }
                )
            }
            
            item {
                PermissionCard(
                    title = "Battery Optimization",
                    status = batteryOptState,
                    description = "Used for:\nPrevent timer from stopping\nAccurate tracking",
                    onClick = { activePopup = PermissionType.BATTERY_OPTIMIZATION }
                )
            }
            
            item {
                PermissionCard(
                    title = "Overlay Permission",
                    status = overlayState,
                    description = "Used for:\nFloating Focus Popup\nQuick actions",
                    onClick = { activePopup = PermissionType.OVERLAY }
                )
            }
            
            item {
                PermissionCard(
                    title = "Accessibility",
                    status = accessibilityState,
                    description = "Used for:\nAdvanced Study Protection\nBlocking distractions",
                    onClick = { activePopup = PermissionType.ACCESSIBILITY }
                )
            }
        }
    }
    
    if (activePopup != null) {
        val popupInfo = getPopupInfo(activePopup!!)
        AlertDialog(
            onDismissRequest = { activePopup = null },
            containerColor = DarkCharcoal,
            title = { Text(popupInfo.title, color = MaterialTheme.colorScheme.onSurface) },
            text = { Text(popupInfo.description, color = MaterialTheme.colorScheme.onSurfaceVariant) },
            confirmButton = {
                Button(
                    onClick = {
                        when (activePopup) {
                            PermissionType.NOTIFICATIONS -> {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    requestPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                                }
                            }
                            PermissionType.USAGE_ACCESS -> {
                                intentLauncher.launch(viewModel.getUsageAccessIntent())
                            }
                            PermissionType.BATTERY_OPTIMIZATION -> {
                                intentLauncher.launch(viewModel.getBatteryOptimizationIntent())
                            }
                            PermissionType.OVERLAY -> {
                                intentLauncher.launch(viewModel.getOverlayIntent())
                            }
                            PermissionType.ACCESSIBILITY -> {
                                intentLauncher.launch(viewModel.getAccessibilityIntent())
                            }
                            PermissionType.FOREGROUND_SERVICE -> {
                                // Handled automatically on Android 9+ on app install
                            }
                            else -> {}
                        }
                        activePopup = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = DeepCharcoal)
                ) {
                    Text(if (popupInfo.isGranted) "Manage" else "Grant Permission", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { activePopup = null }) {
                    Text("Not Now", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        )
    }
}

@Composable
fun PermissionCard(
    title: String,
    status: PermissionState,
    description: String,
    onClick: () -> Unit
) {
    val isGranted = status == PermissionState.GRANTED
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.Warning,
                    contentDescription = null,
                    tint = if (isGranted) CyanAccent else MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Text(
                text = "Status : ${if (isGranted) "Granted" else "Not Granted"}",
                style = MaterialTheme.typography.bodyMedium,
                color = if (isGranted) CyanAccent else MaterialTheme.colorScheme.error,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isGranted) MaterialTheme.colorScheme.surfaceVariant else CyanAccent,
                    contentColor = if (isGranted) MaterialTheme.colorScheme.onSurfaceVariant else DeepCharcoal
                ),
                modifier = Modifier.align(Alignment.End),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(if (isGranted) "Manage" else "Grant Permission", fontWeight = FontWeight.Bold)
            }
        }
    }
}

private data class PopupInfo(val title: String, val description: String, val isGranted: Boolean = false)

private fun getPopupInfo(type: PermissionType): PopupInfo {
    return when (type) {
        PermissionType.USAGE_ACCESS -> PopupInfo(
            title = "Usage Access Required",
            description = "StudyFlow needs this permission to detect your selected study apps.\n\nWithout this permission:\n• Online Timer won't work\n• App Tracking won't work"
        )
        PermissionType.NOTIFICATIONS -> PopupInfo(
            title = "Notifications Required",
            description = "StudyFlow needs this permission to send you study reminders.\n\nWithout this permission:\n• Timers will not alert you\n• Reminders won't work"
        )
        PermissionType.BATTERY_OPTIMIZATION -> PopupInfo(
            title = "Battery Optimization",
            description = "StudyFlow needs to be exempted from battery optimizations to keep timers running in the background.\n\nWithout this permission:\n• Timers may stop unexpectedly"
        )
        PermissionType.OVERLAY -> PopupInfo(
            title = "Overlay Required",
            description = "StudyFlow needs this permission to show floating focus popups.\n\nWithout this permission:\n• Floating features won't work"
        )
        PermissionType.ACCESSIBILITY -> PopupInfo(
            title = "Accessibility Required",
            description = "StudyFlow needs this permission for advanced study protection.\n\nWithout this permission:\n• Distraction blocking won't work"
        )
        PermissionType.FOREGROUND_SERVICE -> PopupInfo(
            title = "Foreground Service",
            description = "This permission is granted automatically on install for tracking timers in background.",
            isGranted = true
        )
    }
}
