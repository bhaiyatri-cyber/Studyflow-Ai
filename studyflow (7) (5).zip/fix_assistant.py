import re

with open('/app/applet/app/src/main/java/com/example/engine/AssistantEngine.kt', 'r') as f:
    content = f.read()

# I will just write it fresh
replacement = """package com.example.engine

import com.example.data.ChatMessageEntity
import com.example.data.StudyDao
import com.example.data.StudySchedule
import com.example.data.StudySession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

class AssistantEngine private constructor(
    private val studyDao: StudyDao,
    private val progressEngine: ProgressEngine,
    private val historyEngine: HistoryEngine,
    private val runningScheduleFlow: StateFlow<StudySchedule?>,
    private val timerStateFlow: StateFlow<TimerState>,
    private val userNameFlow: Flow<String>
) {
    private val engineScope = CoroutineScope(Dispatchers.Default)

    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatHistory: StateFlow<List<ChatMessage>> = _chatHistory.asStateFlow()
    
    init {
        engineScope.launch {
            studyDao.getAllChatMessages().collect { entities ->
                _chatHistory.value = entities.map { 
                    ChatMessage(id = it.id, text = it.text, isUser = it.isUser, timestamp = it.timestamp) 
                }
                
                if (entities.isEmpty()) {
                    val name = userNameFlow.first()
                    val greetingName = if (name == "Student" || name.isBlank()) "" else " $name"
                    sendAssistantMessage("Hello$greetingName 👋\\nMain abhi StudyFlow ke schedule, study time, progress aur tracking se jude questions ka answer de sakta hoon.")
                }
            }
        }
    }

    fun sendMessage(text: String) {
        val userMsg = ChatMessage(text = text, isUser = true)
        saveMessage(userMsg)
        processQuery(text.lowercase(Locale.getDefault()))
    }

    private fun processQuery(query: String) {
        engineScope.launch {
            val reply = when {
                query.contains("aaj kitna padha") || query.contains("today study") || query.contains("kitna time") || query.contains("progress") -> {
                    val sessions = historyEngine.historySessions.value
                    val zoneId = java.time.ZoneId.systemDefault()
                    val today = java.time.LocalDate.now(zoneId)
                    
                    val todayMs = sessions.filter { 
                        it.status == TaskStatus.COMPLETED.displayName && 
                        java.time.Instant.ofEpochMilli(it.date).atZone(zoneId).toLocalDate() == today
                    }.sumOf { it.actualDurationMs }
                    
                    if (todayMs > 0) {
                        "Aaj aapne ${formatDuration(todayMs)} actual study ki hai."
                    } else {
                        "Aaj abhi koi study time record nahi hua hai."
                    }
                }
                query.contains("next task") || query.contains("schedule kya hai") || query.contains("aaj ka schedule") -> {
                    val upcoming = studyDao.getAllSchedules().first().filter { 
                        it.startTime > System.currentTimeMillis() && it.status == TaskStatus.UPCOMING.displayName 
                    }.sortedBy { it.startTime }.firstOrNull()

                    if (upcoming != null) {
                        "Aapka next task ${upcoming.subjectName} hai, jo ${formatTimeDisplay(upcoming.startTime)} par start hoga."
                    } else {
                        "Aaj ke liye koi upcoming task schedule nahi hai."
                    }
                }
                query.contains("abhi kya chal raha") || query.contains("current task") || query.contains("running") -> {
                    val current = runningScheduleFlow.value
                    val state = timerStateFlow.value
                    if (current != null && state == TimerState.RUNNING) {
                        "Abhi ${current.subjectName} session running hai."
                    } else if (current != null && state == TimerState.PAUSED) {
                        "Abhi ${current.subjectName} session paused hai."
                    } else {
                        "Abhi koi session running nahi hai."
                    }
                }
                query.contains("streak") -> {
                    val streak = progressEngine.progressStats.value.streak
                    "Aapki current streak $streak days ki hai."
                }
                query.contains("kitne task complete") || query.contains("completed") -> {
                    val sessions = historyEngine.historySessions.value
                    val todayCompleted = sessions.count { it.status == TaskStatus.COMPLETED.displayName && isToday(it.date) }
                    "Aaj aapne $todayCompleted tasks complete kiye hain."
                }
                query.contains("missed task") || query.contains("missed") -> {
                    val sessions = historyEngine.historySessions.value
                    val todayMissed = sessions.count { it.status == TaskStatus.MISSED.displayName && isToday(it.date) }
                    "Aaj aapke $todayMissed tasks missed hain."
                }
                else -> {
                    "Main abhi StudyFlow ke schedule, study time, progress aur tracking se jude questions ka answer de sakta hoon."
                }
            }
            sendAssistantMessage(reply)
        }
    }

    private fun sendAssistantMessage(text: String) {
        val msg = ChatMessage(text = text, isUser = false)
        saveMessage(msg)
    }

    private fun saveMessage(msg: ChatMessage) {
        engineScope.launch {
            val entity = ChatMessageEntity(
                id = msg.id,
                text = msg.text,
                isUser = msg.isUser,
                timestamp = msg.timestamp
            )
            studyDao.insertChatMessage(entity)
        }
    }

    private fun formatDuration(timeMs: Long): String {
        val totalSeconds = timeMs / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        return if (hours > 0) {
            "$hours ghante $minutes minute"
        } else {
            "$minutes minute"
        }
    }

    private fun formatTimeDisplay(timestamp: Long): String {
        val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }
    
    private fun isToday(timestamp: Long): Boolean {
        val calendar = Calendar.getInstance()
        val todayYear = calendar.get(Calendar.YEAR)
        val todayDay = calendar.get(Calendar.DAY_OF_YEAR)
        
        calendar.timeInMillis = timestamp
        return calendar.get(Calendar.YEAR) == todayYear && calendar.get(Calendar.DAY_OF_YEAR) == todayDay
    }

    companion object {
        @Volatile
        private var INSTANCE: AssistantEngine? = null

        fun getInstance(
            studyDao: StudyDao,
            progressEngine: ProgressEngine,
            historyEngine: HistoryEngine,
            runningScheduleFlow: StateFlow<StudySchedule?>,
            timerStateFlow: StateFlow<TimerState>,
            userNameFlow: Flow<String>
        ): AssistantEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: AssistantEngine(
                    studyDao, progressEngine, historyEngine, runningScheduleFlow, timerStateFlow, userNameFlow
                ).also { INSTANCE = it }
            }
        }
    }
}
"""

with open('/app/applet/app/src/main/java/com/example/engine/AssistantEngine.kt', 'w') as f:
    f.write(replacement)

