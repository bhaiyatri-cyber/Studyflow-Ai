sed -i '80,83d' /app/applet/app/src/main/java/com/example/engine/AssistantEngine.kt
