sed -i '111,113c\
        }\
    }' /app/applet/app/src/main/java/com/example/ui/settings/SettingsScreen.kt
