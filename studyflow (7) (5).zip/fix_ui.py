import re

with open('/app/applet/app/src/main/java/com/example/ui/progress/ProgressScreen.kt', 'r') as f:
    content = f.read()

content = content.replace("package com.example.ui.progress", "package com.example.ui")

with open('/app/applet/app/src/main/java/com/example/ui/progress/ProgressScreen.kt', 'w') as f:
    f.write(content)

with open('/app/applet/app/src/main/java/com/example/ui/home/HomeScreen.kt', 'r') as f:
    home_content = f.read()

home_content = home_content.replace("import androidx.compose.material3.*", "import androidx.compose.material3.*\nimport androidx.compose.material3.Surface")

with open('/app/applet/app/src/main/java/com/example/ui/home/HomeScreen.kt', 'w') as f:
    f.write(home_content)

