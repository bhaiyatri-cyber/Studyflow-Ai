import re

with open('/app/applet/app/src/main/java/com/example/ui/StudyViewModel.kt', 'r') as f:
    content = f.read()

# remove upcomingSchedules
content = re.sub(r'    val upcomingSchedules: StateFlow<List<StudySchedule>> = allSchedules\.map \{ list ->\n        list\.filter \{ it\.status == com\.example\.engine\.TaskStatus\.UPCOMING\.displayName \}\n            \.sortedBy \{ it\.startTime \}\n    \}\.stateIn\(viewModelScope, SharingStarted\.Eagerly, emptyList\(\)\)\n', '', content)

# place it after allSchedules
target = '    val allSchedules: StateFlow<List<StudySchedule>> = engine.studyDao.getAllSchedules().stateIn(\n        viewModelScope, SharingStarted.Eagerly, emptyList()\n    )'

upcoming = """    val upcomingSchedules: StateFlow<List<StudySchedule>> = allSchedules.map { list ->
        list.filter { it.status == com.example.engine.TaskStatus.UPCOMING.displayName }
            .sortedBy { it.startTime }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
"""

content = content.replace(target, target + '\n' + upcoming)

with open('/app/applet/app/src/main/java/com/example/ui/StudyViewModel.kt', 'w') as f:
    f.write(content)
