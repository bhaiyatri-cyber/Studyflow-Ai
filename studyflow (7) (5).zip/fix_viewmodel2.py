import re

with open('/app/applet/app/src/main/java/com/example/ui/StudyViewModel.kt', 'r') as f:
    content = f.read()

target = '    val allSchedules: StateFlow<List<StudySchedule>> = engine.studyDao.getAllSchedules().stateIn(\n        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()\n    )'

upcoming = """
    val upcomingSchedules: StateFlow<List<StudySchedule>> = allSchedules.map { list ->
        list.filter { it.status == com.example.engine.TaskStatus.UPCOMING.displayName }
            .sortedBy { it.startTime }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
"""

content = content.replace(target, target + upcoming)

with open('/app/applet/app/src/main/java/com/example/ui/StudyViewModel.kt', 'w') as f:
    f.write(content)
