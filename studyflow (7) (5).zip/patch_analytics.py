import re

with open('/app/applet/app/src/main/java/com/example/engine/AnalyticsEngine.kt', 'r') as f:
    content = f.read()

replacement_dashboard = """data class AnalyticsDashboard(
    val dailyStudyMs: Long,
    val weeklyStudyMs: Long,
    val monthlyStudyMs: Long,
    val yearlyStudyMs: Long,
    
    val totalSessions: Int,
    val completedSessions: Int,
    val missedSessions: Int,
    val skippedSessions: Int,
    
    val averageStudyTimeMs: Long,
    val averageSessionLengthMs: Long,
    
    val bestStudyDay: String,
    val bestStudyHour: String,
    
    val mostStudiedSubject: String,
    val leastStudiedSubject: String,
    
    val focusScoreTrend: List<Float>,
    val streakHistory: List<Int>,
    
    val level: Int,
    val xp: Int,
    val achievementsCount: Int,
    
    val hasData: Boolean
)"""

content = re.sub(r'data class AnalyticsDashboard\([\s\S]*?val hasData: Boolean\n\)', replacement_dashboard, content)

empty_dashboard = """private fun createEmptyDashboard() = AnalyticsDashboard(0L, 0L, 0L, 0L, 0, 0, 0, 0, 0L, 0L, "None", "None", "None", "None", emptyList(), emptyList(), 1, 0, 0, false)"""
content = re.sub(r'private fun createEmptyDashboard\(\) = [^\n]*', empty_dashboard, content)

calculate = """        val prog = progressEngine.progressStats.value
        _dashboard.value = AnalyticsDashboard(
            dailyStudyMs = dailyStudy,
            weeklyStudyMs = weeklyStudy,
            monthlyStudyMs = monthlyStudy,
            yearlyStudyMs = yearlyStudy,
            totalSessions = sessions.size,
            completedSessions = completed,
            missedSessions = missed,
            skippedSessions = skipped,
            averageStudyTimeMs = avgStudyTime,
            averageSessionLengthMs = avgSessionLen,
            bestStudyDay = bestDay,
            bestStudyHour = bestHour,
            mostStudiedSubject = mostStudied,
            leastStudiedSubject = leastStudied,
            focusScoreTrend = trend,
            streakHistory = listOf(prog.streak), // read from progress engine
            level = prog.level,
            xp = prog.xp,
            achievementsCount = prog.achievements.count { it.isUnlocked },
            hasData = true
        )"""

content = re.sub(r'        _dashboard\.value = AnalyticsDashboard\([\s\S]*?hasData = true\n        \)', calculate, content)

with open('/app/applet/app/src/main/java/com/example/engine/AnalyticsEngine.kt', 'w') as f:
    f.write(content)

