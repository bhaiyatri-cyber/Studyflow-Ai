import re

with open('/app/applet/app/src/main/java/com/example/ui/analytics/AnalyticsScreen.kt', 'r') as f:
    content = f.read()

stats_section = """                item {
                    SectionTitle("Overview")
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatRow("Total Sessions", dashboard.totalSessions.toString())
                            StatRow("Completed", dashboard.completedSessions.toString())
                            StatRow("Missed", dashboard.missedSessions.toString())
                            StatRow("Average Study Time", formatDuration(dashboard.averageStudyTimeMs))
                            StatRow("Best Study Day", dashboard.bestStudyDay)
                            StatRow("Best Study Hour", dashboard.bestStudyHour)
                            StatRow("Most Studied", dashboard.mostStudiedSubject)
                            StatRow("Current Level", "${dashboard.level} (${dashboard.xp} XP)")
                            StatRow("Streak", "${dashboard.streakHistory.firstOrNull() ?: 0} Days")
                        }
                    }
                }
"""

content = content.replace('                // Insights', stats_section + '                // Insights')

stat_row_func = """@Composable
fun StatRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
    }
}
"""

content = content + "\n" + stat_row_func

with open('/app/applet/app/src/main/java/com/example/ui/analytics/AnalyticsScreen.kt', 'w') as f:
    f.write(content)

