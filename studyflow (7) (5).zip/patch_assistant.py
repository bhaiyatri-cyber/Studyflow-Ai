import re

# Update AssistantEngine.kt
with open('/app/applet/app/src/main/java/com/example/engine/AssistantEngine.kt', 'r') as f:
    ae_content = f.read()

ae_content = ae_content.replace(
    "private val timerStateFlow: StateFlow<TimerState>,\n    private val userNameFlow: Flow<String>",
    "private val timerStateFlow: StateFlow<TimerState>,\n    private val userNameFlow: Flow<String>,\n    private val studyGoalFlow: Flow<String>"
)

ae_content = ae_content.replace(
    "timerStateFlow, userNameFlow",
    "timerStateFlow, userNameFlow, studyGoalFlow"
)

ae_content = ae_content.replace(
    "fun getInstance(\n            studyDao: StudyDao,\n            progressEngine: ProgressEngine,\n            historyEngine: HistoryEngine,\n            runningScheduleFlow: StateFlow<StudySchedule?>,\n            timerStateFlow: StateFlow<TimerState>,\n            userNameFlow: Flow<String>\n        ): AssistantEngine",
    "fun getInstance(\n            studyDao: StudyDao,\n            progressEngine: ProgressEngine,\n            historyEngine: HistoryEngine,\n            runningScheduleFlow: StateFlow<StudySchedule?>,\n            timerStateFlow: StateFlow<TimerState>,\n            userNameFlow: Flow<String>,\n            studyGoalFlow: Flow<String>\n        ): AssistantEngine"
)

new_query_logic = """
                query.contains("goal") || query.contains("mera goal") || query.contains("lakshya") -> {
                    val goal = studyGoalFlow.first()
                    "Aapka current study goal '$goal' hai. Ise achieve karne ke liye lagatar mehnat karte rahein!"
                }
                query.contains("aaj kitna padha")
"""

ae_content = ae_content.replace(
    'query.contains("aaj kitna padha")',
    new_query_logic.strip()
)

with open('/app/applet/app/src/main/java/com/example/engine/AssistantEngine.kt', 'w') as f:
    f.write(ae_content)

# Update StudyFlowCoreEngine.kt
with open('/app/applet/app/src/main/java/com/example/engine/StudyFlowCoreEngine.kt', 'r') as f:
    se_content = f.read()

se_content = se_content.replace(
    "val assistantEngine: AssistantEngine = AssistantEngine.getInstance(\n        studyDao, progressEngine, historyEngine, runningSchedule, timerState, userName\n    )",
    "val assistantEngine: AssistantEngine = AssistantEngine.getInstance(\n        studyDao, progressEngine, historyEngine, runningSchedule, timerState, userName, settingsEngine.studyGoal\n    )"
)

with open('/app/applet/app/src/main/java/com/example/engine/StudyFlowCoreEngine.kt', 'w') as f:
    f.write(se_content)

