import re

with open('/app/applet/app/src/main/java/com/example/engine/BackupEngine.kt', 'r') as f:
    content = f.read()

old_create = """            val userName = coreEngine.userName.first()
            val schedules = studyDao.getAllSchedules().first()
            val sessions = studyDao.getAllSessions().first()
            val chatMessages = studyDao.getAllChatMessages().first()

            val backupData = BackupData(
                userName = userName,
                schedules = schedules,
                sessions = sessions,
                chatMessages = chatMessages
            )"""

new_create = """            val userName = coreEngine.userName.first()
            val userAvatar = coreEngine.settingsEngine.userAvatar.first()
            val studyGoal = coreEngine.settingsEngine.studyGoal.first()
            val dailyGoalMs = coreEngine.settingsEngine.dailyStudyGoalMs.first()
            val createdDate = coreEngine.settingsEngine.createdDate.first()
            
            val schedules = studyDao.getAllSchedules().first()
            val sessions = studyDao.getAllSessions().first()
            val chatMessages = studyDao.getAllChatMessages().first()

            val backupData = BackupData(
                version = 2,
                userName = userName,
                userAvatar = userAvatar,
                studyGoal = studyGoal,
                dailyStudyGoalMs = dailyGoalMs,
                createdDate = createdDate,
                schedules = schedules,
                sessions = sessions,
                chatMessages = chatMessages
            )"""

old_restore = """            // Restore username
            coreEngine.updateUserName(backupData.userName)

            // Clear existing and restore new data"""

new_restore = """            // Restore username
            coreEngine.updateUserName(backupData.userName)
            
            // Restore profile
            coreEngine.settingsEngine.updateUserAvatar(backupData.userAvatar)
            coreEngine.settingsEngine.updateStudyGoal(backupData.studyGoal)
            coreEngine.settingsEngine.updateDailyStudyGoalMs(backupData.dailyStudyGoalMs)
            coreEngine.settingsEngine.updateCreatedDate(backupData.createdDate)

            // Clear existing and restore new data"""

content = content.replace(old_create, new_create)
content = content.replace(old_restore, new_restore)

with open('/app/applet/app/src/main/java/com/example/engine/BackupEngine.kt', 'w') as f:
    f.write(content)
