import re

with open('/app/applet/app/src/main/java/com/example/engine/BackupEngine.kt', 'r') as f:
    content = f.read()

content = content.replace("Json.encodeToString", "Json { ignoreUnknownKeys = true }.encodeToString")
content = content.replace("Json.decodeFromString", "Json { ignoreUnknownKeys = true }.decodeFromString")

with open('/app/applet/app/src/main/java/com/example/engine/BackupEngine.kt', 'w') as f:
    f.write(content)

