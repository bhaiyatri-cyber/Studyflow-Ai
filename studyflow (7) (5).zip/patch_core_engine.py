import re

with open('/app/applet/app/src/main/java/com/example/engine/StudyFlowCoreEngine.kt', 'r') as f:
    content = f.read()

content = content.replace('val permissionEngine: PermissionEngine = PermissionEngine.getInstance(context)', 'val permissionEngine: PermissionEngine = PermissionEngine.getInstance(context)\n    val settingsEngine: SettingsEngine = SettingsEngine.getInstance(context)')

with open('/app/applet/app/src/main/java/com/example/engine/StudyFlowCoreEngine.kt', 'w') as f:
    f.write(content)
