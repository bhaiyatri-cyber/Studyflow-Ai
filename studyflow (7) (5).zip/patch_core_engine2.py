import re

with open('/app/applet/app/src/main/java/com/example/engine/StudyFlowCoreEngine.kt', 'r') as f:
    content = f.read()

content = content.replace("    val timerEngine: TimerEngine = TimerEngine.getInstance(context, permissionEngine)", "    val offlineTrackingEngine: OfflineTrackingEngine = OfflineTrackingEngine.getInstance(context)\n    val timerEngine: TimerEngine = TimerEngine.getInstance(context, permissionEngine, offlineTrackingEngine)")

with open('/app/applet/app/src/main/java/com/example/engine/StudyFlowCoreEngine.kt', 'w') as f:
    f.write(content)

