import re

with open('/app/applet/app/src/main/java/com/example/ui/settings/SettingsScreen.kt', 'r') as f:
    content = f.read()

target = """@Composable
fun DataStorageSection(viewModel: StudyViewModel) {"""

replacement = """@Composable
fun DataStorageSection(viewModel: StudyViewModel) {
    val context = LocalContext.current
    var showClearCacheConfirm by remember { mutableStateOf(false) }"""

content = content.replace(target, replacement)

target2 = """            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = { /* TODO Clear Cache */ }) {
                    Text("Clear Cache", color = MaterialTheme.colorScheme.error)
                }
                TextButton(onClick = { /* TODO Export Data */ }) {
                    Text("Export Data", color = CyanAccent)
                }
            }"""

replacement2 = """            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = { showClearCacheConfirm = true }) {
                    Text("Clear Cache", color = MaterialTheme.colorScheme.error)
                }
                TextButton(onClick = { Toast.makeText(context, "Export Data functionality coming soon", Toast.LENGTH_SHORT).show() }) {
                    Text("Export Data", color = CyanAccent)
                }
            }
        }
    }
    
    if (showClearCacheConfirm) {
        AlertDialog(
            onDismissRequest = { showClearCacheConfirm = false },
            containerColor = DarkCharcoal,
            title = { Text("Clear Cache?", color = MaterialTheme.colorScheme.onSurface) },
            text = { Text("This will delete temporary app data but keep your schedules and history safe.", color = MaterialTheme.colorScheme.onSurfaceVariant) },
            confirmButton = {
                Button(
                    onClick = {
                        context.cacheDir.deleteRecursively()
                        Toast.makeText(context, "Cache Cleared", Toast.LENGTH_SHORT).show()
                        showClearCacheConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error, contentColor = MaterialTheme.colorScheme.onError)
                ) {
                    Text("Clear", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearCacheConfirm = false }) {
                    Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        )"""

content = re.sub(r'            Row\(modifier = Modifier.fillMaxWidth\(\), horizontalArrangement = Arrangement.SpaceBetween\) \{\n                TextButton\(onClick = \{ /\* TODO Clear Cache \*/ \}\) \{\n                    Text\("Clear Cache", color = MaterialTheme.colorScheme.error\)\n                \}\n                TextButton\(onClick = \{ /\* TODO Export Data \*/ \}\) \{\n                    Text\("Export Data", color = CyanAccent\)\n                \}\n            \}\n        \}\n    \}', replacement2, content)

with open('/app/applet/app/src/main/java/com/example/ui/settings/SettingsScreen.kt', 'w') as f:
    f.write(content)

