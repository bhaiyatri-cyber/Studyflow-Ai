import re

with open('/app/applet/app/src/main/java/com/example/ui/settings/SettingsScreen.kt', 'r') as f:
    content = f.read()

target = """            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { /* TODO Export Data */ }) {
                    Text("Export Data", color = CyanAccent)
                }
            }"""

replacement = """            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = { /* TODO Clear Cache */ }) {
                    Text("Clear Cache", color = MaterialTheme.colorScheme.error)
                }
                TextButton(onClick = { /* TODO Export Data */ }) {
                    Text("Export Data", color = CyanAccent)
                }
            }"""

content = content.replace(target, replacement)

with open('/app/applet/app/src/main/java/com/example/ui/settings/SettingsScreen.kt', 'w') as f:
    f.write(content)
