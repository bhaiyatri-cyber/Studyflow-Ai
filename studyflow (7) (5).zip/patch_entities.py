import re

with open('/app/applet/app/src/main/java/com/example/data/Entities.kt', 'r') as f:
    content = f.read()

old_backup = """@Serializable
data class BackupData(
    val version: Int = 1,
    val userName: String,
    val schedules: List<StudySchedule>,
    val sessions: List<StudySession>,
    val chatMessages: List<ChatMessageEntity>
)"""

new_backup = """@Serializable
data class BackupData(
    val version: Int = 2,
    val userName: String,
    val userAvatar: String = "person",
    val studyGoal: String = "Learn something new",
    val dailyStudyGoalMs: Long = 7200000L,
    val createdDate: Long = 0L,
    val schedules: List<StudySchedule> = emptyList(),
    val sessions: List<StudySession> = emptyList(),
    val chatMessages: List<ChatMessageEntity> = emptyList()
)"""

content = content.replace(old_backup, new_backup)

with open('/app/applet/app/src/main/java/com/example/data/Entities.kt', 'w') as f:
    f.write(content)
