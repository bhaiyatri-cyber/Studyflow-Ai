import re

with open('/app/applet/app/src/main/java/com/example/engine/AnalyticsEngine.kt', 'r') as f:
    content = f.read()

# Add to AnalyticsDashboard
old_dash = '    val hasData: Boolean\n)'
new_dash = '    val hasData: Boolean,\n    val dailyGoalMs: Long = 7200000L,\n    val dailyGoalProgress: Float = 0f\n)'
content = content.replace(old_dash, new_dash)

# Calculate dailyGoalProgress
old_calc = 'hasData = true\n        )'
new_calc = 'hasData = true,\n            dailyGoalMs = 7200000L,\n            dailyGoalProgress = (dailyStudy.toFloat() / 7200000f).coerceIn(0f, 1f)\n        )'
content = content.replace(old_calc, new_calc)

with open('/app/applet/app/src/main/java/com/example/engine/AnalyticsEngine.kt', 'w') as f:
    f.write(content)

