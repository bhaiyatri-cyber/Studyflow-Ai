import re

with open('/app/applet/app/src/main/java/com/example/engine/HistoryEngine.kt', 'r') as f:
    content = f.read()

replacement = """    fun recordSession(schedule: StudySchedule, finalStatus: TaskStatus, actualDurationMs: Long) {
        engineScope.launch {
            val sessions = studyDao.getAllSessions().first()
            val now = System.currentTimeMillis()
            val msInDay = 24L * 60 * 60 * 1000
            
            // Check if we already have a session for this scheduleId within the last 12 hours
            // to avoid duplicate recording for the current occurrence
            val existing = sessions.find { 
                it.scheduleId == schedule.id && (now - it.date) < (12L * 60 * 60 * 1000)
            }
            if (existing != null) {
                return@launch
            }

            val session = StudySession(
                scheduleId = schedule.id,
                subjectName = schedule.subjectName,
                date = now,
                scheduledDurationMs = schedule.endTime - schedule.startTime,
                actualDurationMs = actualDurationMs,
                status = finalStatus.displayName,
                isOfflineMode = schedule.isOfflineMode,
                selectedAppPackage = schedule.selectedAppPackage,
                notes = schedule.notes,
                timelineEvents = "Schedule created -> ${finalStatus.displayName}"
            )
            studyDao.insertSession(session)
        }
    }"""

content = re.sub(r'    fun recordSession.*?    \}', replacement, content, flags=re.DOTALL)

with open('/app/applet/app/src/main/java/com/example/engine/HistoryEngine.kt', 'w') as f:
    f.write(content)

