import re

with open('/app/applet/app/src/main/java/com/example/ui/home/HomeScreen.kt', 'r') as f:
    content = f.read()

# I will replace the Row containing ProgressOverviewCard with Goal & Progress cards.
target_row = """                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ProgressOverviewCard("Today", formatTime(dashboard.dailyStudyMs), Modifier.weight(1f))
                        ProgressOverviewCard("Weekly", formatTime(dashboard.weeklyStudyMs), Modifier.weight(1f))
                    }
                }"""

new_row = """                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val dailyGoalMs = 2 * 3600 * 1000L
                        val dailyProgress = (dashboard.dailyStudyMs.toFloat() / dailyGoalMs.toFloat()).coerceIn(0f, 1f)
                        GoalCard(
                            title = "Daily Goal",
                            progress = dailyProgress,
                            value = "${(dailyProgress * 100).toInt()}%",
                            modifier = Modifier.weight(1f)
                        )
                        ProgressOverviewCard("Today's Time", formatTime(dashboard.dailyStudyMs), Modifier.weight(1f))
                    }
                }
                item {
                    ProgressOverviewCard("Weekly Progress", formatTime(dashboard.weeklyStudyMs), Modifier.fillMaxWidth())
                }"""

content = content.replace(target_row, new_row)

goal_card_composable = """@Composable
fun GoalCard(title: String, progress: Float, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                color = CyanAccent,
                trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
"""

content = content + "\n" + goal_card_composable

with open('/app/applet/app/src/main/java/com/example/ui/home/HomeScreen.kt', 'w') as f:
    f.write(content)

