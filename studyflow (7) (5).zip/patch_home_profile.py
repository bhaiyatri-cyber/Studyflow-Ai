import re

with open('/app/applet/app/src/main/java/com/example/ui/home/HomeScreen.kt', 'r') as f:
    content = f.read()

new_imports = """import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.School"""

if "import androidx.compose.ui.graphics.vector.ImageVector" not in content:
    content = content.replace("import androidx.compose.ui.unit.dp", "import androidx.compose.ui.unit.dp\n" + new_imports)

old_greeting = """            // Greeting & Date
            item {
                Column {
                    Text(
                        text = "Hello, ${if (userName.isBlank()) "Student" else userName} 👋",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = currentDate,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }"""

new_greeting = """            item {
                val avatarName by viewModel.userAvatar.collectAsState()
                val dailyGoal by viewModel.dailyStudyGoalMs.collectAsState()
                val studyGoal by viewModel.studyGoal.collectAsState()
                
                ProfileCard(
                    name = if (userName.isBlank()) "Student" else userName,
                    avatarName = avatarName,
                    level = progressStats.level,
                    currentXp = progressStats.currentLevelXp,
                    xpToNextLevel = progressStats.xpToNextLevel,
                    streak = progressStats.streak,
                    dailyGoalMs = dailyGoal,
                    dailyStudyMs = dashboard.dailyStudyMs,
                    completionPercent = dashboard.dailyGoalProgress,
                    studyGoal = studyGoal
                )
            }"""

content = content.replace(old_greeting, new_greeting)

profile_card = """
@Composable
fun ProfileCard(
    name: String,
    avatarName: String,
    level: Int,
    currentXp: Int,
    xpToNextLevel: Int,
    streak: Int,
    dailyGoalMs: Long,
    dailyStudyMs: Long,
    completionPercent: Float,
    studyGoal: String
) {
    val rankName = when {
        level < 5 -> "Novice Scholar"
        level < 15 -> "Dedicated Student"
        level < 30 -> "Academic Achiever"
        level < 50 -> "Master Learner"
        else -> "Grandmaster of Study"
    }

    val icon: ImageVector = when (avatarName) {
        "face" -> Icons.Default.Face
        "emoji" -> Icons.Default.EmojiEmotions
        "pets" -> Icons.Default.Pets
        "school" -> Icons.Default.School
        else -> Icons.Default.Person
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(24.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(CyanAccent.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = "Avatar",
                        tint = CyanAccent,
                        modifier = Modifier.size(40.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Hello, $name 👋",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = rankName,
                        style = MaterialTheme.typography.bodyMedium,
                        color = CyanAccent
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Lvl $level",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "$streak Day Streak 🔥",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // XP Bar
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Level Progress", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("$currentXp / $xpToNextLevel XP", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(modifier = Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { if (xpToNextLevel > 0) currentXp.toFloat() / xpToNextLevel else 0f },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                color = CyanAccent,
                trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Goals
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Today's Goal", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val goalHrs = dailyGoalMs / 3600000f
                    val stdHrs = dailyStudyMs / 3600000f
                    Text(
                        text = String.format(Locale.getDefault(), "%.1f / %.1f hrs", stdHrs, goalHrs),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text("Completion", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = "${(completionPercent * 100).toInt()}%",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = CyanAccent
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.background.copy(alpha = 0.5f))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Goal: $studyGoal",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}"""

content = content + "\n" + profile_card

with open('/app/applet/app/src/main/java/com/example/ui/home/HomeScreen.kt', 'w') as f:
    f.write(content)

