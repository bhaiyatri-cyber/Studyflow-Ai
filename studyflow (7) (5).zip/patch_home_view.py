import re

with open('/app/applet/app/src/main/java/com/example/ui/home/HomeScreen.kt', 'r') as f:
    content = f.read()

target = """                        val dailyGoalMs = 2 * 3600 * 1000L
                        val dailyProgress = (dashboard.dailyStudyMs.toFloat() / dailyGoalMs.toFloat()).coerceIn(0f, 1f)
                        GoalCard(
                            title = "Daily Goal",
                            progress = dailyProgress,
                            value = "${(dailyProgress * 100).toInt()}%",
                            modifier = Modifier.weight(1f)
                        )"""

new_target = """                        GoalCard(
                            title = "Daily Goal",
                            progress = dashboard.dailyGoalProgress,
                            value = "${(dashboard.dailyGoalProgress * 100).toInt()}%",
                            modifier = Modifier.weight(1f)
                        )"""

content = content.replace(target, new_target)

with open('/app/applet/app/src/main/java/com/example/ui/home/HomeScreen.kt', 'w') as f:
    f.write(content)

