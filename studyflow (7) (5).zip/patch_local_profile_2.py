import re

with open('/app/applet/app/src/main/java/com/example/ui/settings/SettingsScreen.kt', 'r') as f:
    content = f.read()

new_imports = """import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.School
import androidx.compose.ui.graphics.vector.ImageVector"""

if "import androidx.compose.material.icons.filled.Face" not in content:
    content = content.replace("import androidx.compose.material.icons.filled.*", "import androidx.compose.material.icons.filled.*\n" + new_imports)

# We use regex to replace LocalProfileSection to avoid minor whitespace differences
pattern = r'@Composable\nfun LocalProfileSection\(viewModel: StudyViewModel\) \{[\s\S]*?(?=@Composable\nfun PermissionsSection)'

new_profile_section = """@Composable
fun LocalProfileSection(viewModel: StudyViewModel) {
    val userName by viewModel.userName.collectAsState()
    val userAvatar by viewModel.userAvatar.collectAsState()
    val studyGoal by viewModel.studyGoal.collectAsState()
    val dailyGoalMs by viewModel.dailyStudyGoalMs.collectAsState()
    
    var editMode by remember { mutableStateOf(false) }
    var tempName by remember(userName) { mutableStateOf(userName) }
    var tempAvatar by remember(userAvatar) { mutableStateOf(userAvatar) }
    var tempGoal by remember(studyGoal) { mutableStateOf(studyGoal) }
    var tempDailyGoalHours by remember(dailyGoalMs) { mutableFloatStateOf(dailyGoalMs / 3600000f) }

    val icon: ImageVector = when (if(editMode) tempAvatar else userAvatar) {
        "face" -> Icons.Default.Face
        "emoji" -> Icons.Default.EmojiEmotions
        "pets" -> Icons.Default.Pets
        "school" -> Icons.Default.School
        else -> Icons.Default.Person
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Local Profile", style = MaterialTheme.typography.titleMedium, color = CyanAccent, fontWeight = FontWeight.Bold)
                IconButton(onClick = {
                    if (editMode) {
                        viewModel.updateUserName(tempName)
                        viewModel.updateUserAvatar(tempAvatar)
                        viewModel.updateStudyGoal(tempGoal)
                        viewModel.updateDailyStudyGoalMs((tempDailyGoalHours * 3600 * 1000L).toLong())
                    }
                    editMode = !editMode
                }) {
                    Icon(if (editMode) Icons.Filled.Check else Icons.Filled.Edit, contentDescription = "Edit Profile", tint = CyanAccent)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            
            if (editMode) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    val avatars = listOf("person" to Icons.Default.Person, "face" to Icons.Default.Face, "emoji" to Icons.Default.EmojiEmotions, "pets" to Icons.Default.Pets, "school" to Icons.Default.School)
                    avatars.forEach { (id, ic) ->
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(if (tempAvatar == id) CyanAccent else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { tempAvatar = id },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(ic, contentDescription = null, tint = if (tempAvatar == id) DeepCharcoal else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = tempName,
                    onValueChange = { tempName = it },
                    label = { Text("Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = tempGoal,
                    onValueChange = { tempGoal = it },
                    label = { Text("Study Goal") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text("Daily Goal: ${String.format(java.util.Locale.getDefault(), "%.1f", tempDailyGoalHours)} hours", color = MaterialTheme.colorScheme.onSurface)
                Slider(
                    value = tempDailyGoalHours,
                    onValueChange = { tempDailyGoalHours = it },
                    valueRange = 0.5f..12f,
                    steps = 23,
                    colors = SliderDefaults.colors(thumbColor = CyanAccent, activeTrackColor = CyanAccent)
                )
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(CyanAccent.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(32.dp))
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(if (userName.isBlank()) "Create Profile" else userName, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
                        Text(studyGoal, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Daily Goal: ${String.format(java.util.Locale.getDefault(), "%.1f", dailyGoalMs / 3600000f)} hrs", style = MaterialTheme.typography.labelMedium, color = CyanAccent)
                    }
                }
            }
        }
    }
}
"""

content = re.sub(pattern, new_profile_section, content)

with open('/app/applet/app/src/main/java/com/example/ui/settings/SettingsScreen.kt', 'w') as f:
    f.write(content)
