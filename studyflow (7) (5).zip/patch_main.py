import re

with open('/app/applet/app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

nav_item = """                NavigationBarItem(
                    icon = { Icon(Icons.Filled.Assessment, contentDescription = "Analytics") },
                    label = { Text("Analytics") },
                    selected = currentDestination?.hierarchy?.any { it.route == AnalyticsRoute::class.qualifiedName } == true,
                    onClick = {
                        navController.navigate(AnalyticsRoute) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Filled.Settings,"""

content = content.replace('                NavigationBarItem(\n                    icon = { Icon(Icons.Filled.Settings,', nav_item)

nav_host_item = """            composable<ProgressRoute> { ProgressScreen(viewModel) }
            composable<AnalyticsRoute> { com.example.ui.analytics.AnalyticsScreen(viewModel) }"""

content = content.replace('            composable<ProgressRoute> { ProgressScreen(viewModel) }', nav_host_item)

imports = """import com.example.ui.AnalyticsRoute
import androidx.compose.material.icons.filled.Assessment
import com.example.ui.SettingsRoute"""

content = content.replace('import com.example.ui.SettingsRoute', imports)

with open('/app/applet/app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)

