import re

with open('/app/applet/app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

replacement = """            composable<HomeRoute> { 
                HomeScreen(
                    viewModel = viewModel,
                    onNavigateToCreate = { navController.navigate(com.example.ui.CreateScheduleRoute(scheduleId = -1)) },
                    onNavigateToProgress = { navController.navigate(ProgressRoute) },
                    onNavigateToHistory = { navController.navigate(HistoryRoute) },
                    onNavigateToSettings = { navController.navigate(SettingsRoute) },
                    onNavigateToEdit = { id -> navController.navigate(com.example.ui.CreateScheduleRoute(scheduleId = id)) }
                ) 
            }"""

content = re.sub(r'            composable<HomeRoute> \{ \n                HomeScreen\([\s\S]*?onNavigateToSettings = \{ navController.navigate\(SettingsRoute\) \}\n                \) \n            \}', replacement, content)

with open('/app/applet/app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
