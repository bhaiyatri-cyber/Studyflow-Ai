import re

with open('/app/applet/app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

content = content.replace('import com.example.ui.history.HistoryScreen', 'import com.example.ui.history.HistoryScreen\nimport com.example.ui.settings.SettingsScreen\nimport com.example.ui.settings.PermissionManagementScreen')

with open('/app/applet/app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)

with open('/app/applet/app/src/main/java/com/example/ui/StudyViewModel.kt', 'r') as f:
    content = f.read()

content = content.replace('import kotlinx.coroutines.flow.StateFlow', 'import kotlinx.coroutines.flow.StateFlow\nimport kotlinx.coroutines.flow.flow')

with open('/app/applet/app/src/main/java/com/example/ui/StudyViewModel.kt', 'w') as f:
    f.write(content)
