import re

with open('/app/applet/app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

content = content.replace('import com.example.ui.HomeScreen', 'import com.example.ui.HomeScreen\nimport com.example.ui.settings.SettingsScreen\nimport com.example.ui.settings.PermissionManagementScreen')

with open('/app/applet/app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
