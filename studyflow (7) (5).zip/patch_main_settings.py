import re

with open('/app/applet/app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

target = """            composable<SettingsRoute> { 
                SettingsScreen(
                    viewModel = viewModel,
                    onNavigateToPermissions = { navController.navigate(PermissionsRoute) }
                ) 
            }"""

replacement = """            composable<SettingsRoute> { 
                SettingsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToPermissions = { navController.navigate(PermissionsRoute) }
                ) 
            }"""

content = content.replace(target, replacement)

with open('/app/applet/app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)

