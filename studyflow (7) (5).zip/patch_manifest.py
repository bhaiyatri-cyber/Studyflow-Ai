import re

with open('/app/applet/app/src/main/AndroidManifest.xml', 'r') as f:
    content = f.read()

queries_block = """    <queries>
        <intent>
            <action android:name="android.intent.action.MAIN" />
            <category android:name="android.intent.category.LAUNCHER" />
        </intent>
    </queries>

    <application"""

service_block = """        <service android:name=".engine.StudyService" android:foregroundServiceType="specialUse" android:exported="false">
            <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="study tracking"/>
        </service>
    </application>"""

content = content.replace("    <application", queries_block)
content = content.replace("    </application>", service_block)

with open('/app/applet/app/src/main/AndroidManifest.xml', 'w') as f:
    f.write(content)

