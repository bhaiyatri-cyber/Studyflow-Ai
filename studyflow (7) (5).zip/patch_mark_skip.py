import re

with open('/app/applet/app/src/main/java/com/example/engine/StatusEngine.kt', 'r') as f:
    content = f.read()

replacement = """    fun markAsSkipped(scheduleId: Int) {
        engineScope.launch {
            val schedule = studyDao.getScheduleById(scheduleId).first()
            if (schedule != null) {
                val actualTime = if (runningScheduleFlow.value?.id == schedule.id) timerEngine.elapsedTimeMs.value else 0L
                historyEngine.recordSession(schedule, TaskStatus.SKIPPED, actualTime)
                
                if (schedule.repeatType == "DAILY" || schedule.repeatType == "WEEKLY") {
                    val msInDay = 24L * 60 * 60 * 1000
                    val daysToAdd = if (schedule.repeatType == "WEEKLY") 7 else 1
                    studyDao.updateSchedule(schedule.copy(
                        status = TaskStatus.UPCOMING.displayName,
                        startTime = schedule.startTime + (daysToAdd * msInDay),
                        endTime = schedule.endTime + (daysToAdd * msInDay)
                    ))
                } else {
                    studyDao.updateSchedule(schedule.copy(status = TaskStatus.SKIPPED.displayName))
                }
            }
        }
    }"""

content = re.sub(r'    fun markAsSkipped.*?    }', replacement, content, flags=re.DOTALL)

with open('/app/applet/app/src/main/java/com/example/engine/StatusEngine.kt', 'w') as f:
    f.write(content)

