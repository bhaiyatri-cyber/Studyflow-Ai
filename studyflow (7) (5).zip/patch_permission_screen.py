import re

with open('/app/applet/app/src/main/java/com/example/ui/settings/PermissionManagementScreen.kt', 'r') as f:
    content = f.read()

lifecycle_import = "import androidx.lifecycle.LifecycleEventObserver\nimport androidx.compose.ui.platform.LocalLifecycleOwner\nimport androidx.lifecycle.Lifecycle"

if "LocalLifecycleOwner" not in content:
    content = content.replace("import androidx.compose.ui.platform.LocalContext", "import androidx.compose.ui.platform.LocalContext\n" + lifecycle_import)

lifecycle_observer = """
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshPermissions()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }
"""

if "LifecycleEventObserver" not in content:
    # insert inside PermissionManagementScreen
    content = re.sub(r'(fun PermissionManagementScreen\([\s\S]*?\{)', r'\1\n' + lifecycle_observer, content)

with open('/app/applet/app/src/main/java/com/example/ui/settings/PermissionManagementScreen.kt', 'w') as f:
    f.write(content)
