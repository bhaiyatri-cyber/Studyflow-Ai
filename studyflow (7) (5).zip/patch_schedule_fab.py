import re

with open('/app/applet/app/src/main/java/com/example/ui/schedule/ScheduleScreen.kt', 'r') as f:
    content = f.read()

content = content.replace("""        FloatingActionButton(
            onClick = { onNavigateToCreate(-1) },
            containerColor = CyanAccent,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        )""", """        FloatingActionButton(
            onClick = { onNavigateToCreate(-1) },
            containerColor = CyanAccent,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 80.dp, end = 16.dp)
        )""")

with open('/app/applet/app/src/main/java/com/example/ui/schedule/ScheduleScreen.kt', 'w') as f:
    f.write(content)

