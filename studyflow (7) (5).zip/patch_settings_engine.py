import re

with open('/app/applet/app/src/main/java/com/example/engine/SettingsEngine.kt', 'r') as f:
    content = f.read()

profile_data = """    // Local Profile
    private val AVATAR_KEY = stringPreferencesKey("user_avatar")
    val userAvatar: Flow<String> = context.settingsDataStore.data.map { it[AVATAR_KEY] ?: "person" }
    
    private val CREATED_DATE_KEY = longPreferencesKey("created_date")
    val createdDate: Flow<Long> = context.settingsDataStore.data.map { it[CREATED_DATE_KEY] ?: 0L }
    
    private val LAST_ACTIVE_DATE_KEY = longPreferencesKey("last_active_date")
    val lastActiveDate: Flow<Long> = context.settingsDataStore.data.map { it[LAST_ACTIVE_DATE_KEY] ?: 0L }
    
    private val STUDY_GOAL_KEY = stringPreferencesKey("study_goal")
    val studyGoal: Flow<String> = context.settingsDataStore.data.map { it[STUDY_GOAL_KEY] ?: "Learn something new" }
    
    private val DAILY_STUDY_GOAL_KEY = longPreferencesKey("daily_study_goal_ms")
    val dailyStudyGoalMs: Flow<Long> = context.settingsDataStore.data.map { it[DAILY_STUDY_GOAL_KEY] ?: (2 * 3600 * 1000L) }
    
    private val WEEKLY_STUDY_GOAL_KEY = longPreferencesKey("weekly_study_goal_ms")
    val weeklyStudyGoalMs: Flow<Long> = context.settingsDataStore.data.map { it[WEEKLY_STUDY_GOAL_KEY] ?: (14 * 3600 * 1000L) }
    
    private val MONTHLY_STUDY_GOAL_KEY = longPreferencesKey("monthly_study_goal_ms")
    val monthlyStudyGoalMs: Flow<Long> = context.settingsDataStore.data.map { it[MONTHLY_STUDY_GOAL_KEY] ?: (60 * 3600 * 1000L) }

    fun updateUserAvatar(avatar: String) = engineScope.launch { context.settingsDataStore.edit { it[AVATAR_KEY] = avatar } }
    fun updateCreatedDate(date: Long) = engineScope.launch { context.settingsDataStore.edit { it[CREATED_DATE_KEY] = date } }
    fun updateLastActiveDate(date: Long) = engineScope.launch { context.settingsDataStore.edit { it[LAST_ACTIVE_DATE_KEY] = date } }
    fun updateStudyGoal(goal: String) = engineScope.launch { context.settingsDataStore.edit { it[STUDY_GOAL_KEY] = goal } }
    fun updateDailyStudyGoalMs(ms: Long) = engineScope.launch { context.settingsDataStore.edit { it[DAILY_STUDY_GOAL_KEY] = ms } }
    fun updateWeeklyStudyGoalMs(ms: Long) = engineScope.launch { context.settingsDataStore.edit { it[WEEKLY_STUDY_GOAL_KEY] = ms } }
    fun updateMonthlyStudyGoalMs(ms: Long) = engineScope.launch { context.settingsDataStore.edit { it[MONTHLY_STUDY_GOAL_KEY] = ms } }
"""

content = re.sub(r'    // Local Profile[\s\S]*?    // Study Preferences', profile_data + '\n    // Study Preferences', content)

with open('/app/applet/app/src/main/java/com/example/engine/SettingsEngine.kt', 'w') as f:
    f.write(content)
