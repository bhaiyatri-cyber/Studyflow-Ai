import re

with open('/app/applet/app/src/main/java/com/example/engine/StatusEngine.kt', 'r') as f:
    content = f.read()

replacement = """                if (newStatus == TaskStatus.COMPLETED || newStatus == TaskStatus.MISSED) {
                    val actualTime = if (activeSchedule?.id == schedule.id) currentDuration else 0L
                    historyEngine.recordSession(schedule, newStatus, actualTime)
                }
                
                // Roll forward if repeating
                if ((newStatus == TaskStatus.COMPLETED || newStatus == TaskStatus.MISSED || newStatus == TaskStatus.SKIPPED) 
                    && (schedule.repeatType == "DAILY" || schedule.repeatType == "WEEKLY")) {
                    val msInDay = 24L * 60 * 60 * 1000
                    val daysToAdd = if (schedule.repeatType == "WEEKLY") 7 else 1
                    val newStartTime = schedule.startTime + (daysToAdd * msInDay)
                    val newEndTime = schedule.endTime + (daysToAdd * msInDay)
                    studyDao.updateSchedule(schedule.copy(
                        status = TaskStatus.UPCOMING.displayName,
                        startTime = newStartTime,
                        endTime = newEndTime
                    ))
                }
            }"""

content = content.replace("""                if (newStatus == TaskStatus.COMPLETED || newStatus == TaskStatus.MISSED) {
                    val actualTime = if (activeSchedule?.id == schedule.id) currentDuration else 0L
                    historyEngine.recordSession(schedule, newStatus, actualTime)
                }
            }""", replacement)

with open('/app/applet/app/src/main/java/com/example/engine/StatusEngine.kt', 'w') as f:
    f.write(content)

