import re

with open('/app/applet/app/src/main/java/com/example/engine/ProgressEngine.kt', 'r') as f:
    content = f.read()

replacement = """    private fun calculateStreak(sessions: List<StudySession>): Int {
        val completedSessions = sessions.filter { it.status == TaskStatus.COMPLETED.displayName }
            .sortedByDescending { it.date }
        
        if (completedSessions.isEmpty()) return 0
        
        var streak = 0
        var lastDay = -1L
        
        val zoneId = java.time.ZoneId.systemDefault()
        
        for (session in completedSessions) {
            val absoluteDay = java.time.Instant.ofEpochMilli(session.date).atZone(zoneId).toLocalDate().toEpochDay()
            
            if (lastDay == -1L) {
                val currentAbsoluteDay = java.time.LocalDate.now(zoneId).toEpochDay()
                if (absoluteDay == currentAbsoluteDay || absoluteDay == currentAbsoluteDay - 1) {
                    streak++
                    lastDay = absoluteDay
                } else {
                    break 
                }
            } else {
                if (absoluteDay == lastDay) {
                    continue 
                } else if (absoluteDay == lastDay - 1) {
                    streak++
                    lastDay = absoluteDay
                } else {
                    break 
                }
            }
        }
        return streak
    }"""

content = re.sub(r'    private fun calculateStreak.*?    \}', replacement, content, flags=re.DOTALL)

with open('/app/applet/app/src/main/java/com/example/engine/ProgressEngine.kt', 'w') as f:
    f.write(content)

