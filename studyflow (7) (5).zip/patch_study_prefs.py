import re

with open('/app/applet/app/src/main/java/com/example/ui/settings/SettingsScreen.kt', 'r') as f:
    content = f.read()

study_prefs = """@Composable
fun StudyPreferencesSection(viewModel: StudyViewModel) {
    val defaultOffline by viewModel.defaultStudyModeOffline.collectAsState()
    val defaultDuration by viewModel.defaultStudyDuration.collectAsState()
    val defaultReminder by viewModel.defaultReminderMinutes.collectAsState()
    val defaultPriority by viewModel.defaultPriority.collectAsState()
    val defaultRepeat by viewModel.defaultRepeat.collectAsState()

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Study Preferences", style = MaterialTheme.typography.titleMedium, color = CyanAccent, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Default Study Mode (Offline)", color = MaterialTheme.colorScheme.onSurface)
                Switch(checked = defaultOffline, onCheckedChange = { viewModel.updateDefaultStudyModeOffline(it) })
            }
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Default Duration (min)", color = MaterialTheme.colorScheme.onSurface)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { viewModel.updateDefaultStudyDuration(maxOf(5, defaultDuration - 5)) }) { Icon(Icons.Filled.Remove, null, tint = CyanAccent) }
                    Text(defaultDuration.toString(), color = MaterialTheme.colorScheme.onSurface)
                    IconButton(onClick = { viewModel.updateDefaultStudyDuration(defaultDuration + 5) }) { Icon(Icons.Filled.Add, null, tint = CyanAccent) }
                }
            }
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Default Reminder (min)", color = MaterialTheme.colorScheme.onSurface)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { viewModel.updateDefaultReminderMinutes(maxOf(0, defaultReminder - 5)) }) { Icon(Icons.Filled.Remove, null, tint = CyanAccent) }
                    Text(defaultReminder.toString(), color = MaterialTheme.colorScheme.onSurface)
                    IconButton(onClick = { viewModel.updateDefaultReminderMinutes(defaultReminder + 5) }) { Icon(Icons.Filled.Add, null, tint = CyanAccent) }
                }
            }
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Default Priority", color = MaterialTheme.colorScheme.onSurface)
                TextButton(onClick = { 
                    val next = when(defaultPriority) { "Low" -> "Medium"; "Medium" -> "High"; else -> "Low" }
                    viewModel.updateDefaultPriority(next)
                }) { Text(defaultPriority, color = CyanAccent) }
            }
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Default Repeat", color = MaterialTheme.colorScheme.onSurface)
                TextButton(onClick = { 
                    val next = when(defaultRepeat) { "ONE_TIME" -> "DAILY"; "DAILY" -> "WEEKLY"; "WEEKLY" -> "MONTHLY"; else -> "ONE_TIME" }
                    viewModel.updateDefaultRepeat(next)
                }) { Text(defaultRepeat, color = CyanAccent) }
            }
        }
    }
}
"""

content = re.sub(r'@Composable\nfun StudyPreferencesSection\([\s\S]*?\}\n\}\n', study_prefs, content)

with open('/app/applet/app/src/main/java/com/example/ui/settings/SettingsScreen.kt', 'w') as f:
    f.write(content)
