import re

with open('/app/applet/app/src/main/java/com/example/engine/TimerEngine.kt', 'r') as f:
    content = f.read()

funcs = """    fun pauseTimer() {
        if (_timerState.value == TimerState.RUNNING) {
            _timerState.value = TimerState.PAUSED
        }
    }

    fun resumeTimer() {
        if (_timerState.value == TimerState.PAUSED) {
            _timerState.value = TimerState.RUNNING
        }
    }
"""

content = content.replace('    fun setActiveSchedule(schedule: StudySchedule?) {', funcs + '\n    fun setActiveSchedule(schedule: StudySchedule?) {')

with open('/app/applet/app/src/main/java/com/example/engine/TimerEngine.kt', 'w') as f:
    f.write(content)
