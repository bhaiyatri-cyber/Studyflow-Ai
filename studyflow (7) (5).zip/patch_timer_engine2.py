import re

with open('/app/applet/app/src/main/java/com/example/engine/TimerEngine.kt', 'r') as f:
    content = f.read()

# remove SensorEventListener
content = content.replace("class TimerEngine private constructor(\n    private val context: Context,\n    private val permissionEngine: PermissionEngine\n) : SensorEventListener {", "class TimerEngine private constructor(\n    private val context: Context,\n    private val permissionEngine: PermissionEngine,\n    private val offlineTrackingEngine: OfflineTrackingEngine\n) {")

content = content.replace("private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager", "")
content = content.replace("private val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)", "")

# remove sensor state
content = re.sub(r'    // Sensor state\n.*?lastSensorUpdateTime = 0L\n', '', content, flags=re.DOTALL)

# in startMonitoring
start_mon_replace = """        if (activeSchedule?.isOfflineMode == true) {
            offlineTrackingEngine.startMonitoring()
        }"""
content = re.sub(r'        if \(activeSchedule\?\.isOfflineMode == true\) \{\n            accelerometer\?\.let \{\n                sensorManager\.registerListener\(this, it, SensorManager\.SENSOR_DELAY_NORMAL\)\n            \}\n        \}', start_mon_replace, content, flags=re.DOTALL)

# in stopMonitoring
stop_mon_replace = """        try {
            context.stopService(android.content.Intent(context, StudyService::class.java))
        } catch (e: Exception) {}
        
        offlineTrackingEngine.stopMonitoring()"""
content = re.sub(r'        try \{\n            context\.stopService\(android\.content\.Intent\(context, StudyService::class\.java\)\)\n        \} catch \(e: Exception\) \{\}\n        \n        sensorManager\.unregisterListener\(this\)', stop_mon_replace, content, flags=re.DOTALL)

# in checkConditions
check_replace = """        // 3. Check specific mode conditions
        return if (schedule.isOfflineMode) {
            offlineTrackingEngine.isTrackingConditionsMet.value
        } else {"""
content = re.sub(r'        // 3\. Check specific mode conditions\n        return if \(schedule\.isOfflineMode\) \{\n            isFaceDown && isStable\n        \} else \{', check_replace, content, flags=re.DOTALL)

# remove onSensorChanged and onAccuracyChanged
content = re.sub(r'    override fun onSensorChanged.*?    \}\n\n    override fun onAccuracyChanged.*?    \}\n', '', content, flags=re.DOTALL)

# companion object
comp_replace = """    companion object {
        @Volatile
        private var INSTANCE: TimerEngine? = null

        fun getInstance(context: Context, permissionEngine: PermissionEngine, offlineTrackingEngine: OfflineTrackingEngine): TimerEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: TimerEngine(context.applicationContext, permissionEngine, offlineTrackingEngine).also { INSTANCE = it }
            }
        }
    }"""
content = re.sub(r'    companion object \{.*?    \}', comp_replace, content, flags=re.DOTALL)

with open('/app/applet/app/src/main/java/com/example/engine/TimerEngine.kt', 'w') as f:
    f.write(content)

