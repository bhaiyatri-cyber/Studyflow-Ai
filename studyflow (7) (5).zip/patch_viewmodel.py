import re

with open('/app/applet/app/src/main/java/com/example/ui/StudyViewModel.kt', 'r') as f:
    content = f.read()

date_prop = """    val currentDate: StateFlow<String> = kotlinx.coroutines.flow.flow {
        while (true) {
            val sdf = java.text.SimpleDateFormat("EEEE, MMMM d", java.util.Locale.getDefault())
            emit(sdf.format(java.util.Date()))
            kotlinx.coroutines.delay(60000)
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, "")
"""

content = content.replace('    val currentTip = engine.assistantEngine.currentTip', '    val currentTip = engine.assistantEngine.currentTip\n' + date_prop)

with open('/app/applet/app/src/main/java/com/example/ui/StudyViewModel.kt', 'w') as f:
    f.write(content)
