import re

with open('/app/applet/app/src/main/java/com/example/ui/StudyViewModel.kt', 'r') as f:
    content = f.read()

profile_exports = """    val createdDate: StateFlow<Long> = engine.settingsEngine.createdDate.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
    fun updateCreatedDate(date: Long) = engine.settingsEngine.updateCreatedDate(date)

    val lastActiveDate: StateFlow<Long> = engine.settingsEngine.lastActiveDate.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
    fun updateLastActiveDate(date: Long) = engine.settingsEngine.updateLastActiveDate(date)

    val studyGoal: StateFlow<String> = engine.settingsEngine.studyGoal.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Learn something new")
    fun updateStudyGoal(goal: String) = engine.settingsEngine.updateStudyGoal(goal)

    val dailyStudyGoalMs: StateFlow<Long> = engine.settingsEngine.dailyStudyGoalMs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 2 * 3600 * 1000L)
    fun updateDailyStudyGoalMs(ms: Long) = engine.settingsEngine.updateDailyStudyGoalMs(ms)

    val weeklyStudyGoalMs: StateFlow<Long> = engine.settingsEngine.weeklyStudyGoalMs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 14 * 3600 * 1000L)
    fun updateWeeklyStudyGoalMs(ms: Long) = engine.settingsEngine.updateWeeklyStudyGoalMs(ms)

    val monthlyStudyGoalMs: StateFlow<Long> = engine.settingsEngine.monthlyStudyGoalMs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 60 * 3600 * 1000L)
    fun updateMonthlyStudyGoalMs(ms: Long) = engine.settingsEngine.updateMonthlyStudyGoalMs(ms)
"""

if "createdDate" not in content:
    content = content.replace("    fun updateUserAvatar(avatar: String) = engine.settingsEngine.updateUserAvatar(avatar)", "    fun updateUserAvatar(avatar: String) = engine.settingsEngine.updateUserAvatar(avatar)\n\n" + profile_exports)

with open('/app/applet/app/src/main/java/com/example/ui/StudyViewModel.kt', 'w') as f:
    f.write(content)
