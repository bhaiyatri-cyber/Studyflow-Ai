import re

with open('/app/applet/app/src/main/java/com/example/ui/StudyViewModel.kt', 'r') as f:
    content = f.read()

# I will add the flow exports to the viewmodel
exports = """
    // Settings Exports
    val userAvatar: StateFlow<String> = engine.settingsEngine.userAvatar.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "default_avatar")
    fun updateUserAvatar(avatar: String) = engine.settingsEngine.updateUserAvatar(avatar)

    val defaultStudyModeOffline: StateFlow<Boolean> = engine.settingsEngine.defaultStudyModeOffline.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    fun updateDefaultStudyModeOffline(offline: Boolean) = engine.settingsEngine.updateDefaultStudyModeOffline(offline)

    val defaultReminderMinutes: StateFlow<Int> = engine.settingsEngine.defaultReminderMinutes.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 10)
    fun updateDefaultReminderMinutes(minutes: Int) = engine.settingsEngine.updateDefaultReminderMinutes(minutes)

    val defaultPriority: StateFlow<String> = engine.settingsEngine.defaultPriority.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Medium")
    fun updateDefaultPriority(priority: String) = engine.settingsEngine.updateDefaultPriority(priority)

    val defaultRepeat: StateFlow<String> = engine.settingsEngine.defaultRepeat.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "ONE_TIME")
    fun updateDefaultRepeat(repeat: String) = engine.settingsEngine.updateDefaultRepeat(repeat)

    val defaultStudyDuration: StateFlow<Int> = engine.settingsEngine.defaultStudyDuration.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 60)
    fun updateDefaultStudyDuration(duration: Int) = engine.settingsEngine.updateDefaultStudyDuration(duration)

    val enableNotifications: StateFlow<Boolean> = engine.settingsEngine.enableNotifications.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    fun updateEnableNotifications(enable: Boolean) = engine.settingsEngine.updateEnableNotifications(enable)

    val reminderSound: StateFlow<Boolean> = engine.settingsEngine.reminderSound.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    fun updateReminderSound(enable: Boolean) = engine.settingsEngine.updateReminderSound(enable)

    val vibration: StateFlow<Boolean> = engine.settingsEngine.vibration.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    fun updateVibration(enable: Boolean) = engine.settingsEngine.updateVibration(enable)

    val dailySummary: StateFlow<Boolean> = engine.settingsEngine.dailySummary.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    fun updateDailySummary(enable: Boolean) = engine.settingsEngine.updateDailySummary(enable)

    val silentMode: StateFlow<Boolean> = engine.settingsEngine.silentMode.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    fun updateSilentMode(enable: Boolean) = engine.settingsEngine.updateSilentMode(enable)

    val darkMode: StateFlow<Boolean> = engine.settingsEngine.darkMode.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    fun updateDarkMode(enable: Boolean) = engine.settingsEngine.updateDarkMode(enable)

    val accentColor: StateFlow<Long> = engine.settingsEngine.accentColor.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0xFF00E5FF)
    fun updateAccentColor(color: Long) = engine.settingsEngine.updateAccentColor(color)

    val dynamicTheme: StateFlow<Boolean> = engine.settingsEngine.dynamicTheme.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    fun updateDynamicTheme(enable: Boolean) = engine.settingsEngine.updateDynamicTheme(enable)

    val animationToggle: StateFlow<Boolean> = engine.settingsEngine.animationToggle.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    fun updateAnimationToggle(enable: Boolean) = engine.settingsEngine.updateAnimationToggle(enable)

    val dbSize: StateFlow<Long> = flow { emit(engine.context.getDatabasePath("studyflow_database").length()) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
    
    val backupFileDate: StateFlow<Long> = flow { 
        val file = java.io.File(engine.context.filesDir, "studyflow_backup.json")
        emit(if (file.exists()) file.lastModified() else 0L)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
    
    val backupFileSize: StateFlow<Long> = flow { 
        val file = java.io.File(engine.context.filesDir, "studyflow_backup.json")
        emit(if (file.exists()) file.length() else 0L)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
"""

content = content.replace('val userName: StateFlow<String> = engine.userName.stateIn(', exports + '\n    val userName: StateFlow<String> = engine.userName.stateIn(')

with open('/app/applet/app/src/main/java/com/example/ui/StudyViewModel.kt', 'w') as f:
    f.write(content)

