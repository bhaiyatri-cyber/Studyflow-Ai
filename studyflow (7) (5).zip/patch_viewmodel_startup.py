import re

with open('/app/applet/app/src/main/java/com/example/ui/StudyViewModel.kt', 'r') as f:
    content = f.read()

target_init = """    init {
        viewModelScope.launch {
            delay(1500) // Splash minimum duration
            val name = engine.userName.first()
            if (name.isBlank()) {
                _startupState.value = StartupState.NEEDS_SETUP
            } else {
                _startupState.value = StartupState.READY
            }
        }
    }"""

new_init = """    private val _loadingStatus = MutableStateFlow("Initializing StudyFlowCoreEngine...")
    val loadingStatus = _loadingStatus.asStateFlow()

    init {
        viewModelScope.launch {
            delay(500) // Animation intro
            
            _loadingStatus.value = "Loading Local Database..."
            delay(300)
            
            _loadingStatus.value = "Loading Profile..."
            val name = engine.userName.first()
            delay(200)
            
            _loadingStatus.value = "Loading Settings..."
            delay(200)
            
            _loadingStatus.value = "Loading Permissions..."
            engine.permissionEngine.refreshPermissions()
            delay(200)
            
            _loadingStatus.value = "Loading Schedule..."
            delay(200)
            
            _loadingStatus.value = "Loading Timer State..."
            delay(200)
            
            _loadingStatus.value = "Loading Progress..."
            delay(200)
            
            _loadingStatus.value = "Loading History..."
            delay(200)
            
            _loadingStatus.value = "Initialization Complete"
            delay(300)

            if (name.isBlank()) {
                _startupState.value = StartupState.NEEDS_SETUP
            } else {
                _startupState.value = StartupState.READY
            }
        }
    }"""

content = content.replace(target_init, new_init)

with open('/app/applet/app/src/main/java/com/example/ui/StudyViewModel.kt', 'w') as f:
    f.write(content)

