import re

with open('/app/applet/app/src/main/java/com/example/ui/StudyViewModel.kt', 'r') as f:
    content = f.read()

funcs = """    fun pauseTimer() {
        engine.timerEngine.pauseTimer()
    }
    fun resumeTimer() {
        engine.timerEngine.resumeTimer()
    }
    fun stopTimer() {
        setRunningSchedule(null)
    }
"""

content = content.replace('    fun setRunningSchedule(schedule: StudySchedule?) {\n        engine.setRunningSchedule(schedule)\n    }', '    fun setRunningSchedule(schedule: StudySchedule?) {\n        engine.setRunningSchedule(schedule)\n    }\n' + funcs)

with open('/app/applet/app/src/main/java/com/example/ui/StudyViewModel.kt', 'w') as f:
    f.write(content)
