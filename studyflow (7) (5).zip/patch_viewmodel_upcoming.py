import re

with open('/app/applet/app/src/main/java/com/example/ui/StudyViewModel.kt', 'r') as f:
    content = f.read()

upcoming = """    val upcomingSchedules: StateFlow<List<StudySchedule>> = allSchedules.map { list ->
        list.filter { it.status == com.example.engine.TaskStatus.UPCOMING.displayName }
            .sortedBy { it.startTime }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
"""

content = content.replace('    val allSchedules: StateFlow<List<StudySchedule>> = engine.studyDao.getAllSchedules().stateIn(', upcoming + '    val allSchedules: StateFlow<List<StudySchedule>> = engine.studyDao.getAllSchedules().stateIn(')

with open('/app/applet/app/src/main/java/com/example/ui/StudyViewModel.kt', 'w') as f:
    f.write(content)
