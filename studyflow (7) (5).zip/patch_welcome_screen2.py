import re

with open('/app/applet/app/src/main/java/com/example/ui/startup/WelcomeScreen.kt', 'r') as f:
    content = f.read()

new_imports = """import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.School"""

if "import androidx.compose.foundation.clickable" not in content:
    content = content.replace("import androidx.compose.ui.unit.dp", "import androidx.compose.ui.unit.dp\n" + new_imports)

welcome_1_old = """                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it },
                            label = { Text("Your Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanAccent,
                                focusedLabelColor = CyanAccent,
                                unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                        
                        Spacer(modifier = Modifier.height(32.dp))
                        Button(
                            onClick = {
                                if (nameInput.isNotBlank()) {
                                    viewModel.updateUserName(nameInput.trim())
                                    step = 2
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            enabled = nameInput.isNotBlank(),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CyanAccent)
                        ) {
                            Text("Continue", color = DeepCharcoal, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        }"""

welcome_1_new = """                        var selectedAvatar by remember { mutableStateOf("person") }
                        var selectedGoalHours by remember { mutableFloatStateOf(2f) }
                        
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            val avatars = listOf("person" to Icons.Default.Person, "face" to Icons.Default.Face, "emoji" to Icons.Default.EmojiEmotions, "pets" to Icons.Default.Pets, "school" to Icons.Default.School)
                            avatars.forEach { (id, icon) ->
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(if (selectedAvatar == id) CyanAccent else MaterialTheme.colorScheme.surfaceVariant)
                                        .clickable { selectedAvatar = id },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(icon, contentDescription = null, tint = if (selectedAvatar == id) DeepCharcoal else MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(24.dp))
                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it },
                            label = { Text("Your Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanAccent,
                                focusedLabelColor = CyanAccent,
                                unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                        
                        Spacer(modifier = Modifier.height(24.dp))
                        Text("Daily Goal: ${selectedGoalHours.toInt()} hours", color = MaterialTheme.colorScheme.onSurface)
                        Slider(
                            value = selectedGoalHours,
                            onValueChange = { selectedGoalHours = it },
                            valueRange = 1f..12f,
                            steps = 10,
                            colors = SliderDefaults.colors(thumbColor = CyanAccent, activeTrackColor = CyanAccent)
                        )
                        
                        Spacer(modifier = Modifier.height(32.dp))
                        Button(
                            onClick = {
                                if (nameInput.isNotBlank()) {
                                    viewModel.updateUserName(nameInput.trim())
                                    viewModel.updateUserAvatar(selectedAvatar)
                                    viewModel.updateDailyStudyGoalMs((selectedGoalHours * 3600 * 1000L).toLong())
                                    viewModel.updateCreatedDate(System.currentTimeMillis())
                                    step = 2
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            enabled = nameInput.isNotBlank(),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CyanAccent)
                        ) {
                            Text("Continue", color = DeepCharcoal, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        }"""

content = content.replace(welcome_1_old, welcome_1_new)

with open('/app/applet/app/src/main/java/com/example/ui/startup/WelcomeScreen.kt', 'w') as f:
    f.write(content)
