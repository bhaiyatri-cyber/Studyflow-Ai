import re

with open('/app/applet/app/src/main/java/com/example/ui/schedule/ScheduleScreen.kt', 'r') as f:
    content = f.read()

# We will completely replace the file contents to implement the requested features.
new_content = """package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.StudySchedule
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkCharcoal
import com.example.ui.theme.DeepCharcoal
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun ScheduleScreen(viewModel: StudyViewModel, onNavigateToCreate: (Int) -> Unit) {
    val schedules by viewModel.allSchedules.collectAsState()
    val runningSchedule by viewModel.runningSchedule.collectAsState()

    var showSwitchDialog by remember { mutableStateOf<StudySchedule?>(null) }

    if (showSwitchDialog != null) {
        AlertDialog(
            onDismissRequest = { showSwitchDialog = null },
            title = { Text("Switch sessions?") },
            text = { Text("Starting a new session will stop the current one. Progress will be lost. Continue?") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.setRunningSchedule(showSwitchDialog)
                    showSwitchDialog = null
                }) {
                    Text("Yes, Switch")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSwitchDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(
                text = "My Schedule",
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(16.dp))

            if (schedules.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize().padding(bottom = 72.dp), contentAlignment = Alignment.Center) {
                    Text(
                        text = "No schedules yet. Tap + to add one.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(schedules) { schedule ->
                        ScheduleItem(
                            schedule = schedule,
                            isRunning = runningSchedule?.id == schedule.id,
                            onEdit = { onNavigateToCreate(schedule.id) },
                            onDelete = { viewModel.deleteSchedule(schedule) },
                            onStart = {
                                if (runningSchedule != null && runningSchedule?.id != schedule.id) {
                                    showSwitchDialog = schedule
                                } else {
                                    viewModel.setRunningSchedule(schedule)
                                }
                            },
                            onStop = { viewModel.setRunningSchedule(null) },
                            onSkip = { viewModel.markAsSkipped(schedule.id) }
                        )
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { onNavigateToCreate(-1) },
            containerColor = CyanAccent,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = "Add Schedule", tint = DeepCharcoal)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduleItem(
    schedule: StudySchedule,
    isRunning: Boolean,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onSkip: () -> Unit
) {
    val formatter = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }
    val timeRange = "${formatter.format(schedule.startTime)} - ${formatter.format(schedule.endTime)}"

    var showDeleteConfirm by remember { mutableStateOf(false) }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Schedule") },
            text = { Text("Are you sure you want to delete '${schedule.subjectName}'? This action cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    onDelete()
                    showDeleteConfirm = false
                }) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    val statusColor = when (schedule.status) {
        "Completed" -> CyanAccent
        "Missed" -> MaterialTheme.colorScheme.error
        "Skipped" -> Color(0xFFFFB300) // Amber
        "Running" -> Color(0xFF00E676) // Green
        "Waiting" -> Color(0xFF29B6F6) // Light Blue
        "Paused" -> Color(0xFFFFA726) // Orange
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    val cardColor = if (isRunning) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
    val borderColor = if (isRunning) CyanAccent else Color.Transparent

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .border(width = if (isRunning) 2.dp else 0.dp, color = borderColor, shape = RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
            // Left edge color stripe
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(8.dp)
                    .background(Color(schedule.colorAccent))
            )

            Column(modifier = Modifier.padding(16.dp).weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text(text = schedule.subjectName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    
                    // Status Badge
                    Surface(
                        color = statusColor.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.padding(start = 8.dp)
                    ) {
                        Text(
                            text = schedule.status,
                            color = statusColor,
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Schedule, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = timeRange, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    
                    if (schedule.repeatType == "DAILY" || schedule.repeatType == "WEEKLY") {
                        Spacer(modifier = Modifier.width(12.dp))
                        Icon(Icons.Filled.Repeat, contentDescription = "Repeating", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(text = schedule.repeatType.lowercase().capitalize(), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Mode Label
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val modeIcon = if (schedule.isOfflineMode) Icons.Filled.WifiOff else Icons.Filled.PhoneAndroid
                    val modeText = if (schedule.isOfflineMode) "Offline Mode" else "Online: ${schedule.selectedAppPackage ?: "Unknown"}"
                    Icon(modeIcon, contentDescription = null, modifier = Modifier.size(16.dp), tint = CyanAccent)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = modeText, style = MaterialTheme.typography.bodySmall, color = CyanAccent)
                }

                if (schedule.notes.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = schedule.notes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Actions
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    when (schedule.status) {
                        "Upcoming", "Waiting" -> {
                            TextButton(onClick = onEdit) { Text("Edit") }
                            TextButton(onClick = { showDeleteConfirm = true }, colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Delete") }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(onClick = onStart, colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = DeepCharcoal)) { Text("Start") }
                        }
                        "Running", "Paused" -> {
                            TextButton(onClick = onSkip) { Text("Skip") }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(onClick = onStop, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("Stop") }
                        }
                        else -> { // Completed, Missed, Skipped
                            TextButton(onClick = { showDeleteConfirm = true }, colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
}
"""

with open('/app/applet/app/src/main/java/com/example/ui/schedule/ScheduleScreen.kt', 'w') as f:
    f.write(new_content)

print("Done")
