import re

with open('/app/applet/app/src/main/java/com/example/engine/TimerEngine.kt', 'r') as f:
    content = f.read()

replacement = """package com.example.engine

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import com.example.data.StudySchedule
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class TimerState(val statusName: String) {
    NOT_STARTED("Not Started"),
    WAITING("Waiting"),
    RUNNING("Running"),
    PAUSED("Paused"),
    COMPLETED("Completed"),
    MISSED("Missed")
}

class TimerEngine private constructor(
    private val context: Context,
    private val permissionEngine: PermissionEngine,
    private val offlineTrackingEngine: OfflineTrackingEngine
) {
    private val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

    private val _timerState = MutableStateFlow(TimerState.NOT_STARTED)
    val timerState: StateFlow<TimerState> = _timerState.asStateFlow()

    private val _elapsedTimeMs = MutableStateFlow(0L)
    val elapsedTimeMs: StateFlow<Long> = _elapsedTimeMs.asStateFlow()

    private val _timerError = MutableStateFlow<String?>(null)
    val timerError: StateFlow<String?> = _timerError.asStateFlow()
    
    private val _currentApp = MutableStateFlow<String?>(null)
    val currentApp: StateFlow<String?> = _currentApp.asStateFlow()

    private var activeSchedule: StudySchedule? = null
    
    private var timerJob: Job? = null
    private val engineScope = CoroutineScope(Dispatchers.Default)

    fun setActiveSchedule(schedule: StudySchedule?) {
        activeSchedule = schedule
        _elapsedTimeMs.value = 0L
        _timerState.value = if (schedule == null) TimerState.NOT_STARTED else TimerState.WAITING
        
        if (schedule != null) {
            startMonitoring()
        } else {
            stopMonitoring()
        }
    }

    private fun startMonitoring() {
        stopMonitoring()
        
        try {
            val serviceIntent = android.content.Intent(context, StudyService::class.java)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (e: Exception) {}
        
        if (activeSchedule?.isOfflineMode == true) {
            offlineTrackingEngine.startMonitoring()
        }
        
        timerJob = engineScope.launch {
            var lastTickTime = System.currentTimeMillis()
            
            while (isActive) {
                val schedule = activeSchedule ?: break
                val now = System.currentTimeMillis()
                val delta = now - lastTickTime
                lastTickTime = now

                val isConditionMet = checkConditions(schedule, now)

                if (isConditionMet) {
                    _timerState.value = TimerState.RUNNING
                    _elapsedTimeMs.value += delta
                } else {
                    if (_timerState.value == TimerState.RUNNING) {
                        _timerState.value = TimerState.PAUSED
                    } else if (_timerState.value == TimerState.NOT_STARTED) {
                        if (now >= schedule.startTime) {
                            _timerState.value = TimerState.WAITING
                        }
                    }
                }
                
                if (now >= schedule.endTime) {
                    val requiredDuration = schedule.endTime - schedule.startTime
                    if (_elapsedTimeMs.value >= requiredDuration * 0.8) {
                        _timerState.value = TimerState.COMPLETED
                    } else {
                        _timerState.value = TimerState.MISSED
                    }
                    stopMonitoring()
                    break
                }
                
                delay(1000)
            }
        }
    }

    private fun stopMonitoring() {
        timerJob?.cancel()
        timerJob = null
        
        try {
            context.stopService(android.content.Intent(context, StudyService::class.java))
        } catch (e: Exception) {}
        
        offlineTrackingEngine.stopMonitoring()
    }

    private fun checkConditions(schedule: StudySchedule, now: Long): Boolean {
        // 1. Check time
        if (now < schedule.startTime) return false

        // 2. Check permissions
        if (!schedule.isOfflineMode) { 
             if (permissionEngine.usageAccessState.value != PermissionState.GRANTED) { 
                 _timerError.value = "Timer cannot start.\\nUsage Access is not granted." 
                 return false 
             }
        }
        
        _timerError.value = null

        // 3. Check specific mode conditions
        return if (schedule.isOfflineMode) {
            offlineTrackingEngine.isTrackingConditionsMet.value
        } else {
            schedule.selectedAppPackage?.let { checkForegroundApp(it, now) } ?: false
        }
    }
    
    private fun checkForegroundApp(targetPackages: String, now: Long): Boolean {
        val packagesList = targetPackages.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (packagesList.isEmpty()) return false

        val startTime = now - 1000 * 60 * 60 // Look back 1 hour to find current state
        val events = usageStatsManager.queryEvents(startTime, now)
        val event = UsageEvents.Event()
        
        var currentForeground: String? = null
        
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                currentForeground = event.packageName
            } else if (event.eventType == UsageEvents.Event.ACTIVITY_PAUSED || event.eventType == UsageEvents.Event.ACTIVITY_STOPPED) {
                if (currentForeground == event.packageName) {
                    currentForeground = null
                }
            }
        }
        
        _currentApp.value = currentForeground
        return currentForeground in packagesList
    }

    companion object {
        @Volatile
        private var INSTANCE: TimerEngine? = null

        fun getInstance(context: Context, permissionEngine: PermissionEngine, offlineTrackingEngine: OfflineTrackingEngine): TimerEngine {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: TimerEngine(context.applicationContext, permissionEngine, offlineTrackingEngine).also { INSTANCE = it }
            }
        }
    }
}
"""

with open('/app/applet/app/src/main/java/com/example/engine/TimerEngine.kt', 'w') as f:
    f.write(replacement)

