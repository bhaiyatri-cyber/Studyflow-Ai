package com.example.ui.settings

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.School
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.engine.PermissionType
import com.example.ui.StudyViewModel
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkCharcoal
import com.example.ui.theme.DeepCharcoal
import com.example.ui.components.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: StudyViewModel, onNavigateBack: () -> Unit, onNavigateToPermissions: () -> Unit) {
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepCharcoal,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                    navigationIconContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        },
        containerColor = DeepCharcoal
    ) { paddingValues ->
        ResponsiveLayout(
            modifier = Modifier.padding(paddingValues)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
            LocalProfileSection(viewModel)
            PermissionsSection(viewModel, onNavigateToPermissions)
            StudyPreferencesSection(viewModel)
            NotificationSettingsSection(viewModel)
            BackupRestoreSection(viewModel)
            AppearanceSection(viewModel)
            DataStorageSection(viewModel)
            AboutSection()
            Spacer(modifier = Modifier.height(32.dp))
        }
    }

}
}

@Composable
fun LocalProfileSection(viewModel: StudyViewModel) {
    val userName by viewModel.userName.collectAsState()
    val userAvatar by viewModel.userAvatar.collectAsState()
    val studyGoal by viewModel.studyGoal.collectAsState()
    val dailyGoalMs by viewModel.dailyStudyGoalMs.collectAsState()
    
    var editMode by remember { mutableStateOf(false) }
    var tempName by remember(userName) { mutableStateOf(userName) }
    var tempAvatar by remember(userAvatar) { mutableStateOf(userAvatar) }
    var tempGoal by remember(studyGoal) { mutableStateOf(studyGoal) }
    var tempDailyGoalHours by remember(dailyGoalMs) { mutableFloatStateOf(dailyGoalMs / 3600000f) }

    val icon: ImageVector = when (if(editMode) tempAvatar else userAvatar) {
        "face" -> Icons.Default.Face
        "emoji" -> Icons.Default.EmojiEmotions
        "pets" -> Icons.Default.Pets
        "school" -> Icons.Default.School
        else -> Icons.Default.Person
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Local Profile", style = MaterialTheme.typography.titleMedium, color = CyanAccent, fontWeight = FontWeight.Bold)
                IconButton(onClick = {
                    if (editMode) {
                        viewModel.updateUserName(tempName)
                        viewModel.updateUserAvatar(tempAvatar)
                        viewModel.updateStudyGoal(tempGoal)
                        viewModel.updateDailyStudyGoalMs((tempDailyGoalHours * 3600 * 1000L).toLong())
                    }
                    editMode = !editMode
                }) {
                    Icon(if (editMode) Icons.Filled.Check else Icons.Filled.Edit, contentDescription = "Edit Profile", tint = CyanAccent)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            
            if (editMode) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    val avatars = listOf("person" to Icons.Default.Person, "face" to Icons.Default.Face, "emoji" to Icons.Default.EmojiEmotions, "pets" to Icons.Default.Pets, "school" to Icons.Default.School)
                    avatars.forEach { (id, ic) ->
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(if (tempAvatar == id) CyanAccent else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { tempAvatar = id },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(ic, contentDescription = null, tint = if (tempAvatar == id) DeepCharcoal else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = tempName,
                    onValueChange = { tempName = it },
                    label = { Text("Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = tempGoal,
                    onValueChange = { tempGoal = it },
                    label = { Text("Study Goal") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text("Daily Goal: ${String.format(java.util.Locale.getDefault(), "%.1f", tempDailyGoalHours)} hours", color = MaterialTheme.colorScheme.onSurface)
                Slider(
                    value = tempDailyGoalHours,
                    onValueChange = { tempDailyGoalHours = it },
                    valueRange = 0.5f..12f,
                    steps = 23,
                    colors = SliderDefaults.colors(thumbColor = CyanAccent, activeTrackColor = CyanAccent)
                )
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(CyanAccent.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(32.dp))
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(if (userName.isBlank()) "Create Profile" else userName, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
                        Text(studyGoal, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Daily Goal: ${String.format(java.util.Locale.getDefault(), "%.1f", dailyGoalMs / 3600000f)} hrs", style = MaterialTheme.typography.labelMedium, color = CyanAccent)
                    }
                }
            }
        }
    }
}
@Composable
fun PermissionsSection(viewModel: StudyViewModel, onNavigateToPermissions: () -> Unit) {
    val context = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onNavigateToPermissions() },
        colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Permissions", style = MaterialTheme.typography.titleMedium, color = CyanAccent, fontWeight = FontWeight.Bold)
                Text("Manage app permissions for full functionality", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Filled.Security, contentDescription = null, tint = CyanAccent)
        }
    }
}

@Composable
fun StudyPreferencesSection(viewModel: StudyViewModel) {
    val defaultOffline by viewModel.defaultStudyModeOffline.collectAsState()
    val defaultDuration by viewModel.defaultStudyDuration.collectAsState()
    val defaultReminder by viewModel.defaultReminderMinutes.collectAsState()
    val defaultPriority by viewModel.defaultPriority.collectAsState()
    val defaultRepeat by viewModel.defaultRepeat.collectAsState()

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Study Preferences", style = MaterialTheme.typography.titleMedium, color = CyanAccent, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Default Study Mode (Offline)", color = MaterialTheme.colorScheme.onSurface)
                Switch(checked = defaultOffline, onCheckedChange = { viewModel.updateDefaultStudyModeOffline(it) })
            }
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Default Duration (min)", color = MaterialTheme.colorScheme.onSurface)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { viewModel.updateDefaultStudyDuration(maxOf(5, defaultDuration - 5)) }) { Icon(Icons.Filled.Remove, null, tint = CyanAccent) }
                    Text(defaultDuration.toString(), color = MaterialTheme.colorScheme.onSurface)
                    IconButton(onClick = { viewModel.updateDefaultStudyDuration(defaultDuration + 5) }) { Icon(Icons.Filled.Add, null, tint = CyanAccent) }
                }
            }
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Default Reminder (min)", color = MaterialTheme.colorScheme.onSurface)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { viewModel.updateDefaultReminderMinutes(maxOf(0, defaultReminder - 5)) }) { Icon(Icons.Filled.Remove, null, tint = CyanAccent) }
                    Text(defaultReminder.toString(), color = MaterialTheme.colorScheme.onSurface)
                    IconButton(onClick = { viewModel.updateDefaultReminderMinutes(defaultReminder + 5) }) { Icon(Icons.Filled.Add, null, tint = CyanAccent) }
                }
            }
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Default Priority", color = MaterialTheme.colorScheme.onSurface)
                TextButton(onClick = { 
                    val next = when(defaultPriority) { "Low" -> "Medium"; "Medium" -> "High"; else -> "Low" }
                    viewModel.updateDefaultPriority(next)
                }) { Text(defaultPriority, color = CyanAccent) }
            }
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Default Repeat", color = MaterialTheme.colorScheme.onSurface)
                TextButton(onClick = { 
                    val next = when(defaultRepeat) { "ONE_TIME" -> "DAILY"; "DAILY" -> "WEEKLY"; "WEEKLY" -> "MONTHLY"; else -> "ONE_TIME" }
                    viewModel.updateDefaultRepeat(next)
                }) { Text(defaultRepeat, color = CyanAccent) }
            }
        }
    }
}

@Composable
fun NotificationSettingsSection(viewModel: StudyViewModel) {
    val enableNotifs by viewModel.enableNotifications.collectAsState()
    val sound by viewModel.reminderSound.collectAsState()
    val vibration by viewModel.vibration.collectAsState()
    val silentMode by viewModel.silentMode.collectAsState()

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Notification Settings", style = MaterialTheme.typography.titleMedium, color = CyanAccent, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Enable Notifications", color = MaterialTheme.colorScheme.onSurface)
                Switch(checked = enableNotifs, onCheckedChange = { viewModel.updateEnableNotifications(it) })
            }
            if (enableNotifs) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Reminder Sound", color = MaterialTheme.colorScheme.onSurface)
                    Switch(checked = sound, onCheckedChange = { viewModel.updateReminderSound(it) })
                }
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Vibration", color = MaterialTheme.colorScheme.onSurface)
                    Switch(checked = vibration, onCheckedChange = { viewModel.updateVibration(it) })
                }
            }
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Silent Mode", color = MaterialTheme.colorScheme.onSurface)
                Switch(checked = silentMode, onCheckedChange = { viewModel.updateSilentMode(it) })
            }
        }
    }
}

@Composable
fun BackupRestoreSection(viewModel: StudyViewModel) {
    val context = LocalContext.current
    val backupFileDate by viewModel.backupFileDate.collectAsState()
    var showRestoreConfirm by remember { mutableStateOf(false) }
    var restoreUri by remember { mutableStateOf<android.net.Uri?>(null) }
    
    val backupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            viewModel.createBackup(uri) { success, msg ->
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    val restoreLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            restoreUri = uri
            showRestoreConfirm = true
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Backup & Restore", style = MaterialTheme.typography.titleMedium, color = CyanAccent, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            
            if (backupFileDate > 0) {
                val sdf = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
                Text("Last backup: ${sdf.format(Date(backupFileDate))}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Text("No backup created yet", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Button(onClick = { backupLauncher.launch("studyflow_backup_${System.currentTimeMillis()}.json") }) {
                    Icon(Icons.Filled.Backup, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Backup")
                }
                Button(onClick = { restoreLauncher.launch(arrayOf("application/json")) }) {
                    Icon(Icons.Filled.Restore, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Restore")
                }
            }
        }
    }

    if (showRestoreConfirm && restoreUri != null) {
        AlertDialog(
            onDismissRequest = { showRestoreConfirm = false },
            containerColor = DarkCharcoal,
            title = { Text("Restore Backup?", color = MaterialTheme.colorScheme.onSurface) },
            text = { Text("This will replace all your current schedules, progress, and history with the data from the backup file. This action cannot be undone.", color = MaterialTheme.colorScheme.onSurfaceVariant) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.restoreBackup(restoreUri!!) { success, msg ->
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        }
                        showRestoreConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = DeepCharcoal)
                ) {
                    Text("Restore", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreConfirm = false }) {
                    Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        )
    }
}

@Composable
fun AppearanceSection(viewModel: StudyViewModel) {
    val darkMode by viewModel.darkMode.collectAsState()
    val dynamicTheme by viewModel.dynamicTheme.collectAsState()
    val animationToggle by viewModel.animationToggle.collectAsState()

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Appearance", style = MaterialTheme.typography.titleMedium, color = CyanAccent, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Dark Mode", color = MaterialTheme.colorScheme.onSurface)
                Switch(checked = darkMode, onCheckedChange = { viewModel.updateDarkMode(it) })
            }
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Dynamic Theme (Android 12+)", color = MaterialTheme.colorScheme.onSurface)
                Switch(checked = dynamicTheme, onCheckedChange = { viewModel.updateDynamicTheme(it) })
            }
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Animations", color = MaterialTheme.colorScheme.onSurface)
                Switch(checked = animationToggle, onCheckedChange = { viewModel.updateAnimationToggle(it) })
            }
        }
    }
}

@Composable
fun DataStorageSection(viewModel: StudyViewModel) {
    val context = LocalContext.current
    var showClearCacheConfirm by remember { mutableStateOf(false) }
    val dbSize by viewModel.dbSize.collectAsState()
    val allSchedules by viewModel.allSchedules.collectAsState()
    val allHistory by viewModel.allSessions.collectAsState()
    
    val formatSize = { size: Long -> if (size < 1024) "$size B" else if (size < 1024 * 1024) "${size / 1024} KB" else "${size / (1024 * 1024)} MB" }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Data & Storage", style = MaterialTheme.typography.titleMedium, color = CyanAccent, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))
            
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Database Size", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(formatSize(dbSize), color = MaterialTheme.colorScheme.onSurface)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Schedules", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("${allSchedules.size}", color = MaterialTheme.colorScheme.onSurface)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("History Logs", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("${allHistory.size}", color = MaterialTheme.colorScheme.onSurface)
            }
            Spacer(modifier = Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = { showClearCacheConfirm = true }) {
                    Text("Clear Cache", color = MaterialTheme.colorScheme.error)
                }
                TextButton(onClick = { Toast.makeText(context, "Export Data functionality coming soon", Toast.LENGTH_SHORT).show() }) {
                    Text("Export Data", color = CyanAccent)
                }
            }
        }
    }
    
    if (showClearCacheConfirm) {
        AlertDialog(
            onDismissRequest = { showClearCacheConfirm = false },
            containerColor = DarkCharcoal,
            title = { Text("Clear Cache?", color = MaterialTheme.colorScheme.onSurface) },
            text = { Text("This will delete temporary app data but keep your schedules and history safe.", color = MaterialTheme.colorScheme.onSurfaceVariant) },
            confirmButton = {
                Button(
                    onClick = {
                        context.cacheDir.deleteRecursively()
                        Toast.makeText(context, "Cache Cleared", Toast.LENGTH_SHORT).show()
                        showClearCacheConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error, contentColor = MaterialTheme.colorScheme.onError)
                ) {
                    Text("Clear", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearCacheConfirm = false }) {
                    Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        )
}
}

@Composable
fun AboutSection() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("StudyFlow", style = MaterialTheme.typography.titleLarge, color = CyanAccent, fontWeight = FontWeight.Bold)
            Text("Version 2.1.7", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(16.dp))
            Text("Core Engine Version: 1.2.0", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Developer: Google AI Studio", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(16.dp))
            TextButton(onClick = { }) {
                Text("Open Source Licenses", color = CyanAccent)
            }
        }
    }
}
