import sys

def auto_fix(filepath):
    with open(filepath, 'r') as f:
        lines = f.readlines()
        
    depth = 0
    new_lines = []
    
    for line in lines:
        if line.strip().startswith("@Composable") or line.strip().startswith("private fun"):
            # If we are starting a new top-level construct, depth should be 0.
            while depth > 0:
                new_lines.append("}\n")
                depth -= 1
        
        new_lines.append(line)
        
        # update depth
        depth += line.count('{') - line.count('}')
        
    while depth > 0:
        new_lines.append("}\n")
        depth -= 1
        
    # if we have too many closing braces at the end, remove them
    while depth < 0:
        for i in range(len(new_lines)-1, -1, -1):
            if new_lines[i].strip() == '}':
                new_lines.pop(i)
                depth += 1
                break
                
    with open(filepath, 'w') as f:
        f.writelines(new_lines)

auto_fix('/app/applet/app/src/main/java/com/example/ui/analytics/AnalyticsScreen.kt')
auto_fix('/app/applet/app/src/main/java/com/example/ui/progress/ProgressScreen.kt')
auto_fix('/app/applet/app/src/main/java/com/example/ui/schedule/ScheduleScreen.kt')
auto_fix('/app/applet/app/src/main/java/com/example/ui/settings/SettingsScreen.kt')
auto_fix('/app/applet/app/src/main/java/com/example/MainActivity.kt')
