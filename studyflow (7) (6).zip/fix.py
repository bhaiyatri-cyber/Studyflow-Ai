with open('/app/applet/app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    text = f.read()

# Let's just remove one `}` from the end to see if it compiles
text = text.rstrip()
if text.endswith('}'):
    text = text[:-1]
    
with open('/app/applet/app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(text)
