with open('/app/applet/app/src/main/java/com/example/ui/analytics/AnalyticsScreen.kt', 'r') as f:
    text = f.read()

import re
# AnalyticsCard
text = re.sub(r'(fun AnalyticsCard.*?\n.*?)\n\n@Composable', r'\1\n}\n\n@Composable', text, flags=re.DOTALL)
# InsightCard
text = re.sub(r'(fun InsightCard.*?\n.*?)\n\n@Composable', r'\1\n}\n\n@Composable', text, flags=re.DOTALL)
# SubjectAnalyticsCard
text = re.sub(r'(fun SubjectAnalyticsCard.*?\n.*?)\n\n@Composable', r'\1\n}\n\n@Composable', text, flags=re.DOTALL)
# SectionTitle
text = re.sub(r'(fun SectionTitle.*?\n.*?)\n\n@Composable', r'\1\n}\n\n@Composable', text, flags=re.DOTALL)
# FocusTrendChart
text = re.sub(r'(fun FocusTrendChart.*?\n.*?)\n\nprivate fun', r'\1\n}\n\nprivate fun', text, flags=re.DOTALL)
# formatDuration
text = re.sub(r'(private fun formatDuration.*?\n.*?)\n\n@Composable', r'\1\n\n@Composable', text, flags=re.DOTALL) # formatDuration seems fine
# StatRow is at the end. It ends with:
#     }
# }
# }
# Wait, StatRow needs one } and the file needs zero.

# Let's just use bracket matching to format properly.
