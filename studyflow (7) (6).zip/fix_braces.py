with open('/app/applet/app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    lines = f.readlines()
    
# We will just rewrite the end of MainActivity manually
