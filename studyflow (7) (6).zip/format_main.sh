#!/bin/bash
cat /app/applet/app/src/main/java/com/example/MainActivity.kt | awk -v RS='\\{|\\}' 'BEGIN {depth = 0; line = 1} {depth += gsub(/\\{/, "{", RT) - gsub(/\\}/, "}", RT); if (depth < 0) {print "Negative depth at line", NR; exit}} END {print "Final depth:", depth}'
