import re

with open('/app/applet/app/src/main/java/com/example/ui/analytics/AnalyticsScreen.kt', 'r') as f:
    content = f.read()

# Add import
if "import com.example.ui.components.*" not in content:
    content = content.replace("import com.example.ui.theme.CyanAccent", "import com.example.ui.theme.CyanAccent\nimport com.example.ui.components.*")

old_root = """    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {"""

new_root = """    ResponsiveLayout(
        modifier = Modifier.background(MaterialTheme.colorScheme.background)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {"""

content = content.replace(old_root, new_root)
content += "\n}"

old_insight_card = """@Composable
fun InsightCard(insight: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {"""

new_insight_card = """@Composable
fun InsightCard(insight: String) {
    PremiumCard(
        modifier = Modifier.fillMaxWidth(),
        containerColor = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {"""

content = content.replace(old_insight_card, new_insight_card)

# Analytics Subject Card
old_subject = """@Composable
fun SubjectAnalyticsCard(stat: SubjectStat) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {"""

new_subject = """@Composable
fun SubjectAnalyticsCard(stat: SubjectStat) {
    PremiumCard(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        containerColor = MaterialTheme.colorScheme.surface
    ) {"""

content = content.replace(old_subject, new_subject)

# fix brackets for cards
content = re.sub(r'            }\n        }\n    }\n}', r'            }\n        }\n    }', content)
content = re.sub(r'        }\n    }\n}', r'        }\n    }', content)

with open('/app/applet/app/src/main/java/com/example/ui/analytics/AnalyticsScreen.kt', 'w') as f:
    f.write(content)
