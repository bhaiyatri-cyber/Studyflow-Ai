import re

with open('/app/applet/app/src/main/java/com/example/ui/history/HistoryScreen.kt', 'r') as f:
    content = f.read()

# Add import
if "import com.example.ui.components.*" not in content:
    content = content.replace("import com.example.ui.theme.DeepCharcoal", "import com.example.ui.theme.DeepCharcoal\nimport com.example.ui.components.*")

old_root = """    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepCharcoal)
            .padding(16.dp)
    ) {"""

new_root = """    ResponsiveLayout(
        modifier = Modifier.background(DeepCharcoal).padding(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {"""

content = content.replace(old_root, new_root)
content = content.replace("        }\n    }\n}\n\n@Composable\nfun HistoryCard", "        }\n    }\n    }\n}\n\n@Composable\nfun HistoryCard")

old_empty = """             Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                 Column(horizontalAlignment = Alignment.CenterHorizontally) {
                     Text(
                         text = "No history yet",
                         style = MaterialTheme.typography.titleLarge,
                         color = MaterialTheme.colorScheme.onSurfaceVariant
                     )
                     Spacer(modifier = Modifier.height(8.dp))
                     Text(
                         text = "Your completed and missed study sessions will appear here",
                         style = MaterialTheme.typography.bodyMedium,
                         color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                         textAlign = androidx.compose.ui.text.style.TextAlign.Center
                     )
                 }
             }"""

new_empty = """             PremiumEmptyState(
                 title = "No history yet",
                 description = "Your completed and missed study sessions will appear here.",
                 icon = Icons.Default.History,
                 modifier = Modifier.fillMaxSize()
             )"""

content = content.replace("import androidx.compose.material.icons.filled.Delete", "import androidx.compose.material.icons.filled.Delete\nimport androidx.compose.material.icons.filled.History")
content = content.replace(old_empty, new_empty)

old_card = """    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCharcoal)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {"""

new_card = """    PremiumCard(
        modifier = Modifier.fillMaxWidth(),
        containerColor = DarkCharcoal
    ) {"""

content = content.replace(old_card, new_card)

# need to fix closing brackets for HistoryCard since we removed Column
content = re.sub(r'            }\n        }\n    }\n}', r'            }\n        }\n    }', content)

with open('/app/applet/app/src/main/java/com/example/ui/history/HistoryScreen.kt', 'w') as f:
    f.write(content)
