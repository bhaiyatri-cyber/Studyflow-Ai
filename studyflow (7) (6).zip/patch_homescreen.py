import re

with open('/app/applet/app/src/main/java/com/example/ui/home/HomeScreen.kt', 'r') as f:
    content = f.read()

# Add import
if "import com.example.ui.components.*" not in content:
    content = content.replace("import com.example.ui.theme.GradientStart", "import com.example.ui.theme.GradientStart\nimport com.example.ui.components.*")

old_welcome_card = """@Composable
fun WelcomeCard(onCreateClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.EventNote,
                contentDescription = null,
                modifier = Modifier.size(80.dp),
                tint = CyanAccent
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Welcome to StudyFlow",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Organize your study sessions and track your progress to achieve your goals.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = onCreateClick,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = MaterialTheme.colorScheme.onPrimaryContainer)
            ) {
                Text("Create First Schedule", fontWeight = FontWeight.Bold)
            }
        }
    }
}"""

new_welcome_card = """@Composable
fun WelcomeCard(onCreateClick: () -> Unit) {
    PremiumEmptyState(
        title = "Welcome to StudyFlow",
        description = "Organize your study sessions and track your progress to achieve your goals.",
        icon = Icons.Default.EventNote,
        actionText = "Create First Schedule",
        onActionClick = onCreateClick,
        modifier = Modifier.padding(top = 16.dp, bottom = 16.dp)
    )
}"""

content = content.replace(old_welcome_card, new_welcome_card)

# Update goal card
old_goal_card = """@Composable
fun GoalCard(title: String, progress: Float, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                color = CyanAccent,
                trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}"""

new_goal_card = """@Composable
fun GoalCard(title: String, progress: Float, value: String, modifier: Modifier = Modifier) {
    PremiumCard(
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.surfaceVariant,
        elevation = 2.dp
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
            color = CyanAccent,
            trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}"""

content = content.replace(old_goal_card, new_goal_card)

with open('/app/applet/app/src/main/java/com/example/ui/home/HomeScreen.kt', 'w') as f:
    f.write(content)
