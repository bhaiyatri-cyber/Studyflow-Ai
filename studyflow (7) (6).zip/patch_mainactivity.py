import re

with open('/app/applet/app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

# We need to add WindowSizeClass logic
old_scaffold = """    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = navBackStackEntry?.destination
            NavigationBar {
                NavigationBarItem(
                    icon = { Icon(Icons.Filled.Home, contentDescription = "Home") },
                    label = { Text("Home") },
                    selected = currentDestination?.hierarchy?.any { it.route == HomeRoute::class.qualifiedName } == true,
                    onClick = {
                        navController.navigate(HomeRoute) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Filled.DateRange, contentDescription = "Schedule") },
                    label = { Text("Schedule") },
                    selected = currentDestination?.hierarchy?.any { it.route == ScheduleRoute::class.qualifiedName } == true,
                    onClick = {
                        navController.navigate(ScheduleRoute) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Filled.History, contentDescription = "History") },
                    label = { Text("History") },
                    selected = currentDestination?.hierarchy?.any { it.route == HistoryRoute::class.qualifiedName } == true,
                    onClick = {
                        navController.navigate(HistoryRoute) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Filled.BarChart, contentDescription = "Progress") },
                    label = { Text("Progress") },
                    selected = currentDestination?.hierarchy?.any { it.route == ProgressRoute::class.qualifiedName } == true,
                    onClick = {
                        navController.navigate(ProgressRoute) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Filled.Assessment, contentDescription = "Analytics") },
                    label = { Text("Analytics") },
                    selected = currentDestination?.hierarchy?.any { it.route == AnalyticsRoute::class.qualifiedName } == true,
                    onClick = {
                        navController.navigate(AnalyticsRoute) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Filled.Settings, contentDescription = "Settings") },
                    label = { Text("Settings") },
                    selected = currentDestination?.hierarchy?.any { it.route == SettingsRoute::class.qualifiedName } == true,
                    onClick = {
                        navController.navigate(SettingsRoute) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAssistant = true }) {
                Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = "Assistant")
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = HomeRoute,
            modifier = Modifier.padding(innerPadding)
        ) {"""

new_scaffold = """    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth > 600.dp

        Row(modifier = Modifier.fillMaxSize()) {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = navBackStackEntry?.destination
            
            val navigateTo = { route: Any -> 
                navController.navigate(route) {
                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                    launchSingleTop = true
                    restoreState = true
                }
            }

            if (isWideScreen) {
                NavigationRail {
                    NavigationRailItem(
                        icon = { Icon(Icons.Filled.Home, contentDescription = "Home") },
                        label = { Text("Home") },
                        selected = currentDestination?.hierarchy?.any { it.route == HomeRoute::class.qualifiedName } == true,
                        onClick = { navigateTo(HomeRoute) }
                    )
                    NavigationRailItem(
                        icon = { Icon(Icons.Filled.DateRange, contentDescription = "Schedule") },
                        label = { Text("Schedule") },
                        selected = currentDestination?.hierarchy?.any { it.route == ScheduleRoute::class.qualifiedName } == true,
                        onClick = { navigateTo(ScheduleRoute) }
                    )
                    NavigationRailItem(
                        icon = { Icon(Icons.Filled.History, contentDescription = "History") },
                        label = { Text("History") },
                        selected = currentDestination?.hierarchy?.any { it.route == HistoryRoute::class.qualifiedName } == true,
                        onClick = { navigateTo(HistoryRoute) }
                    )
                    NavigationRailItem(
                        icon = { Icon(Icons.Filled.BarChart, contentDescription = "Progress") },
                        label = { Text("Progress") },
                        selected = currentDestination?.hierarchy?.any { it.route == ProgressRoute::class.qualifiedName } == true,
                        onClick = { navigateTo(ProgressRoute) }
                    )
                    NavigationRailItem(
                        icon = { Icon(Icons.Filled.Assessment, contentDescription = "Analytics") },
                        label = { Text("Analytics") },
                        selected = currentDestination?.hierarchy?.any { it.route == AnalyticsRoute::class.qualifiedName } == true,
                        onClick = { navigateTo(AnalyticsRoute) }
                    )
                    NavigationRailItem(
                        icon = { Icon(Icons.Filled.Settings, contentDescription = "Settings") },
                        label = { Text("Settings") },
                        selected = currentDestination?.hierarchy?.any { it.route == SettingsRoute::class.qualifiedName } == true,
                        onClick = { navigateTo(SettingsRoute) }
                    )
                }
            }

            Scaffold(
                modifier = Modifier.weight(1f),
                bottomBar = {
                    if (!isWideScreen) {
                        NavigationBar {
                            NavigationBarItem(
                                icon = { Icon(Icons.Filled.Home, contentDescription = "Home") },
                                selected = currentDestination?.hierarchy?.any { it.route == HomeRoute::class.qualifiedName } == true,
                                onClick = { navigateTo(HomeRoute) }
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.Filled.DateRange, contentDescription = "Schedule") },
                                selected = currentDestination?.hierarchy?.any { it.route == ScheduleRoute::class.qualifiedName } == true,
                                onClick = { navigateTo(ScheduleRoute) }
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.Filled.History, contentDescription = "History") },
                                selected = currentDestination?.hierarchy?.any { it.route == HistoryRoute::class.qualifiedName } == true,
                                onClick = { navigateTo(HistoryRoute) }
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.Filled.BarChart, contentDescription = "Progress") },
                                selected = currentDestination?.hierarchy?.any { it.route == ProgressRoute::class.qualifiedName } == true,
                                onClick = { navigateTo(ProgressRoute) }
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.Filled.Assessment, contentDescription = "Analytics") },
                                selected = currentDestination?.hierarchy?.any { it.route == AnalyticsRoute::class.qualifiedName } == true,
                                onClick = { navigateTo(AnalyticsRoute) }
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.Filled.Settings, contentDescription = "Settings") },
                                selected = currentDestination?.hierarchy?.any { it.route == SettingsRoute::class.qualifiedName } == true,
                                onClick = { navigateTo(SettingsRoute) }
                            )
                        }
                    }
                },
                floatingActionButton = {
                    FloatingActionButton(onClick = { showAssistant = true }) {
                        Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = "Assistant")
                    }
                }
            ) { innerPadding ->
                NavHost(
                    navController = navController,
                    startDestination = HomeRoute,
                    modifier = Modifier.padding(innerPadding)
                ) {"""

content = content.replace(old_scaffold, new_scaffold)

# The end of the file also needs to close the BoxWithConstraints and Row if they were opened.
# The original ended with:
#                 AssistantBottomSheet(viewModel, onDismiss = { showAssistant = false })
#         }
#     }
# }

old_end = """        if (showAssistant) {
            AssistantBottomSheet(viewModel, onDismiss = { showAssistant = false })
        }
    }
}"""

new_end = """        if (showAssistant) {
                    AssistantBottomSheet(viewModel, onDismiss = { showAssistant = false })
                }
            }
        }
    }
}"""

content = content.replace(old_end, new_end)

with open('/app/applet/app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)

