import re

def make_responsive(filepath):
    try:
        with open(filepath, 'r') as f:
            content = f.read()

        if "import com.example.ui.components.*" not in content:
            content = content.replace("import com.example.ui.theme.DeepCharcoal", "import com.example.ui.theme.DeepCharcoal\nimport com.example.ui.components.*")

        old_root = """    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),"""
            
        new_root = """    ResponsiveLayout(
        modifier = Modifier.background(MaterialTheme.colorScheme.background).padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),"""
            
        if old_root in content:
            content = content.replace(old_root, new_root)
            content += "\n}"
            
        with open(filepath, 'w') as f:
            f.write(content)
    except:
        pass

make_responsive('/app/applet/app/src/main/java/com/example/ui/settings/PermissionManagementScreen.kt')

with open('/app/applet/app/src/main/java/com/example/ui/startup/WelcomeScreen.kt', 'r') as f:
    welcome = f.read()

if "import com.example.ui.components.*" not in welcome:
    welcome = welcome.replace("import com.example.ui.theme.DeepCharcoal", "import com.example.ui.theme.DeepCharcoal\nimport com.example.ui.components.*")
    
if "ResponsiveLayout" not in welcome:
    welcome = welcome.replace("    Column(\n        modifier = Modifier\n            .fillMaxSize()\n            .background(DeepCharcoal)\n            .verticalScroll(rememberScrollState())\n            .padding(24.dp)", "    ResponsiveLayout(modifier = Modifier.background(DeepCharcoal).verticalScroll(rememberScrollState()).padding(24.dp)) {\n        Column(modifier = Modifier.fillMaxSize()")
    if "ResponsiveLayout" in welcome:
        welcome += "\n}"
        
with open('/app/applet/app/src/main/java/com/example/ui/startup/WelcomeScreen.kt', 'w') as f:
    f.write(welcome)
