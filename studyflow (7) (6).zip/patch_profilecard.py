import re

with open('/app/applet/app/src/main/java/com/example/ui/home/HomeScreen.kt', 'r') as f:
    content = f.read()

old_profile_card = """@Composable
fun ProfileCard(
    name: String,
    avatarName: String,
    level: Int,
    currentXp: Int,
    xpToNextLevel: Int,
    streak: Int,
    dailyGoalMs: Long,
    dailyStudyMs: Long,
    completionPercent: Float,
    studyGoal: String
) {
    val rankName = when {
        level < 5 -> "Novice Scholar"
        level < 15 -> "Dedicated Student"
        level < 30 -> "Academic Achiever"
        level < 50 -> "Master Learner"
        else -> "Grandmaster of Study"
    }

    val icon: ImageVector = when (avatarName) {
        "face" -> Icons.Default.Face
        "emoji" -> Icons.Default.EmojiEmotions
        "pets" -> Icons.Default.Pets
        "school" -> Icons.Default.School
        else -> Icons.Default.Person
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(24.dp)) {"""

new_profile_card = """@Composable
fun ProfileCard(
    name: String,
    avatarName: String,
    level: Int,
    currentXp: Int,
    xpToNextLevel: Int,
    streak: Int,
    dailyGoalMs: Long,
    dailyStudyMs: Long,
    completionPercent: Float,
    studyGoal: String
) {
    val rankName = when {
        level < 5 -> "Novice Scholar"
        level < 15 -> "Dedicated Student"
        level < 30 -> "Academic Achiever"
        level < 50 -> "Master Learner"
        else -> "Grandmaster of Study"
    }

    val icon: ImageVector = when (avatarName) {
        "face" -> Icons.Default.Face
        "emoji" -> Icons.Default.EmojiEmotions
        "pets" -> Icons.Default.Pets
        "school" -> Icons.Default.School
        else -> Icons.Default.Person
    }

    PremiumCard(
        modifier = Modifier.fillMaxWidth(),
        containerColor = MaterialTheme.colorScheme.surfaceVariant
    ) {"""

content = content.replace(old_profile_card, new_profile_card)
# The `}` at the end of ProfileCard needs to remove an extra layer since Card {} Column {} was 2 layers, and PremiumCard {} is 1 layer.

with open('/app/applet/app/src/main/java/com/example/ui/home/HomeScreen.kt', 'w') as f:
    f.write(content)
