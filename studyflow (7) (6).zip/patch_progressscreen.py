import re

with open('/app/applet/app/src/main/java/com/example/ui/progress/ProgressScreen.kt', 'r') as f:
    content = f.read()

# Add import
if "import com.example.ui.components.*" not in content:
    content = content.replace("import com.example.ui.theme.*", "import com.example.ui.theme.*\nimport com.example.ui.components.*")

old_root = """    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {"""

new_root = """    ResponsiveLayout(
        modifier = Modifier.background(MaterialTheme.colorScheme.background)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {"""

content = content.replace(old_root, new_root)
# Note: we need to add an extra `}` at the end since we wrapped Column in ResponsiveLayout
content += "\n}"

with open('/app/applet/app/src/main/java/com/example/ui/progress/ProgressScreen.kt', 'w') as f:
    f.write(content)
