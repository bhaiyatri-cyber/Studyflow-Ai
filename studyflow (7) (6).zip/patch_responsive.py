import re

with open('/app/applet/app/src/main/java/com/example/ui/components/StudyFlowComponents.kt', 'r') as f:
    content = f.read()

responsive_component = """
@Composable
fun ResponsiveLayout(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
        ) {
            content()
        }
    }
}
"""

if "fun ResponsiveLayout(" not in content:
    content += responsive_component

with open('/app/applet/app/src/main/java/com/example/ui/components/StudyFlowComponents.kt', 'w') as f:
    f.write(content)
