import re

with open('/app/applet/app/src/main/java/com/example/ui/schedule/ScheduleScreen.kt', 'r') as f:
    content = f.read()

# Add import
if "import com.example.ui.components.*" not in content:
    content = content.replace("import com.example.ui.theme.DeepCharcoal", "import com.example.ui.theme.DeepCharcoal\nimport com.example.ui.components.*")

old_root = """    Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {"""

new_root = """    ResponsiveLayout(modifier = Modifier.background(MaterialTheme.colorScheme.background)) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {"""

content = content.replace(old_root, new_root)

old_empty = """                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.EventBusy, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("No schedules available", style = MaterialTheme.typography.titleLarge)
                        Text("Click the + button to create a new study session", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }"""

new_empty = """                PremiumEmptyState(
                    title = "No schedules available",
                    description = "Create a new study session to organize your time.",
                    icon = Icons.Default.EventBusy,
                    actionText = "Add Schedule",
                    onActionClick = { onNavigateToCreate(-1) },
                    modifier = Modifier.fillMaxSize()
                )"""

content = content.replace(old_empty, new_empty)

old_lazy_column_start = """                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {"""

new_lazy_column_start = """                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    item {
                        PrimaryButton(
                            text = "Add Schedule",
                            onClick = { onNavigateToCreate(-1) },
                            icon = Icons.Default.Add,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
                        )
                    }"""

content = content.replace(old_lazy_column_start, new_lazy_column_start)

old_fab = """        FloatingActionButton(
            onClick = { onNavigateToCreate(-1) },
            containerColor = CyanAccent,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 80.dp, end = 16.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = "Add Schedule", tint = DeepCharcoal)
        }"""

content = content.replace(old_fab, "")

old_card = """    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .border(width = if (isRunning) 2.dp else 0.dp, color = borderColor, shape = RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {"""

new_card = """    PremiumCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .border(width = if (isRunning) 2.dp else 0.dp, color = borderColor, shape = RoundedCornerShape(StudyFlowSpacing.cardRadius)),
        containerColor = cardColor,
        elevation = 2.dp
    ) {
        Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {"""

content = content.replace(old_card, new_card)

# fix brackets for card again
content = re.sub(r'            }\n        }\n    }\n}', r'            }\n        }\n    }', content)


with open('/app/applet/app/src/main/java/com/example/ui/schedule/ScheduleScreen.kt', 'w') as f:
    f.write(content)
