import re

with open('/app/applet/app/src/main/java/com/example/ui/settings/SettingsScreen.kt', 'r') as f:
    content = f.read()

if "import com.example.ui.components.*" not in content:
    content = content.replace("import com.example.ui.theme.DeepCharcoal", "import com.example.ui.theme.DeepCharcoal\nimport com.example.ui.components.*")

old_root = """    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepCharcoal)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {"""

new_root = """    ResponsiveLayout(
        modifier = Modifier.background(DeepCharcoal).verticalScroll(scrollState).padding(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {"""

content = content.replace(old_root, new_root)
# Note: we need to add an extra `}` at the end of the `SettingsScreen` block, not at the end of the file since the file contains other composables.
# We will find where `SettingsScreen` ends and add it there.
settings_end = r'(            Spacer\(modifier = Modifier.height\(32.dp\)\)\n        }\n    }\n)'
content = re.sub(settings_end, r'\1\n}', content)

# I can optionally replace Card with PremiumCard in SettingsScreen as well, but it might be too many replacements (there are many sections).
# At least making it responsive is the main goal.

with open('/app/applet/app/src/main/java/com/example/ui/settings/SettingsScreen.kt', 'w') as f:
    f.write(content)

