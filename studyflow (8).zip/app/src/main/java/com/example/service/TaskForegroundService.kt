package com.example.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.R
import com.example.util.StudyFlowCoreEngine

class TaskForegroundService : Service() {

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val EXTRA_TASK_ID = "EXTRA_TASK_ID"
        const val EXTRA_TASK_NAME = "EXTRA_TASK_NAME"
        const val EXTRA_START_TIME = "EXTRA_START_TIME"
        const val EXTRA_END_TIME = "EXTRA_END_TIME"
    }

    private var sensorManager: SensorManager? = null

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        StudyFlowCoreEngine.registerSensors(sensorManager)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            val taskId = intent.getIntExtra(EXTRA_TASK_ID, -1)
            if (taskId != -1) {
                StudyFlowCoreEngine.stopTask(taskId)
            } else {
                stopSelf()
            }
            return START_NOT_STICKY
        } else if (action == ACTION_START) {
            val taskId = intent.getIntExtra(EXTRA_TASK_ID, -1)
            if (taskId != -1) {
                StudyFlowCoreEngine.startTask(taskId)
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("STUDY_TASKS", "Running Tasks", NotificationManager.IMPORTANCE_DEFAULT)
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, "STUDY_TASKS")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Study Tracker Active")
            .setContentText("Tracking your study session...")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        startForeground(1, notification)
        return START_STICKY
    }

    override fun onDestroy() {
        StudyFlowCoreEngine.unregisterSensors(sensorManager)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
