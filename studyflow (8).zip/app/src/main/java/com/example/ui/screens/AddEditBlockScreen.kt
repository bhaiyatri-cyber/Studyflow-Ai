package com.example.ui.screens

import android.app.TimePickerDialog
import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*

import android.content.Context
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState

import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.data.model.TimeBlock
import com.example.ui.theme.BlockColorBreak
import com.example.ui.theme.BlockColorReading
import com.example.ui.theme.BlockColorReview
import com.example.ui.theme.BlockColorStudy
import java.util.*
import java.text.SimpleDateFormat

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditBlockScreen(
    block: TimeBlock?,
    allBlocks: List<TimeBlock>,
    onSave: (TimeBlock) -> Unit,
    onDelete: (TimeBlock) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var subject by remember { mutableStateOf(block?.subject ?: "") }
    var notes by remember { mutableStateOf(block?.notes ?: "") }

    val sharedPrefs = context.getSharedPreferences("StudyFlowPrefs", Context.MODE_PRIVATE)
    var favoriteSubjects by remember { mutableStateOf(sharedPrefs.getStringSet("favorite_subjects", emptySet())?.toList() ?: emptyList()) }
    val isFavorite = favoriteSubjects.contains(subject)

    
    val calendar = Calendar.getInstance()
    var startCalendar by remember { mutableStateOf(Calendar.getInstance().apply { 
        if (block != null) timeInMillis = block.startTimeMs else {
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
    }) }
    
    var endCalendar by remember { mutableStateOf(Calendar.getInstance().apply { 
        if (block != null) timeInMillis = block.endTimeMs else {
            add(Calendar.HOUR_OF_DAY, 1)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
    }) }

    val colors = listOf(BlockColorStudy, BlockColorBreak, BlockColorReview, BlockColorReading)
    var selectedColor by remember { mutableStateOf(block?.color ?: colors[0].toArgb()) }
    var selectedApps by remember { mutableStateOf(block?.studyApps?.split(",")?.filter { it.isNotEmpty() }?.toSet() ?: emptySet()) }
    var showAppSelection by remember { mutableStateOf(false) }
    var installedApps by remember { mutableStateOf<List<AppItem>>(emptyList()) }
    var searchQuery by remember { mutableStateOf("") }
    
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val apps = packages.filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 || it.packageName.contains("youtube") }
                .map { appInfo ->
                    val name = pm.getApplicationLabel(appInfo).toString()
                    val icon = try {
                        pm.getApplicationIcon(appInfo).toBitmap(100, 100)
                    } catch (e: Exception) { null }
                    AppItem(appInfo.packageName, name, icon)
                }
                .sortedBy { it.name.lowercase() }
            withContext(Dispatchers.Main) {
                installedApps = apps
            }
        }
    }

    
    var reminderStart by remember { mutableStateOf(block?.reminderBeforeStart ?: true) }
    var reminderEnd by remember { mutableStateOf(block?.reminderBeforeEnd ?: true) }
    var notifyDuring by remember { mutableStateOf(block?.notifyDuring ?: false) }
    var notifyStart by remember { mutableStateOf(block?.notifyStart ?: true) }
    var notifyEnd by remember { mutableStateOf(block?.notifyEnd ?: true) }

    val is24HourFormat = android.text.format.DateFormat.is24HourFormat(context)
    val timeFormatStr = if (is24HourFormat) "HH:mm" else "hh:mm a"
    val timeFormat = SimpleDateFormat(timeFormatStr, Locale.getDefault())
    val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (block == null) "Add Block" else "Edit Block") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (block != null) {
                        IconButton(onClick = { 
                            onDelete(block)
                            onNavigateBack()
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            )
        },
        bottomBar = {
            Box(modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .imePadding(),
                contentAlignment = Alignment.Center
            ) {
                FloatingActionButton(
                    onClick = {
                        if (subject.isNotBlank() && endCalendar.timeInMillis > startCalendar.timeInMillis) {
                            val nowMs = System.currentTimeMillis()
                            val tempBlock = block?.copy(
                                subject = subject,
                                startTimeMs = startCalendar.timeInMillis,
                                endTimeMs = endCalendar.timeInMillis,
                                color = selectedColor,
                                reminderBeforeStart = reminderStart,
                                reminderBeforeEnd = reminderEnd,
                                notifyStart = notifyStart,
                                notifyDuring = notifyDuring,
                                notifyEnd = notifyEnd,
                                notes = notes,
                                studyApps = selectedApps.joinToString(",")
                            ) ?: TimeBlock(
                                subject = subject,
                                startTimeMs = startCalendar.timeInMillis,
                                endTimeMs = endCalendar.timeInMillis,
                                color = selectedColor,
                                iconName = "default",
                                reminderBeforeStart = reminderStart,
                                reminderBeforeEnd = reminderEnd,
                                notifyStart = notifyStart,
                                notifyDuring = notifyDuring,
                                notifyEnd = notifyEnd,
                                notes = notes,
                                studyApps = selectedApps.joinToString(","),
                                status = "Upcoming"
                            )
                            val initialStatus = tempBlock.status
                            val newBlock = tempBlock.copy(
                                status = if (block != null && block.status == "Completed") "Completed" else initialStatus
                            )
                            onSave(newBlock)
                            onNavigateBack()
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Save", modifier = Modifier.padding(horizontal = 16.dp))
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 16.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            
            OutlinedTextField(
                value = subject,
                onValueChange = { subject = it },
                label = { Text("Subject / Task Name") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                trailingIcon = {
                    if (subject.isNotEmpty()) {
                        IconButton(onClick = { subject = "" }) {
                            Icon(Icons.Default.Delete, contentDescription = "Clear")
                        }
                    }
                }
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                favoriteSubjects.forEach { fav ->
                    FilterChip(
                        selected = subject == fav,
                        onClick = { subject = fav },
                        label = { Text(fav) }
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes (Optional)") },
                modifier = Modifier.fillMaxWidth().height(100.dp),
                maxLines = 3
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                OutlinedCard(modifier = Modifier
                    .weight(1f)
                    .clickable {
                        TimePickerDialog(
                            context,
                            { _, hourOfDay, minute ->
                                startCalendar = Calendar.getInstance().apply {
                                    if (block != null) {
                                        timeInMillis = startCalendar.timeInMillis
                                    } else {
                                        timeInMillis = System.currentTimeMillis()
                                    }
                                    set(Calendar.HOUR_OF_DAY, hourOfDay)
                                    set(Calendar.MINUTE, minute)
                                    set(Calendar.SECOND, 0)
                                    set(Calendar.MILLISECOND, 0)
                                    if (block == null && timeInMillis < System.currentTimeMillis()) {
                                        add(Calendar.DAY_OF_YEAR, 1)
                                    }
                                }
                                if (endCalendar.timeInMillis < startCalendar.timeInMillis) {
                                    endCalendar = Calendar.getInstance().apply {
                                        timeInMillis = startCalendar.timeInMillis
                                        add(Calendar.HOUR_OF_DAY, 1)
                                    }
                                }
                            },
                            startCalendar.get(Calendar.HOUR_OF_DAY),
                            startCalendar.get(Calendar.MINUTE),
                            is24HourFormat
                        ).show()
                    }) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Start Time", style = MaterialTheme.typography.labelSmall)
                        Text(timeFormat.format(startCalendar.time), style = MaterialTheme.typography.titleLarge)
                    }
                }
                
                Spacer(modifier = Modifier.width(16.dp))
                
                OutlinedCard(modifier = Modifier
                    .weight(1f)
                    .clickable {
                        TimePickerDialog(
                            context,
                            { _, hourOfDay, minute ->
                                endCalendar = Calendar.getInstance().apply {
                                    val startMs = startCalendar.timeInMillis
                                    timeInMillis = startMs
                                    set(Calendar.HOUR_OF_DAY, hourOfDay)
                                    set(Calendar.MINUTE, minute)
                                    set(Calendar.SECOND, 0)
                                    set(Calendar.MILLISECOND, 0)
                                    if (timeInMillis < startMs) {
                                        add(Calendar.DAY_OF_YEAR, 1)
                                    }
                                }
                            },
                            endCalendar.get(Calendar.HOUR_OF_DAY),
                            endCalendar.get(Calendar.MINUTE),
                            is24HourFormat
                        ).show()
                    }) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("End Time", style = MaterialTheme.typography.labelSmall)
                        Text(timeFormat.format(endCalendar.time), style = MaterialTheme.typography.titleLarge)
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text("Color", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                colors.forEach { c ->
                    val colorArgb = c.toArgb()
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(c)
                            .clickable { selectedColor = colorArgb },
                        contentAlignment = Alignment.Center
                    ) {
                        if (selectedColor == colorArgb) {
                            Icon(Icons.Default.Star, contentDescription = "Selected", tint = Color.White)
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text("Repeat System", style = MaterialTheme.typography.titleMedium)
            var expandedRepeat by remember { mutableStateOf(false) }
            val repeatOptions = listOf("None", "Daily", "Weekly", "Monthly", "Custom")
            var repeatMode by remember { mutableStateOf(block?.repeatMode ?: "None") }
            var customDays by remember { mutableStateOf(block?.customDays ?: "") }
            
            ExposedDropdownMenuBox(
                expanded = expandedRepeat,
                onExpandedChange = { expandedRepeat = !expandedRepeat }
            ) {
                OutlinedTextField(
                    readOnly = true,
                    value = repeatMode,
                    onValueChange = { },
                    label = { Text("Repeat") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedRepeat) },
                    colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                    modifier = Modifier.menuAnchor(androidx.compose.material3.MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = expandedRepeat,
                    onDismissRequest = { expandedRepeat = false }
                ) {
                    repeatOptions.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option) },
                            onClick = {
                                repeatMode = option
                                expandedRepeat = false
                            }
                        )
                    }
                }
            }
            
            if (repeatMode == "Custom") {
                Spacer(modifier = Modifier.height(8.dp))
                val daysOfWeek = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
                var selectedDays by remember { mutableStateOf(customDays.split(",").filter { it.isNotEmpty() }.toSet()) }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    daysOfWeek.forEach { day ->
                        FilterChip(
                            selected = selectedDays.contains(day),
                            onClick = {
                                selectedDays = if (selectedDays.contains(day)) selectedDays - day else selectedDays + day
                                customDays = selectedDays.joinToString(",")
                            },
                            label = { Text(day, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text("Study Mode", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            var studyMode by remember { mutableStateOf(if (block?.studyApps?.isEmpty() == true) "Offline" else "Online") }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = studyMode == "Online",
                    onClick = { studyMode = "Online" },
                    label = { Text("Online / App Tracking") },
                    leadingIcon = { Icon(Icons.Default.Apps, contentDescription = null) }
                )
                FilterChip(
                    selected = studyMode == "Offline",
                    onClick = { studyMode = "Offline"; selectedApps = emptySet() },
                    label = { Text("Offline / Face-Down") },
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) }
                )
            }
            
            if (studyMode == "Online") {
                Spacer(modifier = Modifier.height(16.dp))
                Text("Study Applications", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedCard(modifier = Modifier.fillMaxWidth().clickable { showAppSelection = true }) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Selected Apps:", style = MaterialTheme.typography.labelMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    if (selectedApps.isEmpty()) {
                        Text("No study apps selected.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        val displayApps = installedApps.filter { selectedApps.contains(it.packageName) }
                        if (displayApps.isEmpty()) {
                            Text("Loading apps...", style = MaterialTheme.typography.bodyMedium)
                        } else {
                            displayApps.forEach { app ->
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
                                    if (app.icon != null) {
                                        Image(bitmap = app.icon.asImageBitmap(), contentDescription = null, modifier = Modifier.size(24.dp))
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(app.name, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = { showAppSelection = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Select Apps")
                    }
                }
            }
            } else {
                Spacer(modifier = Modifier.height(8.dp))
                Text("In Offline Mode, simply place your phone face-down on a flat surface. The timer will pause if you lift or use your phone.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text("Notifications", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = notifyStart, onCheckedChange = { notifyStart = it })
                Text("Notify exactly at start time")
            }
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = reminderStart, onCheckedChange = { reminderStart = it })
                Text("Reminder 10 minutes before start")
            }
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = notifyDuring, onCheckedChange = { notifyDuring = it })
                Text("Notify during session (every 10 min check)")
            }
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = notifyEnd, onCheckedChange = { notifyEnd = it })
                Text("Notify exactly at end time")
            }
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = reminderEnd, onCheckedChange = { reminderEnd = it })
                Text("Reminder 10 minutes before end")
            }
            
            if (block != null) {
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = {
                        onDelete(block); onNavigateBack()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Delete Block")
                }
            }
            
            Spacer(modifier = Modifier.height(100.dp)) // padding for FAB
        }
    }
    
    if (showAppSelection) {
        AlertDialog(
            onDismissRequest = { showAppSelection = false },
            title = { Text("Select Study Apps") },
            text = {
                Column {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Search Apps") },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                    )
                    LazyColumn(modifier = Modifier.fillMaxWidth().weight(1f, fill = false)) {
                        items(installedApps.filter { it.name.contains(searchQuery, ignoreCase = true) }) { app ->
                            val isSelected = selectedApps.contains(app.packageName)
                            ListItem(
                                headlineContent = { Text(app.name) },
                                leadingContent = {
                                    if (app.icon != null) {
                                        Image(bitmap = app.icon.asImageBitmap(), contentDescription = null, modifier = Modifier.size(32.dp))
                                    }
                                },
                                trailingContent = {
                                    Checkbox(checked = isSelected, onCheckedChange = null)
                                },
                                modifier = Modifier.clickable {
                                    selectedApps = if (isSelected) {
                                        selectedApps - app.packageName
                                    } else {
                                        selectedApps + app.packageName
                                    }
                                }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { showAppSelection = false }
                ) {
                    Text("Done")
                }
            }
        )
    }
}
