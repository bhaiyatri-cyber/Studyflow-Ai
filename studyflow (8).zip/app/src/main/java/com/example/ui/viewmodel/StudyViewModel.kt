package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.DailyStats
import com.example.data.model.TimeBlock
import com.example.data.repository.StudyRepository
import com.example.util.AlarmScheduler
import com.example.util.StudyFlowCoreEngine
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class StudyViewModel(application: Application) : AndroidViewModel(application) {
    private val db = com.example.data.local.DatabaseProvider.getDatabase(application)
    private val repository = StudyRepository(db.timeBlockDao(), db.statsDao())
    private val alarmScheduler = AlarmScheduler(application)

    val allBlocks: StateFlow<List<TimeBlock>> = StudyFlowCoreEngine.allBlocks
    val stats: StateFlow<DailyStats?> = StudyFlowCoreEngine.stats

    init {
        StudyFlowCoreEngine.initialize(application)
        viewModelScope.launch {
            repository.getStats().collect { currentStats ->
                if (currentStats == null) {
                    repository.insertStats(DailyStats())
                }
            }
        }
    }

    fun addBlock(block: TimeBlock) {
        viewModelScope.launch {
            val id = repository.insertBlock(block)
            val insertedBlock = block.copy(id = id.toInt())
            alarmScheduler.scheduleAlarmsForBlock(insertedBlock)
        }
    }

    fun updateBlock(block: TimeBlock) {
        viewModelScope.launch {
            repository.updateBlock(block)
            alarmScheduler.cancelAlarmsForBlock(block)
            alarmScheduler.scheduleAlarmsForBlock(block)
        }
    }

    fun deleteBlock(block: TimeBlock) {
        viewModelScope.launch {
            repository.deleteBlockById(block.id)
            alarmScheduler.cancelAlarmsForBlock(block)
        }
    }

    fun updateStats(newStats: DailyStats) {
        viewModelScope.launch {
            repository.updateStats(newStats)
        }
    }
}
