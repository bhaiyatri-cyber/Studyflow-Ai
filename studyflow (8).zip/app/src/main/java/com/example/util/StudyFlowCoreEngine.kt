package com.example.util

import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Process
import android.provider.Settings
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.local.DatabaseProvider
import com.example.data.model.DailyStats
import com.example.data.model.TimeBlock
import com.example.service.AppAccessibilityService
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

object StudyFlowCoreEngine : SensorEventListener {

    private lateinit var context: Context
    private lateinit var db: AppDatabase
    
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // SINGLE SOURCE OF TRUTH (Exposed to ViewModels/Screens)
    private val _allBlocks = MutableStateFlow<List<TimeBlock>>(emptyList())
    val allBlocks: StateFlow<List<TimeBlock>> = _allBlocks.asStateFlow()

    private val _stats = MutableStateFlow<DailyStats?>(null)
    val stats: StateFlow<DailyStats?> = _stats.asStateFlow()

    // Engine State
    private var isInitialized = false
    private var isFaceDownAndStill = false
    private var lastAccelData = FloatArray(3)
    private var accelTimestamp = 0L

    private var activeTaskId: Int = -1
    private var realStudyTimeMs: Long = 0L
    private var appUsageMap = mutableMapOf<String, Long>()
    private var studyAppsList = listOf<String>()
    
    fun initialize(appContext: Context) {
        if (isInitialized) return
        context = appContext
        db = DatabaseProvider.getDatabase(context)
        isInitialized = true

        createNotificationChannel()

        // Sync Data
        scope.launch {
            db.timeBlockDao().getAllBlocks().collect { blocks ->
                _allBlocks.value = blocks.map { processBlockStatus(it) }
            }
        }
        scope.launch {
            db.statsDao().getStats().collect { currentStats ->
                _stats.value = currentStats
            }
        }

        // Master Timer Loop
        scope.launch {
            while (isActive) {
                tick()
                delay(1000)
            }
        }
    }

    // ==========================================
    // 1. PERMISSION ENGINE
    // ==========================================
    fun hasRequiredPermissions(): Boolean {
        // Usage access
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        } else {
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        }
        val hasUsage = mode == AppOpsManager.MODE_ALLOWED
        
        // Notifications
        val hasNotif = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
        } else true

        return hasUsage && hasNotif
    }

    // ==========================================
    // 2. STATUS & SCHEDULE ENGINE
    // ==========================================
    private fun processBlockStatus(block: TimeBlock): TimeBlock {
        val now = System.currentTimeMillis()
        var newStatus = block.status

        if (block.status in listOf("Completed", "Skipped", "Missed")) {
            return block
        }

        if (now < block.startTimeMs) {
            newStatus = "Upcoming"
        } else if (now in block.startTimeMs until block.endTimeMs) {
            if (activeTaskId == block.id) {
                newStatus = "Running"
            } else {
                val hasStarted = (block.actualTimeTakenMs ?: 0L) > 0L
                newStatus = if (hasStarted) "Paused" else "Waiting"
            }
        } else if (now >= block.endTimeMs) {
            val graceMs = 5 * 60 * 1000L
            if (now < block.endTimeMs + graceMs) {
                newStatus = if (activeTaskId == block.id) "Running" else "Waiting"
            } else {
                newStatus = "Missed"
                // Auto-close missed
                scope.launch { saveHistory(block.id, "Missed") }
            }
        }

        return if (newStatus != block.status) block.copy(status = newStatus) else block
    }

    // ==========================================
    // 3. TIMER & MODE ENGINE
    // ==========================================
    private fun tick() {
        val nowMs = System.currentTimeMillis(); val updatedBlocks = _allBlocks.value.map { processBlockStatus(it) }; if (updatedBlocks != _allBlocks.value) { _allBlocks.value = updatedBlocks }; if (activeTaskId == -1) return
        
        val block = _allBlocks.value.find { it.id == activeTaskId } ?: return
        if (block.status in listOf("Completed", "Skipped", "Missed")) {
            activeTaskId = -1
            cancelNotification()
            return
        }
        val now = System.currentTimeMillis()

        if (now >= block.endTimeMs) {
            // End session
            scope.launch { saveHistory(activeTaskId, if (realStudyTimeMs > 0) "Completed" else "Missed") }
            activeTaskId = -1
            cancelNotification()
            return
        }

        if (!hasRequiredPermissions()) {
            updateNotification(block, false, false)
            return
        }

        val isOnlineMode = studyAppsList.isNotEmpty()
        val foregroundApp = getForegroundApp()
        
        val isStudying = if (isOnlineMode) {
            foregroundApp != null && studyAppsList.contains(foregroundApp)
        } else {
            isFaceDownAndStill
        }

        if (isStudying) {
            realStudyTimeMs += 1000
            if (isOnlineMode && foregroundApp != null) {
                appUsageMap[foregroundApp] = (appUsageMap[foregroundApp] ?: 0L) + 1000
            } else if (!isOnlineMode) {
                appUsageMap["Other"] = (appUsageMap["Other"] ?: 0L) + 1000
            }
            
            // Sync to DB periodically
            if (realStudyTimeMs % 5000L == 0L) {
                scope.launch {
                    val currentBlock = db.timeBlockDao().getBlockById(activeTaskId)
                    if (currentBlock != null) {
                        db.timeBlockDao().updateBlock(currentBlock.copy(
                            status = "Running",
                            actualTimeTakenMs = (currentBlock.actualTimeTakenMs ?: 0L) + 5000
                        ))
                    }
                }
            }
        }

        updateNotification(block, isStudying, realStudyTimeMs > 0)
    }

    fun startTask(taskId: Int) {
        if (!hasRequiredPermissions()) return
        scope.launch {
            val block = db.timeBlockDao().getBlockById(taskId) ?: return@launch
            studyAppsList = if (block.studyApps.isNotBlank()) block.studyApps.split(",") else emptyList()
            activeTaskId = taskId
            realStudyTimeMs = 0L
            appUsageMap.clear()
            
            val intent = Intent(context, com.example.service.TaskForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    fun stopTask(taskId: Int) {
        if (activeTaskId == taskId) {
            scope.launch { saveHistory(activeTaskId, "Paused") }
            activeTaskId = -1
            cancelNotification()
        }
    }

    // ==========================================
    // 4. HISTORY ENGINE
    // ==========================================
    private suspend fun saveHistory(taskId: Int, finalStatus: String) {
        val block = db.timeBlockDao().getBlockById(taskId) ?: return
        if (block.status in listOf("Completed", "Missed", "Skipped")) return

        val json = JSONObject()
        appUsageMap.forEach { (k, v) -> json.put(k, v) }
        
        db.timeBlockDao().updateBlock(block.copy(
            status = finalStatus,
            appUsageStatsJson = json.toString(),
            completedOnMs = System.currentTimeMillis()
        ))
        
        // Update stats
        if (realStudyTimeMs > 0) {
            val s = db.statsDao().getStatsOnce() ?: DailyStats()
            db.statsDao().updateStats(s.copy(
                totalStudyHours = s.totalStudyHours + realStudyTimeMs,
                totalCompletedTasks = s.totalCompletedTasks + 1,
                currentStreak = s.currentStreak + 1 // Add real streak logic if needed
            ))
        }
    }

    // ==========================================
    // 5. NOTIFICATION ENGINE
    // ==========================================
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("STUDY_TASKS", "Running Tasks", NotificationManager.IMPORTANCE_DEFAULT)
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun updateNotification(block: TimeBlock, isStudying: Boolean, hasStartedStudying: Boolean) {
        if (block.status in listOf("Completed", "Skipped", "Missed")) {
            activeTaskId = -1
            cancelNotification()
            return
        }
        val now = System.currentTimeMillis()
        val durationMs = block.endTimeMs - block.startTimeMs
        val elapsedMs = (now - block.startTimeMs).coerceAtLeast(0L)
        val remainingMs = (block.endTimeMs - now).coerceAtLeast(0L)
        val progress = if (durationMs > 0) (elapsedMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f
        val progressPercent = (progress * 100).toInt()
        
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val startStr = timeFormat.format(Date(block.startTimeMs))
        val endStr = timeFormat.format(Date(block.endTimeMs))
        val remainingStr = String.format(Locale.getDefault(), "%02d:%02d:%02d", remainingMs / 3600000, (remainingMs / 60000) % 60, (remainingMs / 1000) % 60)

        val mainIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(context, 0, mainIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        
        val title = if (studyAppsList.isNotEmpty()) {
            if (!hasStartedStudying) "Waiting for Study App..."
            else if (isStudying) "Running: ${block.subject}"
            else "Paused: Open a Study App"
        } else {
            if (isStudying) "Running: ${block.subject}" else "Paused: Phone not face down"
        }

        val notification = NotificationCompat.Builder(context, "STUDY_TASKS")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText("Remaining: $remainingStr ($progressPercent%) | $startStr - $endStr")
            .setProgress(100, progressPercent, false)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOnlyAlertOnce(true)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(1, notification)
    }

    private fun cancelNotification() {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.cancel(1)
        val intent = Intent(context, com.example.service.TaskForegroundService::class.java)
        context.stopService(intent)
    }

    // ==========================================
    // OFFLINE SENSORS
    // ==========================================
    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            val now = System.currentTimeMillis()
            if (now - accelTimestamp > 500) {
                val x = event.values[0]; val y = event.values[1]; val z = event.values[2]
                val dx = abs(x - lastAccelData[0]); val dy = abs(y - lastAccelData[1]); val dz = abs(z - lastAccelData[2])
                val isStill = dx < 1.5f && dy < 1.5f && dz < 1.5f
                val isFaceDown = z < -7.0f && abs(x) < 4.0f && abs(y) < 4.0f
                isFaceDownAndStill = isStill && isFaceDown
                lastAccelData[0] = x; lastAccelData[1] = y; lastAccelData[2] = z
                accelTimestamp = now
            }
        }
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    fun registerSensors(sensorManager: SensorManager?) {
        val accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        sensorManager?.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL)
    }

    fun unregisterSensors(sensorManager: SensorManager?) {
        sensorManager?.unregisterListener(this)
    }

    private fun getForegroundApp(): String? {
        if (AppAccessibilityService.currentForegroundPackage != null) return AppAccessibilityService.currentForegroundPackage
        val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val endTime = System.currentTimeMillis()
        val beginTime = endTime - 10000
        val usageEvents = usageStatsManager.queryEvents(beginTime, endTime)
        var foregroundPackage: String? = null
        val event = android.app.usage.UsageEvents.Event()
        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)
            if (event.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED) {
                foregroundPackage = event.packageName
            }
        }
        return foregroundPackage ?: context.packageName
    }
}
